#!/usr/bin/env python3
"""Installation locale isolee puis ouverture de Cedric Elec Atelier.
Aucune commande ne telecharge un interpreteur, ne demande de droits admin,
ne modifie un compte, ni ne publie les projets.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.metadata
import os
from pathlib import Path
import subprocess
import sys
import venv

ROOT = Path(__file__).resolve().parent
REQUIREMENTS = ROOT / 'requirements.txt'
VENV = ROOT / '.venv'


def requirements():
    return [line.strip().split('==', 1) for line in REQUIREMENTS.read_text().splitlines()
            if line.strip() and not line.lstrip().startswith('#')]


def verify_current():
    print('Python :', sys.version.split()[0])
    ok = sys.version_info >= (3, 11)
    for name, expected in requirements():
        try:
            actual = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            actual = 'absent'
        match = actual == expected
        ok = ok and match
        print(f'{name} : {actual} (attendu {expected}) - ' + ('OK' if match else 'a installer'))
    return ok


def main():
    parser = argparse.ArgumentParser(description='Demarrage local de Cedric Elec Atelier')
    parser.add_argument('--check', action='store_true', help='verifie Python et les versions, sans installer')
    args, app_args = parser.parse_known_args()
    if sys.version_info < (3, 11):
        print('Python 3.11 ou plus recent est requis. Python 3.13 est la version testee.')
        return 1
    if args.check:
        return 0 if verify_current() else 1
    python = VENV / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    stamp = VENV / '.cedric-requirements.sha256'
    digest = hashlib.sha256(REQUIREMENTS.read_bytes()).hexdigest()
    try:
        if not python.is_file():
            print('Preparation de l\'environnement local .venv (sans droits administrateur)...', flush=True)
            venv.EnvBuilder(with_pip=True).create(VENV)
        if not stamp.exists() or stamp.read_text().strip() != digest:
            print('Premiere installation : connexion Internet necessaire pour les bibliotheques libres.', flush=True)
            print('Aucun compte ni cle API. Aucun abonnement ou service payant active.', flush=True)
            print('Cela peut prendre plusieurs minutes. Ne fermez pas cette fenetre.', flush=True)
            subprocess.run([str(python), '-m', 'pip', 'install', '--disable-pip-version-check',
                            '--only-binary=:all:', '-r', str(REQUIREMENTS)], cwd=ROOT, check=True)
            subprocess.run([str(python), str(ROOT/'launch.py'), '--check'], cwd=ROOT, check=True)
            stamp.write_text(digest+'\n')
        print('\nOuverture de Cedric Elec Atelier dans votre navigateur...', flush=True)
        print('Gardez cette fenetre ouverte pendant le travail. Ctrl+C arrete le logiciel.', flush=True)
        return subprocess.call([str(python), str(ROOT/'app.py'), *app_args], cwd=ROOT)
    except KeyboardInterrupt:
        print('\nArret demande.')
        return 0
    except (OSError, subprocess.CalledProcessError) as exc:
        print('\nLe lancement n\'a pas abouti :', exc)
        print('Consultez DEMARRER_ICI.html et docs/DEPANNAGE.md.')
        print('Verifiez Internet et un Python 64 bits compatible. Python 3.13 a ete teste.')
        print('Les projets existants ne sont pas supprimes. Aucun paiement n\'a ete effectue.')
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
