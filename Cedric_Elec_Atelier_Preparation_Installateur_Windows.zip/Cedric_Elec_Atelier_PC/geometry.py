"""Geometrie et regles metier. Aucune dependance reseau."""
from __future__ import annotations
import copy
import heapq
import math
import uuid
from collections import defaultdict


def uid():
    return uuid.uuid4().hex


def distance(a, b):
    return math.hypot(a[0]-b[0], a[1]-b[1])


def polygon_area(points):
    return abs(sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(points, points[1:]+points[:1])))/2 if len(points)>2 else 0


def point_segment_distance(p,a,b):
    dx,dy=b[0]-a[0],b[1]-a[1]
    t=max(0,min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy))) if dx or dy else 0
    return distance(p,(a[0]+t*dx,a[1]+t*dy))


def inside(point, polygon, boundary=True):
    if len(polygon)<3:
        return False
    if boundary and any(point_segment_distance(point,a,b)<1e-7 for a,b in zip(polygon,polygon[1:]+polygon[:1])):
        return True
    x,y=point
    hit=False
    j=len(polygon)-1
    for i in range(len(polygon)):
        xi,yi=polygon[i]; xj,yj=polygon[j]
        if ((yi>y)!=(yj>y)) and x < (xj-xi)*(y-yi)/(yj-yi)+xi:
            hit=not hit
        j=i
    return hit


def assigned_room(element,zones):
    p=[element['x'],element['y']]
    page=element['page']
    eligible=[z for z in zones if z.get('type','room')=='room' and z['page']==page and z.get('confirmed',True) and inside(p,z['points'])]
    if not eligible:
        return None,False
    eligible.sort(key=lambda z:polygon_area(z['points']))
    chosen=eligible[0]
    on_edge=any(point_segment_distance(p,a,b)<1.5 for a,b in zip(chosen['points'],chosen['points'][1:]+chosen['points'][:1]))
    return chosen['id'],on_edge


def assign_rooms(project):
    valid_ids={z['id']:z for z in project['zones'] if z.get('type','room')=='room' and z.get('confirmed',True)}
    for e in project['elements']:
        if e.get('roomManual') and e.get('roomId') in valid_ids and valid_ids[e['roomId']]['page']==e['page']:
            continue
        e['roomId'],e['onBoundary']=assigned_room(e,project['zones'])
    return project


def rect_polygon(rect):
    x,y,w,h=rect
    return [[x,y],[x+w,y],[x+w,y+h],[x,y+h]]


def is_excluded(point,page,project):
    for z in project.get('zones',[]):
        if z['page']==page and z.get('type')=='exclude' and inside(point,z['points']):
            return True
    for item in project.get('legend',[]):
        s=item.get('source',{})
        if s.get('page')==page and s.get('rect') and s.get('excludeFromCount',True) and inside(point,rect_polygon(s['rect'])):
            return True
    return False


def merge_detections(project, legend_id, page, detections):
    """Corrections manuelles et exclusions survivent a chaque nouvelle analyse."""
    old=project['elements']
    stable=[e for e in old if not(e['legendId']==legend_id and e['page']==page and e['status']=='pending' and not e.get('manual'))]
    previous=[e for e in old if e['legendId']==legend_id and e['page']==page]
    added=0; occupied=0
    next_ref=max([int(e.get('ref','E-0').split('-')[-1]) for e in old if str(e.get('ref','')).split('-')[-1].isdigit()]+[0])+1
    for d in sorted(detections,key=lambda v:v.get('score',0),reverse=True):
        p=[d['x'],d['y']]
        if is_excluded(p,page,project):
            continue
        radius=max(2,min(d.get('w',8),d.get('h',8))*.4)
        duplicate=next((e for e in stable if e['page']==page and distance(p,[e['x'],e['y']]) < radius),None)
        if duplicate:
            occupied+=1
            continue
        match=next((e for e in previous if distance(p,[e['x'],e['y']])<radius),None)
        e=dict(d,id=match['id'] if match else uid(),ref=match['ref'] if match else f'E-{next_ref:03d}',legendId=legend_id,page=page,status='pending',manual=False,notes='')
        if not match:
            next_ref+=1
        stable.append(e);added+=1
    project['elements']=stable
    assign_rooms(project)
    mark_stale_circuits(project)
    return added,occupied


def mark_stale_circuits(project):
    elements={e['id']:e for e in project['elements']}
    for c in project.get('circuits',[]):
        current=[elements.get(k) for k in c.get('elementIds',[])]
        missing=any(not e or e['status']!='validated' for e in current)
        moved=any(e and [round(e['x'],3),round(e['y'],3)]!=c.get('positions',{}).get(e['id']) for e in current)
        regrouped=any(e and (not c.get('bus') and (e.get('legendId')!=c.get('legendId') or e.get('roomId')!=c.get('zoneId'))) for e in current)
        target=next((t for t in project.get('targets',[]) if t['id']==c.get('targetId')),None)
        target_moved=not target or [round(target['x'],3),round(target['y'],3)]!=c.get('targetPosition')
        passage=next((p for p in project.get('passages',[]) if p['id']==c.get('passageId')),None)
        passage_moved=bool(c.get('passageId')) and (not passage or passage['points']!=c.get('passagePoints'))
        obstacles=[z['points'] for z in project['zones'] if z['page']==c['page'] and z.get('type')=='obstacle']
        obstacle_changed=obstacles!=c.get('obstaclesSnapshot',obstacles)
        mode_changed=bool(c.get('bus')) and not project.get('config',{}).get('domotique',True)
        for route in c.get('routes',[]):
            points=route.get('points',[])
            route['blocked']=not points or any(not clear_segment(a,b,obstacles) for a,b in zip(points,points[1:]))
        c['stale']=bool(missing or moved or regrouped or target_moved or passage_moved or obstacle_changed or mode_changed)


def segments_intersect(a,b,c,d):
    def orient(p,q,r):return (q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0])
    o1,o2,o3,o4=orient(a,b,c),orient(a,b,d),orient(c,d,a),orient(c,d,b)
    if o1*o2<0 and o3*o4<0:return True
    eps=1e-8
    if abs(o1)<eps and point_segment_distance(c,a,b)<eps:return True
    if abs(o2)<eps and point_segment_distance(d,a,b)<eps:return True
    if abs(o3)<eps and point_segment_distance(a,c,d)<eps:return True
    if abs(o4)<eps and point_segment_distance(b,c,d)<eps:return True
    return False


def clear_segment(a,b,obstacles):
    for poly in obstacles:
        if inside(a,poly) or inside(b,poly):return False
        if any(segments_intersect(a,b,c,d) for c,d in zip(poly,poly[1:]+poly[:1])):return False
    return True


def simplify_path(points):
    out=[]
    for p in points:
        p=[round(float(p[0]),3),round(float(p[1]),3)]
        if out and distance(p,out[-1])<1e-5:continue
        if len(out)>=2:
            a,b=out[-2],out[-1]
            cross=(b[0]-a[0])*(p[1]-b[1])-(b[1]-a[1])*(p[0]-b[0])
            dot=(b[0]-a[0])*(p[0]-b[0])+(b[1]-a[1])*(p[1]-b[1])
            if abs(cross)<1e-7 and dot>=0:out.pop()
        out.append(p)
    return out


def orthogonal_route(start,end,obstacles,bounds):
    """Graphe de visibilite orthogonal: aucun chemin force a travers un obstacle."""
    if distance(start,end)<1e-5:return [list(start)]
    for bend in ([start[0],end[1]],[end[0],start[1]]):
        if clear_segment(start,bend,obstacles) and clear_segment(bend,end,obstacles):
            return simplify_path([start,bend,end])
    margin=max(2,min(bounds)/450)
    xs={float(start[0]),float(end[0])};ys={float(start[1]),float(end[1])}
    for poly in obstacles:
        for x,y in poly:
            xs.update([max(0,x-margin),min(bounds[0],x+margin)])
            ys.update([max(0,y-margin),min(bounds[1],y+margin)])
    xs=sorted(xs);ys=sorted(ys)
    if len(xs)*len(ys)>30000:
        return None
    nodes={(i,j):(x,y) for i,x in enumerate(xs) for j,y in enumerate(ys) if not any(inside((x,y),o) for o in obstacles)}
    a=(xs.index(float(start[0])),ys.index(float(start[1])));b=(xs.index(float(end[0])),ys.index(float(end[1])))
    if a not in nodes or b not in nodes:return None
    cost={a:0};prev={};queue=[(distance(start,end),0,a)];closed=set()
    while queue:
        _,g,n=heapq.heappop(queue)
        if n in closed:continue
        if n==b:
            route=[nodes[n]]
            while n in prev:n=prev[n];route.append(nodes[n])
            return simplify_path(route[::-1])
        closed.add(n)
        for k in ((n[0]-1,n[1]),(n[0]+1,n[1]),(n[0],n[1]-1),(n[0],n[1]+1)):
            if k not in nodes or k in closed:continue
            if not clear_segment(nodes[n],nodes[k],obstacles):continue
            ng=g+distance(nodes[n],nodes[k])
            if ng<cost.get(k,float('inf')):
                cost[k]=ng;prev[k]=n
                heapq.heappush(queue,(ng+distance(nodes[k],end),ng,k))
    return None


def route_with_passage(start,end,obstacles,bounds,passage=None):
    if not passage or len(passage)<2:return orthogonal_route(start,end,obstacles,bounds)
    entry=min(range(len(passage)),key=lambda i:distance(start,passage[i]))
    exit_=min(range(len(passage)),key=lambda i:distance(end,passage[i]))
    middle=passage[entry:exit_+1] if entry<=exit_ else passage[exit_:entry+1][::-1]
    first=orthogonal_route(start,middle[0],obstacles,bounds)
    last=orthogonal_route(middle[-1],end,obstacles,bounds)
    if not first or not last:return None
    if any(not clear_segment(a,b,obstacles) for a,b in zip(middle,middle[1:])):return None
    return simplify_path(first+middle[1:]+last[1:])


def generate_circuits(project,page,target_id,passage_id=None):
    assign_rooms(project)
    target=next((t for t in project['targets'] if t['id']==target_id and t['page']==page),None)
    if not target:raise ValueError('Choisissez un tableau sur la page active.')
    legends={x['id']:x for x in project['legend']}
    zones={x['id']:x for x in project['zones']}
    groups=defaultdict(list);unassigned=0
    for e in project['elements']:
        if e['page']!=page or e['status']!='validated':continue
        typ=legends.get(e['legendId'],{})
        family=typ.get('family','autre')
        bus=family=='commande' and project.get('config',{}).get('domotique',True)
        if not e.get('roomId') and not bus:unassigned+=1;continue
        key=('bus','all') if bus else (e['legendId'],e['roomId'])
        groups[key].append(e)
    existing={(c.get('groupKey'),c.get('targetId')):c for c in project['circuits'] if c['page']==page}
    generated=[];blocked=0;kept=0
    bounds=project['document']['pages'][page]
    obstacles=[z['points'] for z in project['zones'] if z['page']==page and z.get('type')=='obstacle']
    passage=next((p['points'] for p in project.get('passages',[]) if p['id']==passage_id and p['page']==page),None)
    counters=defaultdict(int)
    for c in project['circuits']:
        prefix=c.get('name','C-0').split('-')[0]
        try:counters[prefix]=max(counters[prefix],int(c['name'].split('-')[-1]))
        except (ValueError,KeyError):pass
    for key,elems in groups.items():
        group_key=':'.join(key);prior=existing.get((group_key,target_id))
        if prior and prior.get('manual'):
            generated.append(prior);kept+=1;continue
        bus=key[0]=='bus'
        typ=legends[elems[0]['legendId']]
        family='bus' if bus else typ.get('family','autre')
        prefix={'eclairage':'ECL','prise':'PC','commande':'CMD','bus':'BUS','reseau':'RES','alimentation':'ALIM'}.get(family,'C')
        counters[prefix]+=1
        order=[];todo=elems[:];cursor=[target['x'],target['y']]
        while todo:
            e=min(todo,key=lambda v:distance(cursor,[v['x'],v['y']]))
            order.append(e);todo.remove(e);cursor=[e['x'],e['y']]
        order.reverse()
        nodes=[[e['x'],e['y']] for e in order]+[[target['x'],target['y']]]
        routes=[]
        for i,(a,b) in enumerate(zip(nodes,nodes[1:])):
            pts=route_with_passage(a,b,obstacles,[bounds['width'],bounds['height']],passage if i==len(nodes)-2 else None)
            if pts is None:blocked+=1
            routes.append({'points':pts or [],'blocked':pts is None,'from':order[i]['id'],'to':order[i+1]['id'] if i+1<len(order) else target_id})
        generated.append({'id':prior['id'] if prior else uid(),'page':page,'name':prior['name'] if prior else f'{prefix}-{counters[prefix]:03d}',
          'groupKey':group_key,'legendId':elems[0]['legendId'],'zoneId':None if bus else elems[0]['roomId'],'targetId':target_id,
          'targetPosition':[round(target['x'],3),round(target['y'],3)],'elementIds':[e['id'] for e in order],
          'positions':{e['id']:[round(e['x'],3),round(e['y'],3)] for e in order},'routes':routes,'bus':bus,'color':'#1d8e75' if bus else typ['color'],
          'manual':False,'stale':False,'passageId':passage_id,'passagePoints':copy.deepcopy(passage),'obstaclesSnapshot':copy.deepcopy(obstacles),'extraMeters':prior.get('extraMeters',0) if prior else 0,'notes':''})
    # Preserve custom or manually locked circuits, including groups no longer generated.
    generated_ids={c['id'] for c in generated}
    project['circuits']=[c for c in project['circuits'] if c['page']!=page or (c.get('manual') and c['id'] not in generated_ids)]+generated
    mark_stale_circuits(project)
    return {'circuits':len(generated),'blocked':blocked,'unassigned':unassigned,'kept':kept}


def route_length(circuit,scale):
    if not scale or circuit.get('stale') or any(r.get('blocked') for r in circuit['routes']):return None
    planar=sum(distance(a,b) for r in circuit['routes'] for a,b in zip(r['points'],r['points'][1:]))*scale
    return round(planar+max(0,float(circuit.get('extraMeters',0))),2)


def counts(project):
    zones={z['id']:z for z in project['zones']}
    output=[]
    for symbol in project['legend']:
        els=[e for e in project['elements'] if e['legendId']==symbol['id']]
        output.append({'id':symbol['id'],'name':symbol['name'],'validated':sum(e['status']=='validated' for e in els),'pending':sum(e['status']=='pending' for e in els),'excluded':sum(e['status']=='excluded' for e in els)})
    return output


def simple_polygon(points):
    """Reject self-crossing contours and coincident consecutive vertices."""
    n=len(points)
    if any(distance(points[i],points[(i+1)%n])<1e-6 for i in range(n)):return False
    for i in range(n):
        for j in range(i+1,n):
            if j==i+1 or (i==0 and j==n-1):continue
            if segments_intersect(points[i],points[(i+1)%n],points[j],points[(j+1)%n]):return False
    return True
