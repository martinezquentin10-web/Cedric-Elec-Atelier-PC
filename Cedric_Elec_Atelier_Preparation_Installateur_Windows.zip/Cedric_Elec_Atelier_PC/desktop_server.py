"""Point d'entree HTTP strictement local, protege par un secret de lancement."""
from __future__ import annotations
import hmac
import json
import secrets
import threading
import time
import urllib.parse
from http.cookies import SimpleCookie
from http.server import ThreadingHTTPServer
from pathlib import Path
import app
from desktop_store import DesktopStore
from desktop_workers import DesktopWorkers

VERSION = '0.2.0-bureau-alpha'


class DesktopHandler(app.Handler):
    def _safe_origin(self):
        super()._safe_origin()
        cookies = SimpleCookie()
        try:
            cookies.load(self.headers.get('Cookie', ''))
        except Exception:
            cookies = SimpleCookie()
        cookie = cookies.get('ce_desktop')
        supplied = cookie.value if cookie else ''
        if not hmac.compare_digest(supplied, self.server.desktop_key):
            raise PermissionError('Acces reserve a la fenetre du logiciel local.')

    def do_GET(self):
        url = urllib.parse.urlsplit(self.path)
        supplied = urllib.parse.parse_qs(url.query).get('launch', [''])[0]
        if url.path == '/' and supplied:
            try:
                app.Handler._safe_origin(self)
                if not hmac.compare_digest(supplied, self.server.desktop_key):
                    raise PermissionError('Cle de lancement invalide.')
                self.send_response(303)
                self.send_header('Location', '/')
                self.send_header('Set-Cookie', 'ce_desktop=' + self.server.desktop_key + '; Path=/; HttpOnly; SameSite=Strict')
                self.send_header('Cache-Control', 'no-store')
                self.send_header('Referrer-Policy', 'no-referrer')
                self.send_header('Content-Length', '0')
                self.end_headers()
                return
            except Exception as exc:
                return self._dispatch_error(exc)
        return super().do_GET()

    def _send(self, status, body, kind='application/json; charset=utf-8', download=None):
        if kind.startswith('text/html') and isinstance(body, bytes):
            body = body.replace(b'</head>', b'<script>window.CE_DESKTOP=true;</script><script src="/static/desktop.js" defer></script></head>')
        return super()._send(status, body, kind, download)

    def send_header(self, keyword, value):
        if keyword.lower() == 'content-security-policy':
            # pywebview uses eval to resolve the strictly local JS bridge.
            value = value.replace("script-src 'self' 'unsafe-inline'", "script-src 'self' 'unsafe-inline' 'unsafe-eval'")
            value += "; form-action 'none'"
        return super().send_header(keyword, value)


class DesktopRuntime:
    def __init__(self, root, *, port=0):
        self._old_store, self._old_version = app.STORE, app.VERSION
        self.store = DesktopStore(root)
        self.workers = DesktopWorkers()
        self.workers.install()
        app.STORE = self.store
        app.VERSION = VERSION
        self.http = ThreadingHTTPServer(('127.0.0.1', port), DesktopHandler)
        self.http.daemon_threads = True
        self.http.desktop_key = secrets.token_urlsafe(32)
        self.origin = f'http://127.0.0.1:{self.http.server_port}'
        self.url = self.origin + '/?launch=' + self.http.desktop_key
        self.thread = threading.Thread(target=self.http.serve_forever, daemon=True, name='CE-HTTP-local')
        self.closed = False

    def start(self):
        self.thread.start()
        return self

    def close(self):
        if self.closed:
            return
        self.closed = True
        for job in list(app.JOBS.values()):
            job['cancel'].set()
        self.workers.close()
        deadline = time.monotonic() + 3
        while any(j['status'] == 'running' for j in list(app.JOBS.values())) and time.monotonic() < deadline:
            time.sleep(.03)
        if self.thread.is_alive():
            self.http.shutdown()
            self.thread.join(timeout=3)
        self.http.server_close()
        app.STORE, app.VERSION = self._old_store, self._old_version
