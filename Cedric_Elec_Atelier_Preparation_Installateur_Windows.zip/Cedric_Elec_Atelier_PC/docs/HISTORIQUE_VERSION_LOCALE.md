# Cédric Elec Atelier — version locale 0.1.0

Logiciel neuf d'analyse assistée et de repérage de plans électriques. Code propre à ce projet, sans reprise de l'ancienne application. Logo fourni par Cédric Elec. Livraison du 11 octobre 2026.

**Il s'agit d'une première version fonctionnelle à essayer, pas d'une reconnaissance universelle validée ni d'un logiciel de calcul réglementaire.** Elle fonctionne sur l'ordinateur qui l'exécute, dans son navigateur, sans hébergement ni API payante. Les projets restent sur cet ordinateur.

## Démarrer sous Windows

1. Extraire **tout** le ZIP dans un dossier, par exemple `Documents/CedricElecAtelier`.
2. Disposer de **Python 3.11 ou plus récent, en 64 bits**. Python **3.13** est la version effectivement testée. Installation officielle : https://www.python.org/downloads/ . Aucun achat de Python n'est nécessaire.
3. Double-cliquer sur **LANCER_WINDOWS.cmd**. Au premier lancement seulement, les bibliothèques sont téléchargées depuis PyPI dans `.venv` : Internet est nécessaire. Le navigateur s'ouvre ensuite. Garder la fenêtre de lancement ouverte.

Ce n'est pas un exécutable Windows autonome : Python et la première installation des dépendances restent nécessaires. Le script Windows est fourni mais n'a pas pu être exécuté sous Windows dans l'environnement de livraison. Les essais ont été faits sous Linux, Python 3.13 et Chromium. Aucun programme ne sera installé avec des droits administrateur par ces scripts.

Mac/Linux : dans le dossier extrait, exécuter `python3 launch.py` ou le script `LANCER_MAC_LINUX.command`. Certains systèmes Linux demandent le paquet `python3-venv`. Le lancement n'installe pas Python lui-même.

## Premier essai guidé

Ouvrir **Maison exemple**. La légende et l'échelle sont préparées, mais les objets et les pièces ne sont pas précomptés : le moteur effectue réellement leur recherche.

- **Comptage** : lancer l'analyse, examiner les cercles sur le plan puis valider. Le plan pédagogique comporte 13 spots, 9 prises, 6 commandes et 3 RJ45, soit 31 équipements. Ces nombres concernent cet exemple uniquement.
- **Pièces** : proposer les pièces, vérifier et confirmer chaque contour. Rectangles et polygones peuvent être dessinés manuellement et leurs sommets déplacés.
- **Tracés** : placer un tableau, choisir les passages et obstacles explicites, puis proposer les circuits. En mode domotique, les commandes ont leur BUS distinct. Sélectionner un circuit pour déplacer ses poignées. Une correction manuelle verrouille le tracé afin qu'il ne soit pas écrasé par une nouvelle proposition.
- **Sauvegarder** : exporter un `.ceprojet`. **Récapitulatif & exports** produit le PDF annoté, le CSV ou le SVG éditable.

## Importer un chantier

Formats acceptés : PDF, DXF, PNG, JPEG et WebP. Le PDF vectoriel conserve des informations que les scans n'ont pas. Le DXF peut fournir les noms, positions et rotations des blocs. L'import direct des DWG n'est **pas** inclus : exporter depuis AutoCAD un PDF vectoriel ou un DXF. Pour le DXF, seul l'espace objet est utilisé ; les références externes ne sont pas chargées et les polices peuvent être substituées. Contrôler l'affichage avant de compter.

Encadrer la légende pour obtenir des propositions d'entrées ou découper un symbole à la fois. Vérifier le nom, la famille et l'échantillon. Le logiciel peut aussi utiliser un exemplaire pris directement sur le plan. Exclure la légende, le cartouche et les détails hors périmètre. Les pages se traitent séparément ; une légende peut servir de référence pour une autre page.

Toutes les détections commencent **« à vérifier »**. Le score affiché mesure une ressemblance et n'est pas une probabilité de justesse. Une quantité validée résulte d'une validation utilisateur, pas d'une certification du moteur. Ajouter, déplacer, reclasser ou exclure les objets pour corriger le résultat. Ces décisions sont conservées lors des analyses suivantes.

## Limites importantes de cette livraison

La reconnaissance automatique peut manquer ou confondre des symboles, surtout sur les plans denses, les tracés décomposés, les scans, les exemplaires collés aux murs ou avec une échelle différente. Les rotations testées en reconnaissance d'image sont 0/90/180/270 degrés ; il ne s'agit pas d'une invariance universelle. Aucun OCR ou service d'IA distant n'est intégré.

L'extraction automatique des pièces est une aide expérimentale : sur le PDF de chantier complexe utilisé pour le test d'import, elle n'a fourni **aucun contour exploitable**. Le tracé manuel des zones est alors nécessaire. Les noms seuls ne suffisent pas à définir des murs. Les sous-pièces doivent rester à l'intérieur du parent. Le comptage affecte chaque objet à une seule pièce feuille pour éviter les doublons.

Les murs du fond de plan ne deviennent **pas automatiquement des obstacles de câblage**. Dessiner les obstacles et les passages à respecter, puis contrôler les propositions. Les circuits de cette version sont des regroupements et des tracés de travail : les nombres maximaux d'appareils, protections, sections, topologie du réseau, chutes de tension et règles techniques ne sont pas calculés ni validés. Les liaisons représentées ne sont pas un schéma de raccordement prescriptif.

Les longueurs ne sont indiquées qu'après calibration ou unités DXF exploitables. Elles suivent le chemin en 2D et la réserve totale saisie. Ajouter explicitement montées, descentes et réserves. Un circuit devenu incohérent ou bloqué n'a pas de longueur exploitable.

L'interface a été examinée en largeurs ordinateur, tablette et téléphone **émulées**. Cette version locale n'est pas accessible depuis un autre appareil. Ni synchronisation cloud, ni comptes multiples, ni application mobile native, ni hébergement public ne sont fournis.

## Données et sauvegardes

Par défaut : `~/CedricElecAtelier/Projets`, soit typiquement `C:\Users\VOTRE_NOM\CedricElecAtelier\Projets` sous Windows. Chaque projet conserve son original, une représentation de travail, ses données et au maximum 15 révisions de données. Les écritures sont atomiques et un contrôle de révision évite d'écraser silencieusement une sauvegarde concurrente.

Un `.ceprojet` comprend le plan original et les annotations. Il peut donc contenir des informations confidentielles de chantier. Ne le transmettre qu'aux personnes autorisées. L'ouverture de ce fichier crée une copie de projet indépendante. L'historique local ne remplace **pas** une sauvegarde sur un autre support. Ces fichiers ne sont pas chiffrés par l'application ; la sécurité du compte et du disque reste importante.

## Technique et essais

```sh
python -m venv .venv
# Windows : .venv\Scripts\activate
# Mac/Linux : source .venv/bin/activate
python -m pip install -r requirements-dev.txt
python -m pytest -q
python app.py
```

`python launch.py --check` affiche les versions sans rien installer. Le serveur écoute uniquement `127.0.0.1`, sur le premier port disponible de 8765 à 8779. Fermer sa fenêtre ou utiliser Ctrl+C arrête l'application, pas les fichiers de projet.

Voir **docs/VALIDATION.md**, **docs/ARCHITECTURE.md**, **docs/DEPANNAGE.md** et **THIRD_PARTY_NOTICES.md**. Aucun changement n'a été publié sur l'ancien site ou dépôt GitHub. Aucun service payant n'a été activé.

## Licence

Code source nouveau livré sous **GNU AGPL v3 ou ultérieure**, avec son texte dans `LICENSE`. Les bibliothèques gardent leurs propres licences, notamment PyMuPDF sous AGPL pour l'usage de sa distribution libre. Une redistribution ou une mise à disposition réseau impose de respecter les conditions applicables ; la livraison n'est pas une licence propriétaire des composants tiers. Le logo et le nom Cédric Elec ne sont pas concédés comme marque libre et restent distincts de la licence du code. Aucune licence commerciale n'a été achetée.
