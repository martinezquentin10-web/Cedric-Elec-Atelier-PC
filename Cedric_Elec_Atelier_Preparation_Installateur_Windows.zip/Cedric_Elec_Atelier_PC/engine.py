"""Lecture PDF/DXF, recherche locale et propositions de pieces.
Les scores sont des similarites graphiques, jamais des probabilites de justesse.
"""
from __future__ import annotations
import io
import time
from collections import OrderedDict
import json
import math
import re
import threading
from pathlib import Path

import cv2
import numpy as np
import pymupdf as fitz
import ezdxf
from PIL import Image, ImageOps

from geometry import uid, inside, polygon_area, rect_polygon, distance, is_excluded

PDF_LOCK=threading.RLock()
MAX_PIXELS=4_000_000
MAX_SIDE=2400
# Every tile is bounded BEFORE allocating MuPDF/OpenCV buffers.
TILE_SIZE=512
TILE_CACHE=OrderedDict()
TILE_CACHE_BYTES=0
TILE_CACHE_LIMIT=12*1024*1024
cv2.setNumThreads(1)


def prepare_document(folder:Path, filename:str, raw:bytes):
    suffix=Path(filename).suffix.lower()
    if suffix=='.dwg':
        raise ValueError('Le DWG natif n\u2019est pas pris en charge. Exportez un PDF vectoriel ou un DXF depuis AutoCAD.')
    if suffix not in ('.pdf','.dxf','.png','.jpg','.jpeg','.webp'):
        raise ValueError('Formats acceptes : PDF, DXF, PNG, JPG et WEBP.')
    if not raw or len(raw)>100*1024*1024:
        raise ValueError('Le fichier est vide ou depasse 100 Mo.')
    source=folder/('original'+suffix)
    source.write_bytes(raw)
    blocks=[];polygons=[];texts=[];warnings=[];meter_per_point=None
    with PDF_LOCK:
        if suffix=='.pdf':
            doc=fitz.open(stream=raw,filetype='pdf')
            if doc.needs_pass:raise ValueError('PDF protege : enregistrez une copie non chiffree avant import.')
            if not 0<len(doc)<=250:raise ValueError('Le PDF doit contenir entre 1 et 250 pages.')
            for page in doc:
                if page.rotation:page.remove_rotation()
            doc.save(folder/'work.pdf',garbage=3,deflate=True)
            doc.close()
            kind='pdf'
        elif suffix=='.dxf':
            blocks,polygons,meter_per_point,warnings,texts=convert_dxf(source,folder/'work.pdf')
            kind='dxf'
        else:
            image=ImageOps.exif_transpose(Image.open(io.BytesIO(raw))).convert('RGB')
            if image.width*image.height>60_000_000:raise ValueError('Image trop grande (60 millions de pixels maximum).')
            bio=io.BytesIO();image.save(bio,format='PNG')
            doc=fitz.open();page=doc.new_page(width=image.width,height=image.height)
            page.insert_image(page.rect,stream=bio.getvalue())
            doc.save(folder/'work.pdf');doc.close();kind='image'
        with fitz.open(folder/'work.pdf') as doc:
            pages=[{'width':round(p.rect.width,5),'height':round(p.rect.height,5),'index':i} for i,p in enumerate(doc)]
    extra={'blocks':blocks,'polygons':polygons,'texts':texts,'warnings':warnings,'meterPerPoint':meter_per_point}
    (folder/'analysis-meta.json').write_text(json.dumps(extra,ensure_ascii=False),encoding='utf-8')
    return {'filename':filename,'kind':kind,'pages':pages,'sourceExtension':suffix,'warnings':warnings},meter_per_point


def convert_dxf(source,outfile):
    from ezdxf import bbox, units
    from ezdxf.addons.drawing import RenderContext, Frontend, layout, config, pymupdf
    from ezdxf.math import BoundingBox2d
    doc=ezdxf.readfile(source)
    model=doc.modelspace()
    audit=doc.audit()
    bb=bbox.extents(model,fast=True)
    if not bb.has_data:raise ValueError('Le DXF ne contient pas de geometrie exploitable dans l\u2019espace objet.')
    x0,y0=bb.extmin.x,bb.extmin.y;x1,y1=bb.extmax.x,bb.extmax.y
    width=max(x1-x0,1);height=max(y1-y0,1)
    scale=1160/max(width,height)
    w,h=width*scale+40,height*scale+40
    ctx=RenderContext(doc)
    cfg=config.Configuration(background_policy=config.BackgroundPolicy.WHITE, color_policy=config.ColorPolicy.COLOR)
    backend=pymupdf.PyMuPdfBackend()
    Frontend(ctx,backend,config=cfg).draw_layout(model,finalize=True)
    pdf=backend.get_pdf_bytes(layout.Page(w*25.4/72,h*25.4/72,margins=layout.Margins.all(20*25.4/72)),
        settings=layout.Settings(fit_page=True,page_alignment=layout.PageAlignment.MIDDLE_CENTER),render_box=BoundingBox2d([(x0,y0),(x1,y1)]))
    outfile.write_bytes(pdf)
    transform=lambda x,y:[(x-x0)*scale+20,(y1-y)*scale+20]
    blocks=[];polygons=[];warnings=[];texts=[]
    def collect(entities,depth=0):
        if depth>8:return
        for e in entities:
            if e.dxftype()=='INSERT':
                instances=list(e.multi_insert()) if e.mcount>1 else [e]
                for inst in instances:
                    eb=bbox.extents([inst],fast=True)
                    if eb.has_data:
                        pa=transform(eb.extmin.x,eb.extmax.y);pb=transform(eb.extmax.x,eb.extmin.y)
                        blocks.append({'name':inst.dxf.name,'layer':inst.dxf.layer,'x':(pa[0]+pb[0])/2,'y':(pa[1]+pb[1])/2,'w':max(.5,pb[0]-pa[0]),'h':max(.5,pb[1]-pa[1]),'page':0,'handle':e.dxf.get('handle','')})
                    try:collect(inst.virtual_entities(),depth+1)
                    except Exception:pass
            elif e.dxftype() in ('TEXT','MTEXT','ATTRIB','ATTDEF'):
                value=e.plain_text() if hasattr(e,'plain_text') else e.dxf.get('text','')
                eb=bbox.extents([e],fast=True)
                if value and eb.has_data:
                    pa=transform(eb.extmin.x,eb.extmax.y);pb=transform(eb.extmax.x,eb.extmin.y)
                    texts.append({'text':value,'x':pa[0],'y':pa[1],'w':pb[0]-pa[0],'h':pb[1]-pa[1],'page':0})
            elif e.dxftype()=='LWPOLYLINE' and e.closed:
                points=[transform(p[0],p[1]) for p in e.get_points()]
                if len(points)>=3 and polygon_area(points)>100:
                    polygons.append({'points':points,'layer':e.dxf.layer})
            elif e.dxftype()=='POLYLINE' and e.is_closed:
                points=[transform(v.dxf.location.x,v.dxf.location.y) for v in e.vertices]
                if len(points)>=3 and polygon_area(points)>100:polygons.append({'points':points,'layer':e.dxf.layer})
    collect(model)
    meter_per_point=None
    try:
        insunits=int(doc.header.get('$INSUNITS',0))
        if insunits:meter_per_point=units.conversion_factor(insunits,units.M)/scale
    except Exception:pass
    if audit.has_errors:warnings.append('Le DXF contient des anomalies signalees par son audit. Controlez le rendu.')
    warnings.append('DXF : espace objet uniquement. Xrefs externes non chargees ; verifier les blocs dynamiques et polices substituees.')
    return blocks,polygons,meter_per_point,warnings,texts


def render_png(folder,page_number,scale=1,clip=None):
    with PDF_LOCK:
        with fitz.open(folder/'work.pdf') as doc:
            page=doc.load_page(page_number)
            bounds=fitz.Rect(clip) if clip else page.rect
            bounds=bounds & page.rect
            if bounds.is_empty:raise ValueError('Zone de rendu vide.')
            
            if not math.isfinite(float(scale)) or float(scale)<=0:raise ValueError('Echelle de rendu invalide.')
            scale=min(float(scale),8,MAX_SIDE/max(bounds.width,bounds.height),math.sqrt(MAX_PIXELS/(bounds.width*bounds.height)))
            pix=page.get_pixmap(matrix=fitz.Matrix(scale,scale),clip=bounds,alpha=False,colorspace=fitz.csRGB)
            return pix.tobytes('png')


def render_tile(folder,page_number,scale,x,y):
    """Render a 512px tile from original vectors; coordinates are pixel-grid aligned."""
    global TILE_CACHE_BYTES
    if not math.isfinite(scale) or not .03125<=scale<=64:
        raise ValueError('Niveau de zoom invalide.')
    if x<0 or y<0 or x>100000 or y>100000:
        raise ValueError('Coordonnees de tuile invalides.')
    path=Path(folder)/'work.pdf'
    key=(str(path.resolve()),path.stat().st_mtime_ns,page_number,scale,x,y)
    with PDF_LOCK:
        if key in TILE_CACHE:
            TILE_CACHE.move_to_end(key);return TILE_CACHE[key]
        with fitz.open(path) as doc:
            page=doc.load_page(page_number)
            rect=fitz.Rect(x*TILE_SIZE/scale,y*TILE_SIZE/scale,
                          (x+1)*TILE_SIZE/scale,(y+1)*TILE_SIZE/scale)&page.rect
            if rect.is_empty:raise ValueError('Tuile hors de la page.')
            pix=page.get_pixmap(matrix=fitz.Matrix(scale,scale),clip=rect,
                                alpha=False,colorspace=fitz.csRGB)
            if pix.width>514 or pix.height>514:raise ValueError('Tuile hors limite.')
            data=pix.tobytes('png')
        TILE_CACHE[key]=data;TILE_CACHE_BYTES+=len(data)
        while TILE_CACHE_BYTES>TILE_CACHE_LIMIT or len(TILE_CACHE)>192:
            _,old=TILE_CACHE.popitem(last=False);TILE_CACHE_BYTES-=len(old)
        return data


def render_array(folder,page_number,scale=2):
    # Segmentation is bounded separately from display zoom and symbol matching.
    with PDF_LOCK:
        with fitz.open(Path(folder)/'work.pdf') as doc:
            page=doc.load_page(page_number);r=page.rect
            scale=min(scale,2000/max(r.width,r.height),math.sqrt(2_000_000/(r.width*r.height)))
            pix=page.get_pixmap(matrix=fitz.Matrix(scale,scale),alpha=False,colorspace=fitz.csRGB)
            arr=np.frombuffer(pix.samples_mv,np.uint8).reshape(pix.height,pix.width,3)
            arr=cv2.cvtColor(arr,cv2.COLOR_RGB2BGR)
            return arr,arr.shape[1]/r.width,arr.shape[0]/r.height


def _region_array(folder,page_number,scale,rect):
    # No PNG round trip and no full-page image for the matching engine.
    with PDF_LOCK:
        with fitz.open(Path(folder)/'work.pdf') as doc:
            page=doc.load_page(page_number);clip=fitz.Rect(rect)&page.rect
            if clip.is_empty:raise ValueError('Exemple hors du plan.')
            if clip.width*clip.height*scale*scale>2_200_000:
                raise ValueError('Zone de comparaison trop grande : choisissez un symbole plus petit.')
            pix=page.get_pixmap(matrix=fitz.Matrix(scale,scale),clip=clip,alpha=False,colorspace=fitz.csRGB)
            arr=np.frombuffer(pix.samples_mv,np.uint8).reshape(pix.height,pix.width,3)
            out=cv2.cvtColor(arr,cv2.COLOR_RGB2BGR)
            return out,pix.x,pix.y


def page_info(folder,page_number):
    extra=json.loads((folder/'analysis-meta.json').read_text(encoding='utf-8'))
    with PDF_LOCK:
        with fitz.open(folder/'work.pdf') as doc:
            page=doc[page_number]
            texts=[]
            for block in page.get_text('dict',flags=0).get('blocks',[]):
                for line in block.get('lines',[]):
                    text=' '.join(s['text'] for s in line['spans']).strip()
                    if text:
                        r=line['bbox'];texts.append({'text':text,'x':r[0],'y':r[1],'w':r[2]-r[0],'h':r[3]-r[1],'angle':math.atan2(line.get('dir',(1,0))[1],line.get('dir',(1,0))[0])})
            if not texts:texts=[t for t in extra.get('texts',[]) if t.get('page',0)==page_number]
            drawings=page.get_drawings()
            layers=sorted({str(d.get('layer')) for d in drawings if d.get('layer')})
            return {'width':page.rect.width,'height':page.rect.height,'textCount':len(texts),'texts':texts[:12000],
                    'vectorCount':len(drawings),'layers':layers,'blocks':[b for b in extra['blocks'] if b['page']==page_number],
                    'hasRaster':bool(page.get_images()),'warnings':extra.get('warnings',[])}


def _primitive_records(page):
    records=[]
    for path in page.get_drawings():
        group=[];types=[]
        def flush():
            if len(group)<2:return
            a=np.array(group,dtype=np.float64)
            x0,y0=a.min(axis=0);x1,y1=a.max(axis=0)
            w,h=float(x1-x0),float(y1-y0)
            if max(w,h)<.3:return
            records.append({'x':float((x0+x1)/2),'y':float((y0+y1)/2),'w':w,'h':h,'key':''.join(types),'color':path.get('color'),'bbox':[float(x0),float(y0),float(x1),float(y1)]})
        for item in path['items']:
            typ=item[0]
            if typ=='re':
                flush();group=[];types=[]
                r=item[1]
                records.append({'x':(r.x0+r.x1)/2,'y':(r.y0+r.y1)/2,'w':r.width,'h':r.height,'key':'re','color':path.get('color'),'bbox':[r.x0,r.y0,r.x1,r.y1]})
                continue
            if typ=='qu':
                pts=[tuple(p) for p in (item[1].ul,item[1].ur,item[1].lr,item[1].ll,item[1].ul)]
            elif typ=='l':pts=[tuple(item[1]),tuple(item[2])]
            elif typ=='c':
                p0,p1,p2,p3=[np.array(tuple(p)) for p in item[1:]]
                pts=[tuple((1-t)**3*p0+3*(1-t)**2*t*p1+3*(1-t)*t*t*p2+t**3*p3) for t in np.linspace(0,1,9)]
            else:continue
            if group and distance(group[-1],pts[0])>.05:flush();group=[];types=[]
            group.extend(pts);types.append(typ)
            if len(group)>2 and distance(group[0],group[-1])<.05:
                flush();group=[];types=[]
        flush()
    return records


def _vector_candidates(folder,page_number,source_rect,limit=6000):
    x,y,w,h=source_rect
    with PDF_LOCK:
        with fitz.open(folder/'work.pdf') as doc:records=_primitive_records(doc[page_number])
    selected=[r for r in records if r['bbox'][0]>=x-.15 and r['bbox'][1]>=y-.15 and r['bbox'][2]<=x+w+.15 and r['bbox'][3]<=y+h+.15]
    if not selected or len(selected)>50:return []
    selected.sort(key=lambda r:r['w']*r['h'],reverse=True)
    anchor=selected[0]
    if min(anchor['w'],anchor['h'])<.1:return []
    candidates=[]
    centers=np.array([[r['x'],r['y']] for r in records])
    for candidate in records:
        if candidate['key']!=anchor['key'] or min(candidate['w'],candidate['h'])<.1:continue
        for rot in (0,90,180,270):
            swap=rot in (90,270)
            tw,th=(anchor['h'],anchor['w']) if swap else (anchor['w'],anchor['h'])
            sc=(candidate['w']/tw+candidate['h']/th)/2
            if not .35<=sc<=3 or abs(candidate['w']/tw-candidate['h']/th)>sc*.12:continue
            rad=math.radians(rot);cs,sn=math.cos(rad),math.sin(rad)
            def trans(px,py):
                dx,dy=px-anchor['x'],py-anchor['y']
                return [candidate['x']+sc*(cs*dx-sn*dy),candidate['y']+sc*(sn*dx+cs*dy)]
            success=True
            for r in selected[1:]:
                pred=trans(r['x'],r['y']);radius=max(.65,sc*max(w,h)*.06)
                ids=np.where(np.sum((centers-pred)**2,axis=1)<radius*radius)[0]
                rw,rh=(r['h'],r['w']) if swap else (r['w'],r['h'])
                if not any(records[i]['key']==r['key'] and abs(records[i]['w']-rw*sc)<max(.6,rw*sc*.15) and abs(records[i]['h']-rh*sc)<max(.6,rh*sc*.15) for i in ids):
                    success=False;break
            if success:
                cx,cy=trans(x+w/2,y+h/2)
                cw,ch=(h if swap else w)*sc,(w if swap else h)*sc
                contained=[r for r in records if r['bbox'][0]>=cx-cw/2-.15 and r['bbox'][1]>=cy-ch/2-.15 and r['bbox'][2]<=cx+cw/2+.15 and r['bbox'][3]<=cy+ch/2+.15]
                if len(contained)>len(selected):continue
                candidates.append({'x':cx,'y':cy,'w':cw,'h':ch,'rotation':rot,'scale':sc})
        if len(candidates)>limit:break
    return candidates



def _label_geometry_candidates(folder,project,legend,page_number,threshold):
    """A repeated CAD code is only a locator: the adjacent geometry is checked.
    This handles drawing/legend scale differences without counting bare text.
    """
    source=legend.get('source',{});rect=source.get('rect')
    if not rect:return []
    x,y,w,h=rect;center=[x+w/2,y+h/2]
    source_info=page_info(folder,source['page'])
    tags=[t for t in source_info['texts'] if re.fullmatch(r'[A-Z]{1,4}[0-9]{1,3}',t['text'].strip()) and distance(center,[t['x']+t['w']/2,t['y']+t['h']/2])<max(12,max(w,h)*1.4)]
    if legend.get('code'):tags=[t for t in tags if t['text'].strip()==legend['code']]
    if not tags:return []
    ref=min(tags,key=lambda t:distance(center,[t['x']+t['w']/2,t['y']+t['h']/2]))
    with PDF_LOCK:
        with fitz.open(folder/'work.pdf') as doc:
            source_records=_primitive_records(doc[source['page']])
            records=source_records if source['page']==page_number else _primitive_records(doc[page_number])
    anchors=[r for r in source_records if r['bbox'][0]>=x-.15 and r['bbox'][1]>=y-.15 and r['bbox'][2]<=x+w+.15 and r['bbox'][3]<=y+h+.15 and ('c' in r['key'] or r['key']=='re') and min(r['w'],r['h'])>.4]
    if not anchors:return []
    anchor=max(anchors,key=lambda r:r['w']*r['h']);ref_center=[ref['x']+ref['w']/2,ref['y']+ref['h']/2]
    compatible=[r for r in records if r['key']==anchor['key']]
    target_info=source_info if source['page']==page_number else page_info(folder,page_number)
    found=[]
    for text in target_info['texts']:
        if text['text'].strip()!=ref['text'].strip():continue
        sc=math.hypot(text['w'],text['h'])/max(.1,math.hypot(ref['w'],ref['h']))
        if not .2<sc<10:continue
        angle=text.get('angle',0)-ref.get('angle',0);cs,sn=math.cos(angle),math.sin(angle)
        def projected(pt):
            dx,dy=pt[0]-ref_center[0],pt[1]-ref_center[1]
            return [text['x']+text['w']/2+sc*(cs*dx-sn*dy),text['y']+text['h']/2+sc*(sn*dx+cs*dy)]
        pred=projected([anchor['x'],anchor['y']]);swap=abs(sn)>.7
        aw,ah=(anchor['h'],anchor['w']) if swap else (anchor['w'],anchor['h']);aw*=sc;ah*=sc
        matches=[]
        for r in compatible:
            pos=distance(pred,[r['x'],r['y']]);size=max(abs(r['w']-aw)/max(aw,.2),abs(r['h']-ah)/max(ah,.2))
            color_error=0
            if r.get('color') and anchor.get('color'):color_error=max(abs(a-b) for a,b in zip(r['color'],anchor['color']))
            if pos<max(4*sc,max(aw,ah)*2) and size<.18 and color_error<.15:
                score=1-size*.6-min(.035,pos/max(10*sc,1)*.035)
                if score>=threshold:matches.append((score,r))
        if matches:
            score,matched=max(matches,key=lambda v:v[0]);cx,cy=projected(center)
            cx+=matched['x']-pred[0];cy+=matched['y']-pred[1]
            found.append({'x':cx,'y':cy,'w':(h if swap else w)*sc,'h':(w if swap else h)*sc,'score':min(1,score),'rotation':round(math.degrees(angle))%360,'method':'repere texte '+ref['text'].strip()+' + geometrie verifiee'})
    return found


def detect_symbols(folder,project,legend,page_number,threshold=.88,progress=None,cancel=None):
    """Bounded raster tiles; vector candidates remain verified against the drawing."""
    progress=progress or (lambda *args:None)
    started=time.monotonic()
    def check():
        if cancel and cancel.is_set():raise InterruptedError('Analyse annulee. Resultats termines conserves.')
        if time.monotonic()-started>240:
            raise ValueError('Recherche trop longue. Limitez les rotations ou choisissez un exemple plus distinctif. Les resultats precedents sont conserves.')
    check();source=legend.get('source')
    extra=json.loads((Path(folder)/'analysis-meta.json').read_text(encoding='utf-8'))
    if legend.get('blockName'):
        found=[dict(x=b['x'],y=b['y'],w=b['w'],h=b['h'],score=1.,method='bloc DXF',layer=b.get('layer','')) for b in extra['blocks'] if b['name']==legend['blockName'] and b['page']==page_number]
        return found,{'method':'bloc DXF','raw':len(found),'threshold':1}
    if not source or not source.get('rect'):raise ValueError('Encadrez un exemple du symbole avant la recherche.')
    x,y,w,h=source['rect']
    if not all(math.isfinite(v) for v in (x,y,w,h)) or min(w,h)<1.6:
        raise ValueError('Exemple trop petit : encadrez un symbole complet, puis relancez sa recherche.')
    scale=min(2.5,400/max(w,h))
    template,_,_=_region_array(folder,source['page'],scale,[x,y,x+w,y+h])
    if min(template.shape[:2])<5:raise ValueError('Exemple trop petit : encadrez un symbole complet.')
    ink=cv2.cvtColor(template,cv2.COLOR_BGR2GRAY)<220
    if np.count_nonzero(ink)<6 or float(template.std())<4:
        raise ValueError('La selection est vide ou ne contient pas de symbole suffisamment contraste.')
    progress('Verification des motifs vectoriels',.05)
    candidates=_label_geometry_candidates(folder,project,legend,page_number,threshold) if project['document']['kind']!='image' and legend.get('method')!='image' else []
    check()
    if source['page']==page_number and project['document']['kind']!='image' and legend.get('method')!='image':
        for c in _vector_candidates(folder,page_number,source['rect']):
            check();rotation=c['rotation'];t=np.rot90(template,-rotation//90).copy()
            try:
                patch,_,_=_region_array(folder,page_number,scale,[c['x']-c['w']/2,c['y']-c['h']/2,c['x']+c['w']/2,c['y']+c['h']/2])
            except ValueError:continue
            if min(patch.shape[:2])<4:continue
            patch=cv2.resize(patch,(t.shape[1],t.shape[0]),interpolation=cv2.INTER_AREA)
            score=float(cv2.matchTemplate(patch,t,cv2.TM_CCOEFF_NORMED)[0,0])
            mask=cv2.cvtColor(t,cv2.COLOR_BGR2GRAY)<210
            if np.count_nonzero(mask)>5:
                ink_error=np.abs(patch.astype(np.float32)-t.astype(np.float32)).mean(axis=2)[mask].mean()/255
                score=max(score,1-float(ink_error)*2.5)
            if math.isfinite(score) and score>=threshold:
                candidates.append(dict(c,score=min(1,max(0,score)),method='motif vectoriel verifie'))
    raster_tiles=0
    if not candidates or legend.get('method')=='image':
        dims=project['document']['pages'][page_number]
        pw=math.ceil(dims['width']*scale);ph=math.ceil(dims['height']*scale)
        core=768;nx=math.ceil(pw/core);ny=math.ceil(ph/core)
        rotations=[0,90,180,270] if legend.get('rotations',True) else [0]
        scales=[.8,1.,1.25] if legend.get('multiScale',True) else [1.]
        variants=[]
        for rotation in rotations:
            for sc in scales:
                t=np.rot90(template,-rotation//90).copy()
                if sc!=1:t=cv2.resize(t,None,fx=sc,fy=sc,interpolation=cv2.INTER_AREA)
                if min(t.shape[:2])>=5:variants.append((rotation,t))
        halo=max(max(t.shape[:2]) for _,t in variants)-1 if variants else 0
        for iy in range(ny):
            for ix in range(nx):
                check();px=ix*core;py=iy*core
                image,ox,oy=_region_array(folder,page_number,scale,[px/scale,py/scale,min(pw,px+core+halo)/scale,min(ph,py+core+halo)/scale])
                for rotation,t in variants:
                    check();th,tw=t.shape[:2]
                    if th>image.shape[0] or tw>image.shape[1]:continue
                    result=cv2.matchTemplate(image,t,cv2.TM_CCOEFF_NORMED)
                    maxima=cv2.dilate(result,np.ones((max(3,th//2)|1,max(3,tw//2)|1),np.uint8))
                    mask=(result>=threshold)&(result>=maxima-1e-6)
                    # A start pixel belongs to only one core tile, never both overlaps.
                    mask[core:,:]=False;mask[:,core:]=False
                    yy,xx=np.where(mask)
                    if len(xx)+len(candidates)>15000:
                        raise ValueError('Trop de correspondances : choisissez un exemple plus distinctif ou augmentez le seuil.')
                    for a,b in zip(xx,yy):
                        candidates.append({'x':float((ox+a+tw/2)/scale),'y':float((oy+b+th/2)/scale),'w':tw/scale,'h':th/scale,'score':float(result[b,a]),'method':'comparaison graphique par tuiles','rotation':rotation})
                    del result,maxima,mask
                raster_tiles+=1
                progress('Comparaison graphique par portions',.2+.73*raster_tiles/max(1,nx*ny))
                del image
    check();dedup=[]
    for c in sorted(candidates,key=lambda q:q['score'],reverse=True):
        if any(distance([c['x'],c['y']],[p['x'],p['y']])<max(2,min(c['w'],c['h'],p['w'],p['h'])*.5) for p in dedup):continue
        dedup.append(c)
        if len(dedup)>5000:raise ValueError('Plus de 5 000 correspondances : affinez l’exemple.')
    progress('Preparation des propositions',.97)
    return dedup,{'method':'motifs verifies et comparaison par portions','raw':len(dedup),'threshold':threshold,'tiles':raster_tiles,'seconds':round(time.monotonic()-started,3)}


ROOM_NAMES=re.compile(r'\b(chambre|bedroom|suite|salon|sejour|s\u00e9jour|living|cuisine|kitchen|bureau|office|dressing|sdb|sde|bath|bains?|wc|toilet|entree|entr\u00e9e|couloir|hall|cellier|buanderie|local|garage|terrasse|degagement|d\u00e9gagement)\b',re.I)

def propose_rooms(folder,page_number,project):
    info=page_info(folder,page_number)
    labels=[t for t in info['texts'] if ROOM_NAMES.search(t['text']) and len(t['text'])<65 and t['w']<info['width']*.35 and not is_excluded([t['x']+t['w']/2,t['y']+t['h']/2],page_number,project) and not re.search(r'spot|ruban|applique|prise|commande|porte|sous wc|volume',t['text'],re.I)]
    if not labels:return [],'Aucun nom de piece exploitable. Dessinez les pieces manuellement ; aucun OCR n\u2019est lance.'
    extra=json.loads((folder/'analysis-meta.json').read_text(encoding='utf-8'))
    candidates=[]
    for t in labels:
        p=[t['x']+t['w']/2,t['y']+t['h']/2]
        polys=[v['points'] for v in extra['polygons'] if inside(p,v['points']) and polygon_area(v['points'])>info['width']*info['height']*.001]
        if polys:candidates.append((t,min(polys,key=polygon_area)))
    if not candidates:
        image,sx,sy=render_array(folder,page_number,1.5)
        gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
        # Architectural neutral strokes, not red/green/blue electrical annotations.
        neutral=(image.max(axis=2).astype(np.int16)-image.min(axis=2).astype(np.int16))<35
        mask=((gray<175)&neutral).astype(np.uint8)*255
        k=max(13,round(min(image.shape[:2])*.012))
        horizontal=cv2.morphologyEx(mask,cv2.MORPH_OPEN,np.ones((1,k),np.uint8))
        vertical=cv2.morphologyEx(mask,cv2.MORPH_OPEN,np.ones((k,1),np.uint8))
        walls=cv2.bitwise_or(horizontal,vertical)
        gap=max(9,round(min(image.shape[:2])*.018))|1
        walls=cv2.morphologyEx(walls,cv2.MORPH_CLOSE,np.ones((gap,gap),np.uint8))
        walls=cv2.dilate(walls,np.ones((3,3),np.uint8))
        free=(walls==0).astype(np.uint8)
        count,components,stats,centers=cv2.connectedComponentsWithStats(free,8)
        used=set()
        for t in labels:
            x=int((t['x']+t['w']/2)*sx);y=int((t['y']+t['h']/2)*sy)
            x=max(0,min(image.shape[1]-1,x));y=max(0,min(image.shape[0]-1,y))
            component=int(components[y,x])
            if component==0:
                nearby=components[max(0,y-12):y+13,max(0,x-12):x+13];vals=nearby[nearby>0]
                if not vals.size:continue
                component=int(np.bincount(vals).argmax())
            if component in used:continue
            bx,by,bw,bh,area=stats[component]
            if bx==0 or by==0 or bx+bw>=image.shape[1] or by+bh>=image.shape[0]:continue
            if not image.shape[0]*image.shape[1]*.001<area<image.shape[0]*image.shape[1]*.45:continue
            contour,_=cv2.findContours((components==component).astype(np.uint8),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
            if not contour:continue
            shape=max(contour,key=cv2.contourArea)
            points=cv2.approxPolyDP(shape,max(2,cv2.arcLength(shape,True)*.004),True).reshape(-1,2)
            poly=[[round(float(px)/sx,3),round(float(py)/sy,3)] for px,py in points]
            if len(poly)<3 or len(poly)>80:continue
            candidates.append((t,poly));used.add(component)
    palette=['#3d70c9','#d5a626','#39877a','#9b78bc','#d77855','#557ca0']
    result=[]
    existing=[z for z in project['zones'] if z['page']==page_number and z.get('type','room')=='room']
    for t,poly in candidates:
        center=[t['x']+t['w']/2,t['y']+t['h']/2]
        if any(inside(center,z['points']) for z in existing):continue
        result.append({'id':uid(),'name':t['text'],'page':page_number,'points':poly,'parentId':None,'type':'room','confirmed':False,'color':palette[len(result)%len(palette)],'source':'proposition geometrique'})
    return result,'Contours proposes a verifier : les portes ouvertes, meubles, textes et cloisons peuvent modifier la segmentation.'


def propose_legend(folder,page_number,rect):
    """Propositions de lignes: noms du PDF et motifs proches, toujours editables."""
    x,y,w,h=rect
    info=page_info(folder,page_number)
    labels=[t for t in info['texts'] if x<=t['x']<=x+w and y<=t['y']<=y+h and len(t['text'])>2 and not re.search(r'legende|l\u00e9gende|reference|r\u00e9f\u00e9rence|symbole|exemple|designation|d\u00e9signation',t['text'],re.I)]
    with PDF_LOCK:
        with fitz.open(folder/'work.pdf') as doc:records=_primitive_records(doc[page_number])
    records=[r for r in records if x<=r['x']<=x+w and y<=r['y']<=y+h and .3<max(r['w'],r['h'])<min(80,w*.3) and (min(r['w'],r['h'])>.12 or max(r['w'],r['h'])<12)]
    if labels:
        minimum_height=float(np.percentile([t['h'] for t in labels],70))*.79
        labels=[t for t in labels if t['h']>=minimum_height and t['w']>t['h']*1.6 and not re.match(r'^T[0-9]+(?: |$)',t['text'])]
    rows=[];used=[]
    palette=['#da2936','#285fbd','#228964','#8660af','#d99022','#597b91']
    for t in sorted(labels,key=lambda z:(z['y'],z['x'])):
        ty=t['y']+t['h']/2
        nearby=[r for r in records if 3<t['x']-r['x']<min(110,w*.5) and abs(r['y']-ty)<max(9,t['h']*1.2)]
        if not nearby:continue
        anchor=min(nearby,key=lambda r:abs(r['y']-ty)*3+(t['x']-r['x'])*.25)
        if any(distance([anchor['x'],anchor['y']],p)<8 for p in used):continue
        radius=max(4,anchor['w']*.8,anchor['h']*.8)
        group=[r for r in records if abs(r['x']-anchor['x'])<radius and abs(r['y']-anchor['y'])<radius and r['x']+r['w']/2<t['x']-2]
        if not group:continue
        x0=min(r['bbox'][0] for r in group);y0=min(r['bbox'][1] for r in group)
        x1=max(r['bbox'][2] for r in group);y1=max(r['bbox'][3] for r in group)
        pad=max(.5,min(3,max(x1-x0,y1-y0)*.2))
        x0-=pad;y0-=pad;x1+=pad;y1+=pad
        name=t['text'];family='autre'
        if re.search(r'spot|luminaire|eclairage|\u00e9clairage|applique|ruban|suspension|projecteur',name,re.I):family='eclairage'
        elif re.search(r'rj45|reseau|r\u00e9seau|data',name,re.I):family='reseau'
        elif re.search(r'commande|interrupteur|poussoir|knx|bus',name,re.I):family='commande'
        elif re.search(r'prise|2p|pc ',name,re.I):family='prise'
        elif re.search(r'alimentation|sortie.*cable|sortie.*c\u00e2ble',name,re.I):family='alimentation'
        rows.append({'id':uid(),'name':name,'family':family,'color':palette[len(rows)%len(palette)],'source':{'page':page_number,'rect':[x0,y0,x1-x0,y1-y0],'excludeFromCount':True},'method':'auto','rotations':True,'multiScale':True,'proposed':True})
        used.append([anchor['x'],anchor['y']])
        if len(rows)>=100:break
    return rows
