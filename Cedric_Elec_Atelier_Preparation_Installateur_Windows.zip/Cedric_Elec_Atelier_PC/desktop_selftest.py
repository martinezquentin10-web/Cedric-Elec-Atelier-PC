"""Essai du moteur embarque; ne remplace pas un essai visuel de Windows."""
from __future__ import annotations
import http.cookiejar
import json
from pathlib import Path
import tempfile
import time
import urllib.error
import urllib.request


def run():
    import app
    from desktop_server import DesktopRuntime
    checks = {}
    with tempfile.TemporaryDirectory(prefix='ce-bureau-test-') as temporary:
        root = Path(temporary) / 'Projets'
        with_runtime = DesktopRuntime(root).start()
        try:
            cookies = http.cookiejar.CookieJar()
            client = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cookies))
            client.open(with_runtime.url, timeout=45).read()
            def request(path, body=None):
                data = json.dumps(body).encode('utf-8') if body is not None else None
                req = urllib.request.Request(with_runtime.origin + path, data=data,
                      headers={'Content-Type': 'application/json', 'X-CE-Token': app.TOKEN})
                with client.open(req, timeout=100) as response:
                    raw = response.read()
                    return json.loads(raw) if 'application/json' in response.headers.get('Content-Type', '') else raw
            checks['local_only'] = request('/api/health')['localOnly'] is True
            project = request('/api/demo', {})
            identifier = project['id']
            checks['demo_imported'] = len(project['legend']) == 4
            job = request(f'/api/projects/{identifier}/analyze', {'page': 0})['jobId']
            limit = time.monotonic() + 100
            while time.monotonic() < limit:
                state = request('/api/jobs/' + job)
                if state['status'] != 'running':
                    break
                time.sleep(.15)
            project = request('/api/projects/' + identifier)
            checks['analysis_done'] = state['status'] == 'done'
            checks['31_positions'] = len(project['elements']) == 31
            png = request(f'/api/projects/{identifier}/tile?page=0&scale=16&x=5&y=5')
            checks['hd_tile'] = png.startswith(b'\x89PNG\r\n\x1a\n')
            pdf = request(f'/api/projects/{identifier}/export?kind=pdf')
            checks['pdf_export'] = pdf.startswith(b'%PDF-')
            project['name'] = 'Brouillon non confirme'
            with_runtime.store.checkpoint(project, 1, 'self-test', True)
            recovered = with_runtime.store.recover(identifier)
            checks['recovered_as_copy'] = recovered['id'] != identifier and recovered['name'].startswith('Brouillon non confirme')
            checks['original_untouched'] = with_runtime.store.load(identifier)['name'] != 'Brouillon non confirme'
        finally:
            with_runtime.close()
        from desktop_store import DesktopStore
        reopened = DesktopStore(root)
        checks['disk_reopen'] = len(reopened.load(identifier)['elements']) == 31
        checks['draft_reopen'] = any(r['id'] == identifier for r in reopened.recovery_list())
    return {'ok': all(checks.values()), 'checks': checks,
            'guiValidated': False, 'note': 'Moteur et HTTP locaux uniquement; la fenetre native et l\u2019installateur restent a verifier sur Windows.'}
