#!/usr/bin/env python3
"""Cedric Elec Atelier - application locale independante, version 0.1.0.
Lancer : python app.py. Pas de cle API, pas de compte, pas de telemetrie.
"""
from __future__ import annotations
import argparse
import base64
import copy
import json
import logging
import mimetypes
import os
import re
import secrets
import socket
import sys
import threading
import time
import urllib.parse
import webbrowser
from concurrent.futures import ThreadPoolExecutor
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path

from storage import Store,LOCK,RevisionConflict
from geometry import uid,merge_detections,generate_circuits,assign_rooms
from engine import render_tile,render_png,page_info,detect_symbols,propose_rooms,propose_legend
from exports import export_csv,export_pdf,export_svg
from demo import create_demo,legend_items

ROOT=Path(__file__).resolve().parent
VERSION='0.1.2-stabilisation'
MAX_BODY=145*1024*1024
TOKEN=secrets.token_urlsafe(32)
JOBS={};JOBS_LOCK=threading.Lock()
EXECUTOR=ThreadPoolExecutor(max_workers=1,thread_name_prefix='analyse-locale')
STORE=None
HEAVY_GATE=threading.Lock()


def run_analysis(job_id,identifier,page,legend_ids,threshold):
    job=JOBS[job_id]
    try:
        project=STORE.load(identifier);legends=[l for l in project['legend'] if l['id'] in legend_ids]
        if not legends:raise ValueError('Ajoutez ou selectionnez un symbole dans la legende.')
        total=0;occupied=0;methods=[];warnings=[]
        for n,legend in enumerate(legends):
            def progress(label,value):
                job.update(message=legend['name']+' : '+label,progress=(n+value)/len(legends))
            if job['cancel'].is_set():raise InterruptedError('Analyse annulee. Les resultats deja termines sont conserves.')
            try:
                with HEAVY_GATE:
                    detections,report=detect_symbols(STORE.folder(identifier),project,legend,page,threshold,progress,job['cancel'])
            except ValueError as exc:
                warnings.append(legend['name']+' : '+str(exc))
                job.update(message=warnings[-1],progress=(n+1)/len(legends))
                continue
            with LOCK:
                current=STORE.load(identifier)
                # A removed legend must not be resurrected by a late-running analysis.
                latest_legend=next((l for l in current['legend'] if l['id']==legend['id']),None)
                if not latest_legend or any(latest_legend.get(k)!=legend.get(k) for k in ('source','blockName','rotations','multiScale','method')):continue
                added,overlap=merge_detections(current,legend['id'],page,detections)
                current=STORE.write(current)
            total+=added;occupied+=overlap;methods.append(report)
        job.update(status='done' if methods else 'error',progress=1,message=f'{total} propositions a verifier.'+(' '+str(len(warnings))+' symbole(s) a recadrer.' if warnings else ''),result={'added':total,'occupied':occupied,'methods':methods,'warnings':warnings})
    except InterruptedError as exc:job.update(status='cancelled',message=str(exc))
    except Exception as exc:
        logging.exception('Analyse interrompue')
        job.update(status='error',message=str(exc))


class Handler(BaseHTTPRequestHandler):
    server_version='CedricElecAtelier/0.1'
    def log_message(self,fmt,*args):
        logging.debug(fmt,*args)
    def _send(self,status,body,kind='application/json; charset=utf-8',download=None):
        if not isinstance(body,bytes):body=json.dumps(body,ensure_ascii=False,allow_nan=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type',kind)
        self.send_header('Content-Length',str(len(body)))
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer')
        self.send_header('Cache-Control','no-store')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        if download:self.send_header('Content-Disposition',"attachment; filename*=UTF-8''"+urllib.parse.quote(download))
        self.end_headers()
        try:self.wfile.write(body)
        except (BrokenPipeError,ConnectionResetError):pass
    def _safe_origin(self):
        port=self.server.server_port
        host=self.headers.get('Host','')
        allowed={f'127.0.0.1:{port}',f'localhost:{port}'}
        if host not in allowed:raise PermissionError('Hote refuse. Ouvrez l\u2019adresse locale affichee au lancement.')
        origin=self.headers.get('Origin')
        if origin and origin not in {'http://'+h for h in allowed}:raise PermissionError('Origine externe refusee.')
        if self.headers.get('Sec-Fetch-Site')=='cross-site':raise PermissionError('Requete externe refusee.')
    def _body(self):
        self._safe_origin()
        if self.headers.get('X-CE-Token')!=TOKEN:raise PermissionError('Session invalide. Rechargez la page.')
        length=int(self.headers.get('Content-Length','0'))
        if not 0<length<=MAX_BODY:raise ValueError('Requete vide ou trop volumineuse.')
        if 'application/json' not in self.headers.get('Content-Type',''):raise ValueError('Une requete JSON est attendue.')
        return json.loads(self.rfile.read(length))
    def _dispatch_error(self,exc):
        if isinstance(exc,RevisionConflict):self._send(409,{'error':str(exc),'conflict':True})
        elif isinstance(exc,PermissionError):self._send(403,{'error':str(exc)})
        elif isinstance(exc,FileNotFoundError):self._send(404,{'error':str(exc)})
        elif isinstance(exc,(ValueError,KeyError,IndexError,TypeError)):self._send(400,{'error':str(exc)})
        else:
            logging.exception('Erreur de requete')
            self._send(500,{'error':'Le traitement a echoue : '+str(exc)[:300]})
    def do_GET(self):
        # Heavy operations cannot pile up behind concurrent requests.
        path=urllib.parse.urlsplit(self.path).path
        heavy=path.endswith('/export') or path.endswith('/page')
        if heavy and not HEAVY_GATE.acquire(blocking=False):
            return self._send(429,{'error':'Une analyse est en cours. Attendez sa fin avant cette operation.','retryable':True})
        try:return self._do_GET()
        finally:
            if heavy:HEAVY_GATE.release()
    def _do_GET(self):
        try:
            self._safe_origin()
            url=urllib.parse.urlsplit(self.path);path=url.path;q=urllib.parse.parse_qs(url.query)
            if path=='/api/health':return self._send(200,{'ok':True,'version':VERSION,'dataDirectory':str(STORE.root),'localOnly':True})
            if path=='/api/projects':return self._send(200,{'projects':STORE.list()})
            m=re.fullmatch(r'/api/jobs/([a-f0-9]{32})',path)
            if m:
                job=JOBS.get(m[1])
                if not job:raise FileNotFoundError('Analyse introuvable.')
                return self._send(200,{k:v for k,v in job.items() if k!='cancel'})
            m=re.fullmatch(r'/api/projects/([a-f0-9]{32})(?:/(\w+))?',path)
            if m:
                identifier,action=m.groups();p=STORE.load(identifier);folder=STORE.folder(identifier)
                page=int(q.get('page',['0'])[0])
                if not 0<=page<len(p['document']['pages']):raise ValueError('Page invalide.')
                if not action:return self._send(200,p)
                if action=='page':return self._send(200,page_info(folder,page))
                if action=='tile':
                    scale=float(q.get('scale',['1'])[0]);x=int(q.get('x',['0'])[0]);y=int(q.get('y',['0'])[0])
                    return self._send(200,render_tile(folder,page,scale,x,y),'image/png')
                if action in ('render','crop'):
                    scale=float(q.get('scale',['1'])[0]);clip=None
                    if action=='crop':
                        r=[float(n) for n in q.get('rect',[''])[0].split(',')]
                        if len(r)!=4:raise ValueError('Rectangle invalide.')
                        clip=[r[0],r[1],r[0]+r[2],r[1]+r[3]];scale=4
                    return self._send(200,render_png(folder,page,scale,clip),'image/png')
                if action=='export':
                    kind=q.get('kind',['project'])[0];safe=re.sub(r'[^a-zA-Z0-9_-]+','_',p['name'])[:70] or 'chantier'
                    if kind=='project':return self._send(200,STORE.archive(identifier),'application/zip',safe+f"_r{p['revision']}.ceprojet")
                    if kind=='pdf':return self._send(200,export_pdf(folder,p),'application/pdf',safe+'_annote.pdf')
                    if kind=='csv':return self._send(200,export_csv(p),'text/csv; charset=utf-8',safe+'_quantites.csv')
                    if kind=='svg':return self._send(200,export_svg(folder,p,page),'image/svg+xml',safe+f'_page{page+1}_editable.svg')
                    raise ValueError('Export non reconnu.')
                raise FileNotFoundError('Action inconnue.')
            if path=='/':
                html=(ROOT/'static/index.html').read_text(encoding='utf-8').replace('__CE_SESSION__',TOKEN)
                return self._send(200,html.encode('utf-8'),'text/html; charset=utf-8')
            if path.startswith('/static/'):
                relative=urllib.parse.unquote(path[len('/static/'):]);file=(ROOT/'static'/relative).resolve()
                if ROOT/'static' not in file.parents:raise PermissionError('Chemin refuse.')
                if not file.is_file():raise FileNotFoundError('Ressource introuvable.')
                return self._send(200,file.read_bytes(),mimetypes.guess_type(str(file))[0] or 'application/octet-stream')
            raise FileNotFoundError('Page introuvable.')
        except Exception as exc:self._dispatch_error(exc)
    def do_POST(self):
        path=urllib.parse.urlsplit(self.path).path
        heavy=path in ('/api/import','/api/restore','/api/demo') or path.endswith(('/rooms','/legend','/circuits'))
        if heavy and not HEAVY_GATE.acquire(blocking=False):
            return self._send(429,{'error':'Une autre operation utilise le moteur. Attendez sa fin, puis reessayez.','retryable':True})
        try:return self._do_POST()
        finally:
            if heavy:HEAVY_GATE.release()
    def _do_POST(self):
        try:
            path=urllib.parse.urlsplit(self.path).path;body=self._body()
            if path=='/api/import':
                raw=base64.b64decode(body['data'],validate=True)
                p=STORE.create(Path(body['filename']).name,raw,body.get('name'))
                return self._send(201,p)
            if path=='/api/restore':return self._send(201,STORE.restore(base64.b64decode(body['data'],validate=True)))
            if path=='/api/demo':
                demo=ROOT/'examples/maison-exemple.pdf'
                if not demo.exists():
                    demo.parent.mkdir(exist_ok=True);create_demo(demo)
                p=STORE.create('Maison-exemple.pdf',demo.read_bytes(),'Maison exemple - Demonstration')
                p['legend']=legend_items();p['demo']=True;p['scales']={'0':.01}
                p['zones']=[{'id':uid(),'page':0,'name':'Legende hors comptage','points':[[940,65],[1170,65],[1170,650],[940,650]],'type':'exclude','confirmed':True,'parentId':None,'color':'#94a3b8'}]
                return self._send(201,STORE.write(p))
            m=re.fullmatch(r'/api/jobs/([a-f0-9]{32})/cancel',path)
            if m:
                job=JOBS.get(m[1])
                if job:job['cancel'].set()
                return self._send(200,{'ok':True})
            m=re.fullmatch(r'/api/projects/([a-f0-9]{32})(?:/(\w+))?',path)
            if not m:raise FileNotFoundError('Action inconnue.')
            identifier,action=m.groups()
            if not action:
                current=STORE.load(identifier);p=body['project']
                if p.get('id')!=identifier:raise ValueError('Identifiants de projet differents.')
                p['document']=current['document'];p['createdAt']=current['createdAt']
                return self._send(200,STORE.write(p,expected=body.get('revision')))
            page=int(body.get('page',0));p=STORE.load(identifier)
            if not 0<=page<len(p['document']['pages']):raise ValueError('Page invalide.')
            if action=='analyze':
                threshold=max(.65,min(.99,float(body.get('threshold',.88))))
                with JOBS_LOCK:
                    if any(j['status']=='running' for j in JOBS.values()):raise ValueError('Une analyse est deja en cours. Attendez sa fin avant une nouvelle recherche.')
                    for old in list(JOBS)[:-20]:
                        if JOBS[old]['status']!='running':JOBS.pop(old,None)
                    job_id=uid();JOBS[job_id]={'id':job_id,'projectId':identifier,'status':'running','progress':0,'message':'Preparation','cancel':threading.Event()}
                    EXECUTOR.submit(run_analysis,job_id,identifier,page,body.get('legendIds',[l['id'] for l in p['legend']]),threshold)
                return self._send(202,{'jobId':job_id})
            if action=='rooms':
                proposed,message=propose_rooms(STORE.folder(identifier),page,p)
                with LOCK:
                    latest=STORE.load(identifier);latest['zones'].extend(proposed);latest=STORE.write(latest)
                return self._send(200,{'project':latest,'count':len(proposed),'message':message})
            if action=='legend':
                rect=body['rect']
                if len(rect)!=4 or min(rect[2:])<=0:raise ValueError('Cadre de legende invalide.')
                items=propose_legend(STORE.folder(identifier),page,rect)
                with LOCK:
                    latest=STORE.load(identifier);latest['legend'].extend(items)
                    x,y,w,h=rect
                    latest['zones'].append({'id':uid(),'name':'Legende hors comptage','page':page,'points':[[x,y],[x+w,y],[x+w,y+h],[x,y+h]],'type':'exclude','confirmed':True,'parentId':None,'color':'#94a3b8'})
                    latest=STORE.write(latest)
                return self._send(200,{'project':latest,'count':len(items)})
            if action=='circuits':
                with LOCK:
                    p=STORE.load(identifier);report=generate_circuits(p,page,body['targetId'],body.get('passageId'));p=STORE.write(p)
                return self._send(200,{'project':p,'report':report})
            raise FileNotFoundError('Action inconnue.')
        except Exception as exc:self._dispatch_error(exc)


def main():
    global STORE
    parser=argparse.ArgumentParser(description='Cedric Elec Atelier - application locale')
    parser.add_argument('--port',type=int,default=8765)
    parser.add_argument('--data-dir',default=os.environ.get('CE_DATA_HOME',str(Path.home()/'CedricElecAtelier'/'Projets')))
    parser.add_argument('--no-browser',action='store_true')
    args=parser.parse_args();STORE=Store(args.data_dir)
    logging.basicConfig(filename=STORE.root.parent/'atelier.log',level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    server=None
    for port in range(args.port,args.port+15):
        try:server=ThreadingHTTPServer(('127.0.0.1',port),Handler);break
        except OSError:continue
    if server is None:raise RuntimeError('Aucun port local libre. Fermez une autre instance du logiciel.')
    server.daemon_threads=True
    url=f'http://127.0.0.1:{server.server_port}'
    print('\nCEDRIC ELEC ATELIER - VERSION LOCALE 0.1.0',flush=True)
    print('Adresse : '+url,flush=True)
    print('Projets : '+str(STORE.root),flush=True)
    print('Gardez cette fenetre ouverte. Ctrl+C pour fermer le logiciel.\n',flush=True)
    if not args.no_browser:threading.Timer(.7,lambda:webbrowser.open(url)).start()
    try:server.serve_forever(poll_interval=.3)
    except KeyboardInterrupt:pass
    finally:
        for j in JOBS.values():j['cancel'].set()
        server.server_close();EXECUTOR.shutdown(wait=False,cancel_futures=True)

if __name__=='__main__':main()
