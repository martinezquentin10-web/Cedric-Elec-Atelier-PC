# Cedric Elec Atelier 0.1.2 - stabilisation, 11 octobre 2026

Cette version conserve le parcours et l'interface de l'application neuve 0.1.0. L'ancien site n'est pas remplace.

## Changements

- Affichage PDF : fond leger et tuiles de 512 pixels, rendu depuis les vecteurs d'origine, adaptation au zoom et a la densite d'ecran. Deux requetes simultanees au maximum, abandon des rendus devenus inutiles, cache serveur limite a 12 Mo / 192 tuiles et cache navigateur a 80 tuiles.
- Analyse : comparaison graphique par portions de 768 pixels avec recouvrement pour les symboles qui traversent une limite. Plus de grand tableau de comparaison sur toute la page. Segmentation des pieces limitee a 2 millions de pixels. Une analyse globale a la fois. Les exemples invalides sont signales et les autres familles peuvent terminer.
- Secours : copie du plan source et des modifications dans IndexedDB; bouton de recuperation dans le meme navigateur. Export .ceprojet du dernier brouillon meme quand la sauvegarde serveur echoue, a condition que le plan source ait deja ete copie. Les etats incomplets et erreurs de quota sont signales.
- Reprise : restauration vers un nouveau chantier, sans ecraser l'existant. Renouvellement du jeton anti-CSRF apres redemarrage si le cookie d'acces prive est toujours valide.
- Hebergement de test : cloud.py exige une cle privee dans CE_ACCESS_KEY, utilise un cookie HttpOnly/SameSite et controle les origines. Les sources sont accessibles aux utilisateurs autorises via /sources.zip. Aucun secret n'est inclus dans cette archive de source.

## Ce qui n'est PAS resolu par ce correctif

Il ne s'agit pas d'une synchronisation cloud durable, d'un compte individuel ou d'une sauvegarde externe automatique. Render Free reste temporaire, avec veille et quotas. Une copie de navigateur peut etre supprimee en effacant les donnees du site ou en navigation privee; elle ne se retrouve pas automatiquement sur un autre appareil ou une autre adresse de site. Le navigateur peut refuser la conservation persistante. Exporter regulierement un .ceprojet dans un emplacement sauvegarde reste necessaire.

Les comptages, contours et traces doivent etre controles. La lecture du DWG direct reste absente. Un scan ne gagne pas de details inexistants par le zoom.

## Validation realisee

- 52 tests Python reussis, dont les 36 precedents et 16 nouveaux cas de stabilisation.
- 15 controles HTTP du point d'entree cloud : refus d'acces, origine externe, CSRF, imports/restauration, rendu en tuiles et sources sans cle privee.
- Test de calcul sur un PDF prive de 24 508 objets graphiques : 48 tuiles au facteur 16 et proposition de pieces; pic RSS du processus observe de 251,8 Mio. Cela ne constitue pas un plafond garanti ni un test de charge multi-utilisateurs. Les pieces n'ont pas ete trouvees automatiquement sur ce plan.
- Interface testee dans Chromium via un harnais en memoire : serveur HTTP local reel appele par une liaison de test; stockage IndexedDB simule. Parcours maison exemple (31 elements), zoom a 1 181 %, archive contenant le dernier brouillon, restauration apres suppression du chantier sur le serveur et vue 390 x 844 sans debordement horizontal. Aucune erreur JavaScript relevee sur ce parcours.
- La navigation native du navigateur de test est bloquee dans cet environnement. La persistance IndexedDB dans un vrai navigateur apres fermeture complete, la navigation HTTPS externe et les appareils Windows/iOS/Android ne sont PAS valides par le harnais. Ces points demandent un essai utilisateur reel.

## Publication

Le service d'essai existant reste intact. La version est preparee pour un service de test distinct, plan explicitement free, auto-deploiement desactive. Aucun abonnement, base payante ou disque payant n'est active. Les anciennes donnees ne sont pas copiees automatiquement vers une nouvelle origine : exporter puis ouvrir le .ceprojet.
