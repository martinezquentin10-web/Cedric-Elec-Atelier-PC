# Licences et composants tiers

Le logiciel utilise des bibliothèques de lecture et traitement de plans : réécrire l'application ne signifie pas réécrire les moteurs PDF ou DXF. Aucun code de l'ancien logiciel Cédric Elec n'a été repris.

| Composant | Version testée | Licence de la distribution utilisée |
|---|---|---|
| PyMuPDF / MuPDF | 1.26.7 | GNU AGPL v3, voir texte fourni |
| ezdxf | 1.4.4 | MIT |
| NumPy | 2.3.5 | BSD et mentions de composants intégrés |
| opencv-python-headless | 4.13.0.92 | Mentions Apache 2.0 / distribution et tiers, voir textes fournis |
| Pillow | 12.3.0 | MIT-CMU et mentions incluses |

Les avis issus des distributions installées sont reproduits dans `docs/licences`. Les bibliothèques elles-mêmes ne sont pas embarquées dans le ZIP : le premier lancement installe les versions fixées par `requirements.txt`. Leurs propres sources et licences restent disponibles par leurs distributions respectives.

Le code source nouveau de l'application est fourni sous GNU AGPL v3 ou ultérieure, voir `LICENSE`. Le code n'est pas une garantie d'absence de défauts et ne constitue pas une validation technique d'installation. Pour un service réseau ou une redistribution, respecter les obligations de communication du code source correspondant et les autres conditions de chaque licence. Aucune licence commerciale tierce n'est incluse ou achetée.

Le logo, le nom de l'entreprise et ses signes distinctifs restent ceux de Cédric Elec ; leur insertion pour son logiciel n'accorde pas une autorisation générale d'utilisation de sa marque. Les plans et données utilisateur ne sont pas placés sous licence libre du seul fait de leur import.
