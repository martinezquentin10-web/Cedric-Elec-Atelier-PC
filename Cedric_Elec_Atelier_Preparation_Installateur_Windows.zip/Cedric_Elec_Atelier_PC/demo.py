"""Plan pedagogique genere par le logiciel, sans donnees de client."""
from pathlib import Path
import pymupdf as fitz

COLORS={'spot':(0.85,.16,.18),'prise':(.12,.33,.77),'commande':(.10,.57,.39),'rj45':(.52,.29,.70)}
ROOMS=[('Sejour',[60,70,470,350]),('Cuisine',[550,70,350,250]),('Chambre 1',[60,440,380,280]),('Entree',[460,440,190,280]),('Salle de bains',[670,340,230,180]),('Cellier',[670,540,230,180])]
POINTS={'spot':[(170,170),(380,170),(170,310),(380,310),(650,140),(800,140),(650,250),(800,250),(170,540),(330,640),(770,410),(550,570),(780,620)],
        'prise':[(100,240),(490,240),(290,385),(580,130),(860,280),(100,620),(400,510),(620,680),(700,680)],
        'commande':[(495,375),(580,280),(400,685),(490,690),(700,485),(700,560)],
        'rj45':[(100,320),(100,675),(860,680)]}
LEGEND=[('spot','Spot encastre','eclairage','#da2936',130),('prise','Prise 16 A','prise','#285fbd',230),('commande','Commande BUS','commande','#228964',330),('rj45','Prise RJ45','reseau','#8660af',430)]


def draw_symbol(page,kind,x,y):
    color=COLORS[kind]
    if kind=='spot':
        page.draw_circle((x,y),7,color=color,width=1.3)
        page.draw_circle((x,y),1.8,color=color,fill=color,width=.7)
    elif kind=='prise':
        page.draw_rect(fitz.Rect(x-7,y-7,x+7,y+7),color=color,width=1.3)
        for dx in (-2.5,2.5):page.draw_circle((x+dx,y),.9,color=color,fill=color,width=.6)
        page.draw_line((x,y+3),(x,y+5),color=color,width=1)
    elif kind=='commande':
        page.draw_circle((x,y),6,color=color,width=1.3)
        page.draw_line((x,y),(x+8,y-8),color=color,width=1.3)
    else:
        page.draw_rect(fitz.Rect(x-6,y-6,x+6,y+6),color=color,width=1.3)
        page.draw_line((x-3,y-3),(x+3,y+3),color=color,width=1.1)
        page.draw_line((x-3,y+3),(x+3,y-3),color=color,width=1.1)


def create_demo(path:Path):
    doc=fitz.open();page=doc.new_page(width=1200,height=820)
    page.insert_text((60,36),'MAISON EXEMPLE  /  REZ-DE-CHAUSSEE',fontsize=16,color=(.16,.23,.34))
    page.insert_text((60,54),'Plan pedagogique - symboles et quantites connus - ne pas utiliser pour une installation',fontsize=9,color=(.40,.45,.52))
    gray=(.23,.26,.29);furniture=(.69,.71,.73)
    for name,(x,y,w,h) in ROOMS:
        page.draw_rect(fitz.Rect(x,y,x+w,y+h),color=gray,width=6)
        page.insert_text((x+20,y+30),name.upper(),fontsize=12,color=(.32,.37,.44))
    # Furniture drawn lightly, without altering the electrical symbols.
    for r in [(215,180,310,285),(75,90,440,120),(80,460,270,600),(90,470,160,490),(175,470,245,490),(820,355,880,395),(840,420,880,490),(575,88,875,110),(755,190,845,230),(705,575,735,660)]:
        page.draw_rect(fitz.Rect(*r),color=furniture,width=.7)
    for kind,points in POINTS.items():
        for x,y in points:draw_symbol(page,kind,x,y)
    page.draw_rect(fitz.Rect(847,605,873,635),color=(.25,.30,.36),fill=(.94,.95,.96),width=1)
    page.insert_text((825,653),'TABLEAU',fontsize=8,color=(.30,.34,.40))
    page.draw_rect(fitz.Rect(945,70,1165,540),color=(.8,.83,.87),width=.7)
    page.insert_text((965,95),'LEGENDE DU CHANTIER',fontsize=11,color=(.18,.27,.46))
    for kind,name,family,color,y in LEGEND:
        draw_symbol(page,kind,980,y)
        page.insert_text((1000,y+4),name,fontsize=11,color=(.25,.29,.35))
        page.insert_text((965,y+29),f'Exemple de reference / {family}',fontsize=8,color=(.5,.54,.59))
    page.insert_text((945,580),'Les commandes sont sur un BUS distinct.',fontsize=9,color=(.25,.30,.38))
    page.insert_text((945,600),'13 spots / 9 prises / 6 commandes / 3 RJ45',fontsize=9,color=(.25,.30,.38))
    page.draw_line((60,760),(900,760),color=(.4,.45,.52),width=.6)
    for x in (60,900):page.draw_line((x,750),(x,770),color=(.4,.45,.52),width=.6)
    page.insert_text((455,778),'8,40 m',fontsize=11,color=(.3,.36,.43))
    page.insert_text((60,806),'CEDRIC ELEC ATELIER  |  DEMONSTRATION  |  Les quantites affichees sont des donnees de test.',fontsize=8,color=(.4,.46,.52))
    doc.save(path,deflate=True);doc.close()


def legend_items():
    from geometry import uid
    return [{'id':uid(),'name':name,'family':family,'color':color,'source':{'page':0,'rect':[968,y-12,24,24]},'rotations':True,'multiScale':True,'method':'auto'} for _,name,family,color,y in LEGEND]
