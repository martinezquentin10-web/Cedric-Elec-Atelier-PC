; Construction Windows uniquement. Ne touche pas aux projets utilisateur.
#define AppVersion "0.2.0"
#define AppName "Cedric Elec Atelier"
[Setup]
AppId={{843269E7-8B09-4D68-ADE2-A6E97BFF027D}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher=Cedric Elec
DefaultDirName={localappdata}\Programs\CedricElecAtelier
DefaultGroupName=Cedric Elec Atelier
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
OutputDir=..\dist-installateur
OutputBaseFilename=Cedric-Elec-Atelier-Installation-0.2.0-alpha
SetupIconFile=cedric-elec.ico
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\CedricElecAtelier.exe
CloseApplications=yes
RestartApplications=no
LicenseFile=..\LICENSE
#ifdef SIGNTOOLNAME
SignTool={#SIGNTOOLNAME}
SignedUninstaller=yes
#endif
[Languages]
Name: "french"; MessagesFile: "compiler:Languages\French.isl"
[Files]
Source: "..\dist\CedricElecAtelier\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
[Icons]
Name: "{userdesktop}\Cedric Elec Atelier"; Filename: "{app}\CedricElecAtelier.exe"; WorkingDir: "{app}"
Name: "{group}\Cedric Elec Atelier"; Filename: "{app}\CedricElecAtelier.exe"; WorkingDir: "{app}"
Name: "{group}\Desinstaller Cedric Elec Atelier"; Filename: "{uninstallexe}"
[Run]
Filename: "{app}\CedricElecAtelier.exe"; Description: "Ouvrir Cedric Elec Atelier"; Flags: nowait postinstall skipifsilent
; Aucun UninstallDelete : les chantiers de l'utilisateur restent sur le disque.
