# Windows only. Build using packaging/build-windows.ps1.
from pathlib import Path
from PyInstaller.utils.hooks import collect_all
root = Path(SPECPATH).parent
datas = [(str(root/'static'), 'static'), (str(root/'examples'), 'examples'),
         (str(root/'LICENSE'), '.'), (str(root/'THIRD_PARTY_NOTICES.md'), '.'),
         (str(root/'packaging'/'sources-bureau.zip'), 'sources')]
binaries = []
hidden = ['desktop_workers', 'desktop_selftest', 'webview.platforms.winforms',
          'webview.platforms.edgechromium', 'clr', 'pythonnet', 'clr_loader']
for package in ['webview', 'clr_loader']:
    package_data, package_bin, package_hidden = collect_all(package)
    datas += package_data
    binaries += package_bin
    hidden += package_hidden
a = Analysis([str(root/'desktop_main.py')], pathex=[str(root)],
    binaries=binaries, datas=datas, hiddenimports=hidden,
    excludes=['PyQt5', 'PyQt6', 'PySide2', 'PySide6', 'webview.platforms.gtk', 'webview.platforms.qt'])
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name='CedricElecAtelier',
          console=False, debug=False, strip=False, upx=False,
          icon=str(root/'packaging'/'cedric-elec.ico'))
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name='CedricElecAtelier')
