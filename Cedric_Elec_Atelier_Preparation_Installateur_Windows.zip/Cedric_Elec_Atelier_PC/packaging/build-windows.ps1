# Script de fabrication pour developpeur, PAS un lanceur utilisateur.
$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT') { throw 'La fabrication doit etre effectuee sous Windows.' }
Set-Location (Split-Path $PSScriptRoot -Parent)
python -c "import struct,sys; assert sys.platform=='win32' and struct.calcsize('P')==8, 'Python Windows 64 bits requis'"
if ($LASTEXITCODE -ne 0) { throw 'Python Windows 64 bits requis.' }
python -m venv .venv-build
$py = Join-Path (Get-Location) '.venv-build\Scripts\python.exe'
& $py -m pip install -r requirements-desktop.txt
if ($LASTEXITCODE -ne 0) { throw 'Dependances non installees.' }
& $py -m pip freeze | Out-File -Encoding utf8 packaging\versions-fabrication.txt
& $py -m pytest -q
if ($LASTEXITCODE -ne 0) { throw 'Les tests doivent reussir avant la fabrication.' }
& $py packaging\prepare-assets.py
if ($LASTEXITCODE -ne 0) { throw 'Preparation des ressources impossible.' }
& $py -m PyInstaller --noconfirm --clean packaging\desktop.spec
if ($LASTEXITCODE -ne 0) { throw 'Fabrication du programme impossible.' }
$result = Join-Path (Get-Location) 'packaging\resultat-executable.json'
Remove-Item $result -ErrorAction SilentlyContinue
$binary = Join-Path (Get-Location) 'dist\CedricElecAtelier\CedricElecAtelier.exe'
$process = Start-Process -FilePath $binary -ArgumentList "--self-test --result `"$result`"" -PassThru
if (-not $process.WaitForExit(240000)) { $process.Kill(); throw 'Essai de l executable trop long.' }
if ($process.ExitCode -ne 0 -or -not (Test-Path $result)) { throw 'Essai du moteur embarque echoue.' }
$report = Get-Content $result -Raw | ConvertFrom-Json
if (-not $report.ok) { throw 'Un controle de l executable a echoue.' }
$isccCommand = Get-Command ISCC.exe -ErrorAction SilentlyContinue
$isccPath = if ($isccCommand) { $isccCommand.Source } else { $null }
if (-not $isccPath) {
    $candidate = "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe"
    if (Test-Path $candidate) { $isccPath = $candidate }
}
if (-not $isccPath) { throw 'Installer Inno Setup sur le poste de fabrication, puis relancer.' }
& $isccPath packaging\installer.iss
if ($LASTEXITCODE -ne 0) { throw 'Fabrication de l installateur impossible.' }
Get-FileHash dist-installateur\*.exe -Algorithm SHA256 | Format-List | Out-File -Encoding utf8 dist-installateur\SHA256.txt
Write-Host 'Installateur alpha construit. Signature et essais visuels sur Windows encore requis avant validation.'
