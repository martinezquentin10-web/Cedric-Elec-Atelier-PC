"""Prepare les ressources et les sources correspondantes avant PyInstaller."""
from pathlib import Path
import sys
import zipfile
root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))
from PIL import Image
from demo import create_demo
(root/'examples').mkdir(exist_ok=True)
if not (root/'examples'/'maison-exemple.pdf').exists():
    create_demo(root/'examples'/'maison-exemple.pdf')
logo = Image.open(root/'static'/'logo.png').convert('RGBA')
canvas = Image.new('RGBA',(256,256),'white')
logo.thumbnail((236,236))
canvas.alpha_composite(logo,((256-logo.width)//2,(256-logo.height)//2))
canvas.save(root/'packaging'/'cedric-elec.ico',sizes=[(16,16),(32,32),(48,48),(64,64),(128,128),(256,256)])
with zipfile.ZipFile(root/'packaging'/'sources-bureau.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in root.rglob('*'):
        if not p.is_file() or any(part in {'.venv-build','__pycache__','.pytest_cache','dist','build','dist-installateur'} for part in p.relative_to(root).parts):
            continue
        if p.suffix.lower() in {'.ttf','.otf','.woff','.woff2','.pyc','.zip','.exe'}:
            continue
        if p.name in {'versions-fabrication.txt','resultat-executable.json'}:
            continue
        z.write(p,p.relative_to(root))
