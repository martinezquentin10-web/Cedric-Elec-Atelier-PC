"""Private test entrypoint. Secret supplied ONLY by environment, never in source.
No permanent server storage on Render Free. Browser backup is a recovery copy,
not a replacement for external backups or multi-device synchronisation.
"""
from __future__ import annotations
import hashlib,hmac,json,logging,os,secrets,threading,time,urllib.parse,io,zipfile
from http.cookies import SimpleCookie
from http.server import ThreadingHTTPServer
import app
from storage import Store

ACCESS_KEY=os.environ.get('CE_ACCESS_KEY','')
if len(ACCESS_KEY)<32:
    raise RuntimeError('CE_ACCESS_KEY must be a private random value of at least 32 characters.')
COOKIE_VALUE=hmac.new(ACCESS_KEY.encode(),b'ce-atelier-private-session-v1',hashlib.sha256).hexdigest()
HOST=os.environ.get('RENDER_EXTERNAL_HOSTNAME','')
LOCAL_TEST=os.environ.get('CE_LOCAL_TEST')=='1'
app.MAX_BODY=31*1024*1024

LOGIN='''<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Cedric Elec - Acces prive</title><style>body{background:#f0f4f8;font:16px system-ui;color:#243552;display:grid;place-items:center;min-height:90vh}main{background:white;padding:36px;border-radius:20px;max-width:470px;box-shadow:0 10px 35px #22334418}img{width:76px}button{background:#315496;color:white;border:0;padding:14px 20px;border-radius:9px;cursor:pointer}input{display:block;box-sizing:border-box;width:100%;padding:12px;margin:16px 0}p{line-height:1.6}#msg{color:#a34035}</style><main><img src="/static/logo.png" alt="Cedric Elec"><h1>Votre atelier de plans</h1><p>Version de test 0.1.2. Ouvrez votre lien personnel pour entrer.</p><form id="f"><label>Cle d'acces privee<input id="k" type="password" autocomplete="off" required></label><button>Ouvrir l'atelier</button></form><p id="msg"></p><small>Ne partagez pas votre lien prive. Les fichiers sont traites sur le serveur d'essai, pas uniquement sur cet ordinateur.</small></main><script>
async function enter(key){const r=await fetch('/access',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key})});if(!r.ok){document.querySelector('#msg').textContent='Acces refuse. Utilisez votre lien prive.';return;}location.replace('/');}
document.querySelector('#f').onsubmit=e=>{e.preventDefault();enter(document.querySelector('#k').value).catch(()=>document.querySelector('#msg').textContent='Connexion interrompue. Reessayez.');};
const key=new URLSearchParams(location.hash.slice(1)).get('cle');if(key){history.replaceState(null,'','/');enter(key).catch(()=>document.querySelector('#msg').textContent='Le serveur redemarre. Rechargez votre lien personnel.');}
</script></html>'''

class CloudHandler(app.Handler):
    def _safe_origin(self):
        host=self.headers.get('Host','')
        allowed={HOST} if HOST else set()
        if LOCAL_TEST:allowed|={f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}'}
        if host not in allowed:raise PermissionError('Hote non autorise.')
        origin=self.headers.get('Origin')
        permitted={'https://'+h for h in allowed}
        if LOCAL_TEST:permitted|={'http://'+h for h in allowed}
        if origin and origin not in permitted:raise PermissionError('Origine non autorisee.')
        if self.headers.get('Sec-Fetch-Site')=='cross-site':raise PermissionError('Requete externe refusee.')
    def authenticated(self):
        try:
            cookie=SimpleCookie();cookie.load(self.headers.get('Cookie',''))
            value=cookie.get('ce_session')
            return bool(value) and hmac.compare_digest(value.value,COOKIE_VALUE)
        except Exception:return False
    def do_GET(self):
        try:
            self._safe_origin();path=urllib.parse.urlsplit(self.path).path
            if path=='/api/health':
                return self._send(200,{'ok':True,'version':app.VERSION,'cloud':True,'temporaryServerStorage':True,'maxUploadMB':20})
            if path=='/static/logo.png':return super().do_GET()
            if not self.authenticated():
                if path=='/':return self._send(200,LOGIN.encode(),'text/html; charset=utf-8')
                return self._send(401,{'error':'Acces prive requis. Ouvrez votre lien personnel.'})
            if path=='/api/session':return self._send(200,{'token':app.TOKEN})
            if path=='/sources.zip':
                buf=io.BytesIO()
                with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
                    paths=list(app.ROOT.glob('*.py'))+list(app.ROOT.glob('*.md'))+list(app.ROOT.glob('requirements*.txt'))+[app.ROOT/'LICENSE']
                    paths+=list((app.ROOT/'static').glob('*'))+list((app.ROOT/'tests').glob('*.py'))+list((app.ROOT/'docs/licences').glob('*.txt'))
                    for p in paths:
                        if p.is_file():z.write(p,str(p.relative_to(app.ROOT)))
                return self._send(200,buf.getvalue(),'application/zip','Cedric_Elec_Atelier_0.1.2_sources.zip')
            if path=='/':
                html=(app.ROOT/'static/index.html').read_text().replace('__CE_SESSION__',app.TOKEN)
                html=html.replace("window.CE_SESSION=", "window.CE_CLOUD=true;window.CE_SESSION=")
                return self._send(200,html.encode(),'text/html; charset=utf-8')
            return super().do_GET()
        except Exception as exc:self._dispatch_error(exc)
    def do_POST(self):
        try:
            self._safe_origin();path=urllib.parse.urlsplit(self.path).path
            if path=='/access':
                length=int(self.headers.get('Content-Length','0'))
                if not 0<length<1024:raise ValueError('Requete invalide.')
                key=json.loads(self.rfile.read(length)).get('key','')
                if not isinstance(key,str) or not hmac.compare_digest(key,ACCESS_KEY):
                    time.sleep(.2);return self._send(403,{'error':'Acces refuse.'})
                data=b'{"ok":true}';self.send_response(200)
                self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)))
                self.send_header('Set-Cookie','ce_session='+COOKIE_VALUE+'; HttpOnly; SameSite=Strict; Path=/; Max-Age=604800'+('' if LOCAL_TEST else '; Secure'))
                self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(data);return
            if not self.authenticated():return self._send(401,{'error':'Acces prive requis.'})
            return super().do_POST()
        except Exception as exc:self._dispatch_error(exc)
    def _body(self):
        body=super()._body()
        if urllib.parse.urlsplit(self.path).path in ('/api/import','/api/restore'):
            if len(body.get('data',''))>28*1024*1024:
                raise ValueError('Import limite a 20 Mo pour cette version de test.')
        return body

def main():
    app.STORE=Store(os.environ.get('CE_DATA_HOME','/tmp/cedric-elec-stabilisation/Projets'))
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    server=ThreadingHTTPServer(('127.0.0.1' if LOCAL_TEST else '0.0.0.0',int(os.environ.get('PORT','10000'))),CloudHandler)
    server.daemon_threads=True
    print('Cedric Elec Atelier '+app.VERSION+' ready; private access; bounded tiles; temporary server storage.',flush=True)
    server.serve_forever(poll_interval=.3)

if __name__=='__main__':main()
