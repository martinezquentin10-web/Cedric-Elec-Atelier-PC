# Cédric Elec Atelier PC — avancement et validation

**11 octobre 2026 · source 0.2.0 alpha · pas d’installateur produit**

## État réel

L’entrée de bureau et les fichiers de fabrication Windows sont écrits.
Le moteur fonctionne dans les essais locaux décrits ci-dessous.
Aucun exécutable Windows n’a été fabriqué, lancé ou signé pendant ce travail.
Aucun changement n’a été publié sur Render, GitHub ou l’ancien site.
Aucun service de fabrication payant ni nouvelle dépense n’a été activé.

## Modifications

**Calculs isolés.** Deux processus distincts, l’un pour l’affichage et l’autre pour l’analyse.
Chaque processus travaille sur une demande à la fois. Le code PDF n’est plus appelé directement
par les threads HTTP de l’entrée bureau. Une panne de processus, une annulation ou un délai dépassé
produit une erreur contrôlée. Le calcul suivant peut recréer le processus sans redémarrer l’application.
Les résultats déjà enregistrés ne sont pas effacés par ce mécanisme.
Cela ne garantit pas l’absence de panne du système complet, de manque de mémoire global ou de bogue de l’interface.

**Brouillons sur disque.** Écriture temporaire, vidage des tampons et remplacement atomique.
Les sessions ont des fichiers distincts afin de ne pas remplacer silencieusement d’anciennes modifications non confirmées.
Les brouillons récupérés deviennent de nouveaux projets.
Ce mécanisme ne remplace pas une sauvegarde sur un autre disque et ne synchronise pas plusieurs PC.

**Fenêtre native préparée.** Ouverture de l’interface locale dans pywebview, dialogues de sauvegarde limités
aux fichiers de projet et exports, protection du lancement local, journal tournant et demande de sauvegarde avant fermeture.
Le code est préparé mais l’affichage Windows et les interactions réelles avec Edge WebView2 ne sont pas validés.

**Zoom.** Le rendu par tuiles depuis le PDF, ajouté en 0.1.2, est conservé.
Un test compare les octets de la même tuile rendue directement et via le processus isolé : ils sont identiques.
Un scan ne gagne pas de détails inexistants.

## Résultats obtenus

| Essai | Résultat | Périmètre |
|---|---|---|
| Suite Python complète | 79 tests réussis en 28,49 s | Linux, Python 3.13.5 ; 52 tests de la base et 27 tests de bureau |
| JavaScript du pont natif | 4 tests réussis | Node.js ; API native et DOM simulés, pas de fenêtre Windows |
| Parcours intégré du moteur local | 10 contrôles réussis | Vrai HTTP de boucle locale, fichiers temporaires et vrais processus de calcul |

Les tests de bureau incluent un arrêt brutal volontaire d’un processus factice,
un délai dépassé, l’annulation avant et pendant une tâche, la recréation du processus,
la conservation de brouillons de deux sessions, la récupération non destructive,
le refus des chemins de traversée, des origines externes et d’un accès local sans cookie.

Le parcours intégré importe la maison exemple, recherche réellement ses 31 équipements,
génère une tuile HD, exporte un PDF, récupère un brouillon dans un projet distinct,
vérifie que l’original est intact, ferme le moteur puis rouvre le stockage disque.
Il ne s’agit ni d’un essai sur tous les plans réels ni d’une validation de l’installation électrique.

## Travail restant avant un premier installateur

La fabrication PyInstaller et Inno Setup doit être exécutée sous Windows.
Les composants natifs Windows et leur installation doivent être vérifiés, en particulier Edge WebView2.
Le programme et l’installateur n’ont pas de signature vérifiée ici.
Les essais restant à effectuer concernent le premier lancement sur un PC Windows neuf,
les dialogues de fichiers, la fermeture avec modifications, les gros PDF, le zoom prolongé,
les mises à jour et la conservation des chantiers après désinstallation/réinstallation.

La capacité d’ouvrir une fenêtre native Windows n’est pas disponible dans cet environnement Linux.
Les téléchargements tentés pour obtenir les composants de fabrication n’ont pas abouti.
Aucune fabrication GitHub Actions n’a été déclenchée : son coût n’a pas été autorisé ou vérifié.

## Sources techniques consultées

- PyMuPDF, multiprocessing : https://pymupdf.readthedocs.io/en/latest/recipes-multiprocessing.html
- pywebview, API de fenêtre et persistance : https://pywebview.flowrl.com/api/
- pywebview, préparation d’exécutables : https://pywebview.flowrl.com/guide/freezing
- PyInstaller, contraintes de plateforme : https://pypi.org/project/pyinstaller/

Ces documentations justifient les choix d’architecture ; elles ne valident pas ce logiciel.
