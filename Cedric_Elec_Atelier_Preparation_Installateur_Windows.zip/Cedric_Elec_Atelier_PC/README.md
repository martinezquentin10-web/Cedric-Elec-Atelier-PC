# Cédric Elec Atelier PC — 0.2.0 alpha

**Dossier de code source. Ce n’est pas un installateur Windows.**

La fenêtre native est préparée dans `desktop_main.py` avec pywebview.
Le moteur et l’interface restent ceux du nouvel Atelier, avec le logo fourni,
le zoom par tuiles de la version 0.1.2 et les mêmes formats de projets.
Aucun appel au site Render n’est nécessaire au fonctionnement de cette entrée.

## Stabilisation ajoutée

- Les traitements PDF sont exécutés dans des processus distincts et sériels, pas dans les fils d’exécution HTTP. Le rendu et l’analyse ont chacun leur processus.
- Annulation et délai maximal de calcul ; un processus interrompu est recréé à la prochaine demande. Les résultats de familles déjà terminées restent enregistrés par le processus principal.
- Brouillons sur disque, distincts par session. Une nouvelle ouverture ne doit pas effacer le brouillon non confirmé d’une ancienne session.
- Récupération vers un nouveau projet sans écraser l’original.
- Fermeture précédée d’une tentative de sauvegarde ; en cas d’erreur, la fenêtre reste ouverte.
- Protection de l’accès local par cookie de lancement et contrôle de l’origine des appels natifs.

## Données

Les projets sont séparés de l’installation :
`C:\Users\UTILISATEUR\CedricElecAtelier\Projets`.
Les dossiers voisins `Brouillons` et `Journaux` contiennent les brouillons et les journaux tournants.
Ils ne sont pas supprimés par la configuration de désinstallation.
Ces fichiers ne sont pas chiffrés par l’application. Les copier sur un autre support reste nécessaire contre une panne du disque.

## Fabrication — poste d’intégration Windows uniquement

`packaging/build-windows.ps1` prépare un environnement, exécute les tests,
construit le programme avec PyInstaller, lance un autotest du moteur embarqué,
puis demande à Inno Setup de produire l’installateur.
Ce script est destiné au poste de fabrication, pas à Quentin.
Il n’a pas été exécuté sous Windows dans cette livraison.

La fenêtre Windows utilise Microsoft Edge WebView2. Sa présence, la compatibilité des composants .NET,
les dialogues natifs, la signature du programme et de l’installateur, et le comportement du Contrôle intelligent
 des applications doivent être validés sur Windows avant livraison d’un installateur utilisable.
Aucune protection Windows ne doit être désactivée pour essayer ce code.

## Validation effectuée

Voir `VALIDATION_BUREAU.md`. Le moteur a été testé sous Linux avec Python 3.13.5.
Les tests JavaScript simulent le pont natif ; ce ne sont pas des essais de la fenêtre Windows.
La reconnaissance graphique et les pièces restent des aides à contrôler. Aucun dimensionnement ni validation réglementaire.

## Licence

Conservation de la licence AGPL-3.0 de la base livrée et des notices des composants.
Les ressources de code correspondantes sont prévues dans le paquet fabriqué.
Le logo appartient à son titulaire. Aucun plan privé de chantier ni clé d’accès Render n’est inclus.
