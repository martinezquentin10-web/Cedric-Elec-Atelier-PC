"""Lanceur de bureau; entree PyInstaller Windows, jamais acces Render."""
from __future__ import annotations
import argparse
import json
import logging
from logging.handlers import RotatingFileHandler
import multiprocessing
import os
from pathlib import Path
import sys
import tempfile


def main():
    # Child processes are diverted by freeze_support before importing GUI code.
    for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
        os.environ[name] = '1'
    parser = argparse.ArgumentParser(description='Cedric Elec Atelier - Bureau')
    parser.add_argument('--self-test', action='store_true')
    parser.add_argument('--result')
    parser.add_argument('--data-dir')
    args = parser.parse_args()
    if args.self_test:
        from desktop_selftest import run
        report = run()
        if args.result:
            Path(args.result).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        return 0 if report.get('ok') else 1
    root = Path(args.data_dir) if args.data_dir else Path.home() / 'CedricElecAtelier' / 'Projets'
    root.mkdir(parents=True, exist_ok=True)
    logs = root.parent / 'Journaux'
    logs.mkdir(exist_ok=True)
    logging.basicConfig(level=logging.INFO,
        handlers=[RotatingFileHandler(logs / 'bureau.log', maxBytes=2_000_000, backupCount=4, encoding='utf-8')],
        format='%(asctime)s %(levelname)s %(message)s')
    # Lock is outside the program installation folder, stable across upgrades.
    lock_handle = (root.parent / 'bureau.lock').open('a+b')
    if os.name == 'nt':
        import msvcrt
        lock_handle.seek(0)
        if not lock_handle.read(1):
            lock_handle.write(b'0'); lock_handle.flush()
        lock_handle.seek(0)
        try:
            msvcrt.locking(lock_handle.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, 'Cedric Elec Atelier est deja ouvert. Revenez a sa fenetre.', 'Cedric Elec Atelier', 64)
            lock_handle.close()
            return 0
    from desktop_server import DesktopRuntime
    from desktop_api import DesktopApi
    runtime = None
    try:
        import webview
        runtime = DesktopRuntime(root).start()
        api = DesktopApi(runtime)
        window = webview.create_window('Cedric Elec - Atelier Plans | version bureau 0.2.0 alpha',
                runtime.url, js_api=api, width=1450, height=940,
                min_size=(1040, 720), background_color='#f3f5f8')
        api._window = window
        window.events.closing += api._on_closing
        profile = Path(os.environ.get('LOCALAPPDATA', str(root.parent))) / 'CedricElecAtelier' / 'Profil'
        profile.mkdir(parents=True, exist_ok=True)
        webview.start(gui='edgechromium' if os.name == 'nt' else None,
                      private_mode=False, storage_path=str(profile), debug=False,
                      localization={'global.quitConfirmation': 'Fermer le logiciel ?',
                                    'global.ok': 'OK', 'global.cancel': 'Annuler'})
    except Exception as exc:
        logging.exception('Demarrage de la version bureau impossible')
        text = ('Le logiciel ne peut pas demarrer. Vos projets ne sont pas supprimes. '
                'Verifier le moteur Microsoft Edge WebView2 et le journal bureau.log.\n\n' + str(exc)[:500])
        if os.name == 'nt':
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, text, 'Cedric Elec Atelier', 16)
        elif sys.stderr:
            print(text, file=sys.stderr)
        return 1
    finally:
        if runtime:
            runtime.close()
        lock_handle.close()
    return 0


if __name__ == '__main__':
    multiprocessing.freeze_support()
    raise SystemExit(main())
