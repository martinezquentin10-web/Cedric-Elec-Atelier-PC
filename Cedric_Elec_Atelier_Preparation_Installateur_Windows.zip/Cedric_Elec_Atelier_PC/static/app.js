'use strict';
// Interface sans framework, dependance distante ni appel IA payant.
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const esc = v => String(v ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const clone = v => JSON.parse(JSON.stringify(v));
const uid = () => Array.from(crypto.getRandomValues(new Uint8Array(16)),b=>b.toString(16).padStart(2,'0')).join('');
const fnum = (v,n=1) => Number(v).toLocaleString('fr-FR',{maximumFractionDigits:n});
const icons = {
 upload:'<path d="M12 16V3m-5 5 5-5 5 5M4 15v5h16v-5"/>',
 folder:'<path d="M3 6h7l2 3h9v11H3zM3 6V4h7l2 2h8v3"/>',
 save:'<path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/>',
 cursor:'<path d="m5 3 15 9-7 1-3 7z"/>',
 hand:'<path d="M8 12V5a2 2 0 0 1 4 0v6-7a2 2 0 0 1 4 0v7-5a2 2 0 0 1 4 0v8c0 5-3 7-7 7-3 0-5-2-7-5l-3-4a2 2 0 0 1 3-2l2 2"/>',
 crop:'<path d="M8 3v13h13M3 8h13v13M3 3h1m16 0h1v1M3 20v1h1"/>',
 polygon:'<path d="m5 5 13-2 3 13-10 5-8-9z"/><circle cx="5" cy="5" r="2"/><circle cx="21" cy="16" r="2"/><circle cx="11" cy="21" r="2"/>',
 square:'<rect x="4" y="4" width="16" height="16" rx="1"/>',
 route:'<path d="M4 20v-8h9V4h7"/><circle cx="4" cy="20" r="2"/><circle cx="20" cy="4" r="2"/>',
 target:'<rect x="4" y="4" width="16" height="16" rx="3"/><path d="m13 7-4 6h4l-2 4 5-7h-4z"/>',
 pin:'<path d="M19 10c0 5-7 11-7 11S5 15 5 10a7 7 0 1 1 14 0Z"/><circle cx="12" cy="10" r="2"/>',
 plus:'<path d="M12 4v16M4 12h16"/>',
 minus:'<path d="M5 12h14"/>',
 fit:'<path d="M8 3H3v5m13-5h5v5M3 16v5h5m8 0h5v-5"/><rect x="7" y="7" width="10" height="10" rx="1"/>',
 undo:'<path d="m8 5-5 5 5 5M3 10h10c9 0 9 10 1 10"/>',
 redo:'<path d="m16 5 5 5-5 5m5-5H11c-9 0-9 10-1 10"/>',
 play:'<path d="m7 4 14 8-14 8z"/>',
 check:'<path d="m4 12 5 5L20 6"/>',
 cross:'<path d="m6 6 12 12M18 6 6 18"/>',
 edit:'<path d="m4 16 12-12 4 4L8 20H4zm10-10 4 4"/>',
 trash:'<path d="M3 6h18M9 6V3h6v3M6 6l1 15h10l1-15M10 10v7m4-7v7"/>',
 layers:'<path d="m12 3 10 5-10 5L2 8zm-9 9 9 5 9-5m-18 5 9 5 9-5"/>',
 report:'<path d="M4 21V4h12l4 4v13zM15 4v5h5M8 16v2m4-6v6m4-4v4"/>',
 shield:'<path d="M12 3 3 6v6c0 5 9 9 9 9s9-4 9-9V6z"/><path d="m8 12 3 3 5-6"/>',
 ruler:'<path d="m3 16 13-13 5 5L8 21zm8-9 2 2m-5 1 2 2m-5 1 2 2"/>',
 search:'<circle cx="10" cy="10" r="7"/><path d="m15 15 6 6"/>',
 spark:'<path d="m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5z"/>',
 circle:'<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="2"/>',
 room:'<path d="m3 10 9-7 9 7v11H3zM9 21v-8h6v8"/>',
 bus:'<path d="M3 7h18M3 17h18M7 7v10m10-10v10"/><circle cx="7" cy="7" r="2"/><circle cx="17" cy="17" r="2"/>',
 info:'<circle cx="12" cy="12" r="9"/><path d="M12 10v7m0-11v1"/>',
 eye:'<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12"/><circle cx="12" cy="12" r="3"/>',
 lock:'<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V6a4 4 0 0 1 8 0v4m-4 4v3"/>',
 chevron:'<path d="m9 5 7 7-7 7"/>'
};
const icon = name => `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true">${icons[name]||icons.circle}</svg>`;
const button = (id,label,kind='pale',ic='')=>`<button id="${id}" class="button ${kind}">${ic?icon(ic):''}${label}</button>`;
const familyNames={eclairage:'\u00c9clairage',prise:'Prises',commande:'Commandes / BUS',reseau:'R\u00e9seau',alimentation:'Alimentation',autre:'Autre'};
const stateNames={validated:'Valid\u00e9',pending:'\u00c0 v\u00e9rifier',excluded:'Exclu'};
const familyIcon=f=>({eclairage:'circle',prise:'square',commande:'bus',reseau:'square',alimentation:'target'}[f]||'circle');
const S={project:null,base:null,page:0,step:1,catalog:'symbols',tool:'select',selected:null,info:null,camera:{x:0,y:0,scale:1},
  points:[],rect:null,filterLegend:null,filterStatus:'all',layers:{elements:true,rooms:false,circuits:false,labels:false},
  targetId:null,passageId:null,focusCircuit:null,undo:[],redo:[],change:0,dirty:false,saving:false,saveTimer:null,job:null,busy:false,drag:null,pointers:new Map(),pinch:null,gesture:false,renderTimer:null};
let savePromise=null,modalResolve=null;

async function api(path,body,retried=false){
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),120000);
 try{
  const options={headers:{'X-CE-Token':window.CE_SESSION},cache:'no-store',signal:controller.signal};
  if(body!==undefined){options.method='POST';options.headers['Content-Type']='application/json';options.body=JSON.stringify(body);}
  const response=await fetch(path,options);
  let data;try{data=await response.json();}catch(e){throw new Error('Le serveur redemarre ou la connexion est interrompue. Votre copie de secours reste dans ce navigateur.');}
  if(response.status===403&&window.CE_CLOUD&&!retried&&body!==undefined&&String(data.error).includes('Session invalide')){
   const session=await api('/api/session');window.CE_SESSION=session.token;return api(path,body,true);
  }
  if(!response.ok){const error=new Error(data.error||'Le traitement a echoue.');error.conflict=data.conflict;error.status=response.status;throw error;}
  return data;
 }catch(e){if(e.name==='AbortError')throw new Error('Operation trop longue ou connexion interrompue. La copie de secours reste accessible.');throw e;}finally{clearTimeout(timer);}
}
let backupWarningAt=0;
function backupFailure(e){$('#local-copies').textContent='Secours a verifier';if(Date.now()-backupWarningAt>30000){backupWarningAt=Date.now();toast(e.message||'Copie locale indisponible. Telechargez une sauvegarde.',true,10000);}}
function checkpoint(){if(!S.project)return;const project=clone(S.project),dirty=S.dirty;CEVault.checkpoint(project,dirty).then(ready=>{$('#local-copies').textContent=ready?(window.CE_DESKTOP?'Brouillons PC':'Copie navigateur'):'Copie partielle';}).catch(backupFailure);}

function toast(message,error=false,timeout=6500){
 if(!error)$$('#toasts .toast:not(.error)').forEach(t=>t.remove());
 while($('#toasts').children.length>=2)$('#toasts').firstElementChild.remove();
 const t=document.createElement('div');t.className='toast'+(error?' error':'');t.innerHTML=`<span>${esc(message)}</span><button aria-label="Fermer">&times;</button>`;
 t.querySelector('button').onclick=()=>t.remove();$('#toasts').append(t);if(timeout)setTimeout(()=>t.remove(),timeout);
}
function busy(on,label='Traitement local en cours\u2026'){
 S.busy=on;$('#busy-indicator').classList.toggle('hidden',!on);$('#busy-label').textContent=label;
}
async function guarded(fn){try{return await fn();}catch(e){console.error(e);toast(e.message,true,10000);}finally{busy(false);}}
function closeModal(value=null){if($('#modal').open)$('#modal').close();if(modalResolve){const r=modalResolve;modalResolve=null;r(value);}}
function formDialog(title,body,confirm='Enregistrer'){
 closeModal();$('#modal-content').innerHTML=`<div class="modal-header"><h2>${esc(title)}</h2><button class="icon-button" data-close-modal aria-label="Fermer">${icon('cross')}</button></div><form id="dialog-form"><div class="modal-body">${body}<div class="modal-actions"><button type="button" class="button quiet" data-close-modal>Annuler</button><button type="submit" class="button primary">${esc(confirm)}</button></div></div></form>`;
 $('#modal').showModal();setTimeout(()=>$('#dialog-form input:not([type=checkbox])')?.focus(),60);
 return new Promise(resolve=>{modalResolve=resolve;$('#dialog-form').onsubmit=e=>{e.preventDefault();closeModal(new FormData(e.target));};});
}
function infoDialog(title,body){closeModal();$('#modal-content').innerHTML=`<div class="modal-header"><h2>${esc(title)}</h2><button class="icon-button" data-close-modal aria-label="Fermer">${icon('cross')}</button></div><div class="modal-body">${body}</div>`;$('#modal').showModal();}
async function confirmDialog(title,message,confirm='Confirmer'){return !!(await formDialog(title,`<p>${esc(message)}</p>`,confirm));}
function persistStatus(text,ok=true){$('#save-status').innerHTML=`<span class="status-dot" style="background:${ok?'#55a386':'#d5a43b'}"></span>${esc(text)}`;}
function changed(){S.change++;S.dirty=true;checkpoint();persistStatus('Enregistrement\u2026',false);clearTimeout(S.saveTimer);S.saveTimer=setTimeout(()=>guarded(saveNow),600);}

function mergeProject(base,local,remote){
 const out=clone(remote),eq=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
 const collections=['legend','elements','zones','targets','passages','circuits'];
 function patchFields(before,ours,theirs,label){
  const item=clone(theirs);for(const key of new Set([...Object.keys(before||{}),...Object.keys(ours||{})])){
   if(['revision','updatedAt','document','createdAt','roomId','onBoundary','stale'].includes(key)&&!ours.roomManual)continue;
   if(eq(before?.[key],ours?.[key]))continue;
   if(!eq(before?.[key],theirs?.[key])&&!eq(ours?.[key],theirs?.[key])&&!['status','manual','notes','roomId','roomManual','onBoundary','stale'].includes(key))throw new Error('Modification concurrente sur '+label+' ('+key+'). Vos changements restent dans cette fenetre ; exportez une sauvegarde avant de recharger.');
   if(key in ours)item[key]=clone(ours[key]);else delete item[key];
  }return item;
 }
 for(const key of ['name','config','scales']){
  if(eq(base[key],local[key]))continue;
  if(typeof local[key]==='object')out[key]=patchFields(base[key]||{},local[key],remote[key]||{},key);
  else {if(!eq(base[key],remote[key])&&!eq(local[key],remote[key]))throw new Error('Le nom du chantier a change dans une autre fenetre.');out[key]=local[key];}
 }
 for(const key of collections){
  const before=new Map((base[key]||[]).map(x=>[x.id,x])),ours=new Map((local[key]||[]).map(x=>[x.id,x])),theirs=new Map((remote[key]||[]).map(x=>[x.id,x]));
  for(const[id,old]of before){if(!ours.has(id))theirs.delete(id);}
  for(const[id,obj]of ours){const old=before.get(id);if(!old){theirs.set(id,obj);continue;}if(eq(old,obj))continue;theirs.set(id,patchFields(old,obj,theirs.get(id)||old,obj.name||obj.ref||key));}
  out[key]=[...theirs.values()];
 }
 const legendIds=new Set(out.legend.map(l=>l.id));out.elements=out.elements.filter(e=>legendIds.has(e.legendId));return out;
}
function ingest(remote){
 if(S.project?.id!==remote.id)return;
 S.project=S.dirty?mergeProject(S.base||S.project,S.project,remote):remote;S.base=clone(remote);checkpoint();
}

async function saveNow(){
 clearTimeout(S.saveTimer);
 if(savePromise){await savePromise;if(S.dirty)return saveNow();return;}
 if(!S.project||!S.dirty)return;
 savePromise=(async()=>{
  let conflicts=0;
  while(S.dirty&&S.project){
   const version=S.change,snapshot=clone(S.project);
   try{
    const saved=await api(`/api/projects/${snapshot.id}`,{project:snapshot,revision:snapshot.revision});
    if(S.project.id!==snapshot.id)return;
    S.base=clone(saved);
    if(version===S.change){S.project=saved;S.dirty=false;}
    else {S.project.revision=saved.revision;S.project.updatedAt=saved.updatedAt;}
    persistStatus(window.CE_CLOUD?'Enregistre sur serveur temporaire':'Enregistre sur cet ordinateur');checkpoint();renderResults();renderOverlay();
   }catch(e){
    if(e.conflict){if(++conflicts>3)throw new Error('Sauvegarde concurrente persistante. Vos modifications restent dans le brouillon local. Attendez la fin de l’analyse avant de reessayer.');const remote=await api(`/api/projects/${snapshot.id}`);S.project=mergeProject(S.base||snapshot,S.project,remote);S.base=clone(remote);S.change++;continue;}
    persistStatus('Sauvegarde en attente',false);throw e;
   }
  }
 })();
 try{await savePromise;}finally{savePromise=null;}
}
function remember(snapshot=clone(S.project)){if(!snapshot)return;S.undo.push(snapshot);if(S.undo.length>40)S.undo.shift();S.redo=[];}
function mutate(fn,history=true){if(!S.project)return;if(history)remember();fn(S.project);assignRooms();changed();renderApp();}
function dist(a,b){return Math.hypot(a[0]-b[0],a[1]-b[1]);}
function area(poly){return Math.abs(poly.reduce((sum,a,i)=>{const b=poly[(i+1)%poly.length];return sum+a[0]*b[1]-b[0]*a[1];},0))/2;}
function pointInside(p,poly){let hit=false;for(let i=0,j=poly.length-1;i<poly.length;j=i++){const a=poly[i],b=poly[j];if((a[1]>p[1])!==(b[1]>p[1])&&p[0]<(b[0]-a[0])*(p[1]-a[1])/(b[1]-a[1])+a[0])hit=!hit;}return hit;}
function assignRooms(){if(!S.project)return;const zs=S.project.zones.filter(z=>z.type==='room'&&z.confirmed).sort((a,b)=>area(a.points)-area(b.points));for(const e of S.project.elements){if(e.roomManual&&zs.some(z=>z.id===e.roomId))continue;e.roomId=zs.find(z=>z.page===e.page&&pointInside([e.x,e.y],z.points))?.id||null;}}
const legendById=id=>S.project?.legend.find(l=>l.id===id);
const zoneById=id=>S.project?.zones.find(z=>z.id===id);
function selectedObject(){const sel=S.selected;if(!sel||!S.project)return null;return S.project[{legend:'legend',element:'elements',zone:'zones',circuit:'circuits',target:'targets',passage:'passages'}[sel.type]]?.find(x=>x.id===sel.id)||null;}
function currentElements(includeExcluded=false){const focus=S.step===5&&S.focusCircuit?S.project?.circuits.find(c=>c.id===S.focusCircuit):null;return(S.project?.elements||[]).filter(e=>(!focus||focus.elementIds.includes(e.id))&&e.page===S.page&&(!S.filterLegend||e.legendId===S.filterLegend)&&(S.filterStatus==='all'?(includeExcluded||e.status!=='excluded'):e.status===S.filterStatus));}
function totalCounts(elements){return elements.reduce((r,e)=>{r[e.status]=(r[e.status]||0)+1;return r;},{validated:0,pending:0,excluded:0});}
function cropURL(legend){const source=legend.source;if(!source)return '';return `/api/projects/${S.project.id}/crop?page=${source.page}&rect=${source.rect.join(',')}`;}
function familyOptions(value){return Object.entries(familyNames).map(([id,name])=>`<option value="${id}" ${id===value?'selected':''}>${esc(name)}</option>`).join('');}
function zoneOptions(selected,allowParent=false,exclude=null){return `<option value="">${allowParent?'Aucune (pi&egrave;ce principale)':'Non affect&eacute; / automatique'}</option>`+(S.project?.zones||[]).filter(z=>z.page===S.page&&z.type==='room'&&z.id!==exclude&&(allowParent||z.confirmed)).map(z=>`<option value="${z.id}" ${z.id===selected?'selected':''}>${esc(z.name)}</option>`).join('');}
function field(name,label,value,type='text'){return `<label class="form-field"><span>${label}</span><input data-field="${name}" type="${type}" value="${esc(value)}" ${type==='number'?'min="0" step="0.1"':''}></label>`;}

function renderNav(){
 $('#steps').innerHTML=['Plan','L\u00e9gende','Comptage','Pi\u00e8ces','Trac\u00e9s'].map((label,i)=>`<button class="step ${S.step===i+1?'active':''}" data-step="${i+1}" ${S.project||i===0?'':'disabled'}><span>${i+1}</span>${esc(label)}</button>`).join('');
 $('#project-name').textContent=S.project?.name||'Nouveau chantier';
 const d=S.project?.document;
 $('#document-info').innerHTML=d?`${esc(d.filename)}<br><span>${d.kind==='dxf'?'DXF / espace objet':d.kind==='image'?'Image':'PDF'} &middot; ${d.pages.length} page${d.pages.length>1?'s':''}</span>${S.project.demo?'<div class="stat-pills"><span>EXEMPLE P&Eacute;DAGOGIQUE</span></div>':''}`:'PDF, DXF ou image. Vos fichiers restent ici.';
 $('#save-project').disabled=!S.project;$('#save-project').innerHTML=icon('save')+'Sauvegarder';
 $('#open-projects').innerHTML=icon('folder');$('#import-plan').innerHTML=icon('upload')+'Importer un plan';$('#open-backup').innerHTML=icon('folder');
 $('#privacy-note').innerHTML=icon('shield')+(window.CE_CLOUD?'Essai prive : plans traites sur le serveur.<br>Secours dans ce navigateur, sans synchronisation cloud.<br><a href="/sources.zip">Code source AGPL - sans garantie</a>':(window.CE_DESKTOP?'Application PC. Projets et brouillons sur le disque. Aucun traitement sur Render.':'Traitements sur votre ordinateur. Copie de secours dans ce navigateur.'));$('.local-badge').innerHTML='<span></span>'+(window.CE_CLOUD?'ESSAI PRIVE':'LOCAL');
 $('#welcome').classList.toggle('hidden',!!S.project);$('#world').style.display=S.project?'block':'none';
 $('#welcome-import').innerHTML=icon('upload')+'Importer mon plan';
}
function renderStage(){
 const p=S.project;let content='';
 if(S.step===1){content=`<h2>Commencez par votre plan</h2><p>D&eacute;posez le fichier, puis v&eacute;rifiez l'&eacute;chelle avant de mesurer les trac&eacute;s.</p>${button('calibrate','D&eacute;finir l\u2019&eacute;chelle','outline full','ruler')}${p?`<div class="stat-pills"><span>${S.info?fnum(S.info.vectorCount,0):'\u2026'} trac&eacute;s vectoriels</span><span>${S.info?fnum(S.info.textCount,0):'\u2026'} textes</span></div><div class="inline-note">${p.scales[String(S.page)]?'&Eacute;chelle renseign&eacute;e. V&eacute;rifiez une cote connue.':'&Eacute;chelle non d&eacute;finie : aucune longueur en m&egrave;tres ne sera invent&eacute;e.'}</div>${button('document-details','Informations du fichier','quiet full','info')}`:''}`;}
 if(S.step===2){content=`<h2>Votre l&eacute;gende fait foi</h2><p>Encadrez la l&eacute;gende pour proposer ses lignes, ou choisissez un symbole pr&eacute;cis.</p>${button('start-legend','Encadrer la l&eacute;gende','primary full','crop')}${button('start-sample','Ajouter un exemple','outline full','plus')}${p?.document.kind==='dxf'?button('from-blocks','Utiliser les blocs DXF','pale full','layers'):''}<div class="row">${button('start-exclude','Zone &agrave; exclure','quiet','square')}</div><div class="inline-note">Les noms et les exemples propos&eacute;s restent &agrave; v&eacute;rifier.</div>`;}
 if(S.step===3){content=`<h2>Comptez, puis v&eacute;rifiez</h2><p>Chaque quantit&eacute; correspond &agrave; un rep&egrave;re sur le plan. Les propositions ne sont pas valid&eacute;es automatiquement.</p>${button('analyze-all','Analyser la l&eacute;gende','primary full','play')}<label class="form-field"><span>Seuil de similarit&eacute; <strong id="threshold-value">${Math.round((p?.config.threshold||.88)*100)} %</strong></span><input id="threshold" type="range" min="65" max="99" value="${Math.round((p?.config.threshold||.88)*100)}"></label><label class="form-field"><span>Afficher sur le plan</span><select id="filter-status"><option value="all">Tous, hors exclus</option><option value="pending">&Agrave; v&eacute;rifier</option><option value="validated">Valid&eacute;s</option><option value="excluded">Exclus</option></select></label>${button('validate-visible','Valider les propositions affich&eacute;es','gold full','check')}`;}
 if(S.step===4){content=`<h2>Une pi&egrave;ce, un contour</h2><p>Les noms aident &agrave; proposer les pi&egrave;ces. Validez les contours ou dessinez-les librement.</p>${button('propose-rooms','Proposer les pi&egrave;ces','primary full','spark')}<div class="row">${button('start-room','Forme libre','outline','polygon')}${button('start-roomRect','Rectangle','outline','square')}</div><div class="inline-note">Une sous-pi&egrave;ce peut &ecirc;tre rattach&eacute;e &agrave; une suite, sans double comptage.</div>`;}
 if(S.step===5){const targets=p?.targets.filter(t=>t.page===S.page)||[],passages=p?.passages.filter(t=>t.page===S.page)||[];if(!targets.some(t=>t.id===S.targetId))S.targetId=targets[0]?.id||null;
  content=`<h2>Des trac&eacute;s modifiables</h2><p>Un circuit par type et par pi&egrave;ce. Seuls les &eacute;quipements valid&eacute;s sont utilis&eacute;s.</p>${button('start-target','Placer un tableau','outline full','target')}<div class="row">${button('start-passage','Passage','pale','route')}${button('start-obstacle','Obstacle','pale','polygon')}</div><label class="form-field"><span>Destination</span><select id="target-choice"><option value="">Choisir un tableau</option>${targets.map(t=>`<option value="${t.id}" ${t.id===S.targetId?'selected':''}>${esc(t.name)}</option>`).join('')}</select></label><label class="form-field"><span>Passage impos&eacute; pour rejoindre le tableau</span><select id="passage-choice"><option value="">Aucun passage impos&eacute;</option>${passages.map(t=>`<option value="${t.id}" ${t.id===S.passageId?'selected':''}>${esc(t.name)}</option>`).join('')}</select></label><label class="checkbox-row"><input id="domotique" type="checkbox" ${p?.config.domotique?'checked':''}>Commandes sur un BUS distinct</label>${button('generate-circuits','Proposer les circuits','primary full','route')}<div class="microcopy">Les murs ne sont pas des obstacles automatiques. D&eacute;finissez les interdictions et contr&ocirc;lez les passages.</div>`;
 }
 $('#stage-card').innerHTML=`<div class="stage-num">&Eacute;TAPE ${S.step} / 5</div>${content}`;
 if($('#filter-status'))$('#filter-status').value=S.filterStatus;
 ['calibrate','document-details'].forEach(id=>{if($('#'+id))$('#'+id).disabled=!p;});
 if($('#analyze-all'))$('#analyze-all').disabled=!p?.legend.length||!!S.job;
 if($('#validate-visible'))$('#validate-visible').disabled=!currentElements().some(e=>e.status==='pending');
 if($('#generate-circuits'))$('#generate-circuits').disabled=!S.targetId||!p?.elements.some(e=>e.page===S.page&&e.status==='validated');
}
function renderCatalog(){
 const p=S.project,rooms=S.catalog==='rooms';$('#catalog-title').textContent=rooms?'Pi\u00e8ces & zones':'L\u00e9gende du chantier';$('#tab-symbols').classList.toggle('active',!rooms);$('#tab-rooms').classList.toggle('active',rooms);
 const items=rooms?(p?.zones.filter(z=>z.page===S.page)||[]):(p?.legend||[]);$('#catalog-counter').textContent=items.length;
 $('#catalog-list').innerHTML=(!rooms&&S.filterLegend?'<button class="button quiet full compact" id="clear-filter">Afficher tous les symboles</button>':'')+items.map(item=>{
  if(rooms){const count=p.elements.filter(e=>e.page===S.page&&e.status==='validated'&&(e.roomId===item.id||(item.type==='room'&&pointInside([e.x,e.y],item.points)))).length;
   return `<button class="catalog-item ${S.selected?.id===item.id?'selected':''}" data-select-type="zone" data-select-id="${item.id}"><span class="symbol-swatch" style="--swatch:${item.color}">${icon(item.type==='room'?'room':item.type==='obstacle'?'polygon':'square')}</span><span class="catalog-label"><strong>${esc(item.name)}</strong><small>${item.type==='room'?(item.confirmed?(item.parentId?'Sous-pi&egrave;ce':'Contour valid&eacute;'):'Contour &agrave; valider'):item.type==='obstacle'?'Passage interdit':'Hors comptage'}</small></span><span class="quantity">${item.type==='room'?count:'&mdash;'}</span></button>`;
  }
  const c=totalCounts(p.elements.filter(e=>e.legendId===item.id&&e.page===S.page));
  return `<button class="catalog-item ${S.selected?.id===item.id?'selected':''}" data-select-type="legend" data-select-id="${item.id}">${item.source?`<img class="symbol-thumb" src="${cropURL(item)}" alt="">`:`<span class="symbol-swatch" style="--swatch:${item.color}">${icon(familyIcon(item.family))}</span>`}<span class="catalog-label"><strong>${esc(item.name)}</strong><small>${esc(item.blockName?'Bloc DXF':familyNames[item.family]||'Symbole')}${item.proposed?' &middot; &agrave; v&eacute;rifier':''}</small></span><span class="quantity">${c.validated}${c.pending?`<small>+${c.pending} &agrave; voir</small>`:''}</span></button>`;
 }).join('')||`<div class="catalog-empty">${rooms?'Dessinez une pi&egrave;ce ou demandez une proposition de contours.':'La l&eacute;gende du chantier appara&icirc;tra ici.<br>Chaque symbole est personnalisable.'}</div>`;
 $('#catalog-add').innerHTML=icon('plus')+(rooms?'Dessiner une pi&egrave;ce':'Ajouter un symbole');$('#catalog-add').disabled=!p;
}
function renderTools(){
 const tools=[['select','cursor','S\u00e9lectionner (V)'],['pan','hand','D\u00e9placer le plan (H)']];
 if(S.step===2)tools.push(['sample','crop','Encadrer un exemple']);
 if(S.step===3)tools.push(['add','plus','Ajouter un \u00e9quipement oubli\u00e9']);
 if(S.step===4)tools.push(['room','polygon','Pi\u00e8ce libre'],['roomRect','square','Pi\u00e8ce rectangulaire']);
 if(S.step===5)tools.push(['target','target','Tableau'],['passage','route','Passage impos\u00e9']);
 if(S.step===1)tools.push(['measure','ruler','Calibrer une cote']);
 $('#tools').innerHTML=tools.map(([id,ic,title])=>`<button class="icon-button ${S.tool===id?'active':'tonal'}" data-tool="${id}" title="${esc(title)}" aria-label="${esc(title)}" ${S.project?'':'disabled'}>${icon(ic)}</button>`).join('');
 $('#undo').innerHTML=icon('undo');$('#redo').innerHTML=icon('redo');$('#undo').disabled=!S.undo.length;$('#redo').disabled=!S.redo.length;
 $('#zoom-out').innerHTML=icon('minus');$('#zoom-in').innerHTML=icon('plus');$('#fit').innerHTML=icon('fit');
 $('#page-control').innerHTML=S.project?`<button data-page-shift="-1" ${S.page===0?'disabled':''} aria-label="Page pr&eacute;c&eacute;dente">&lsaquo;</button><span>Page ${S.page+1} / ${S.project.document.pages.length}</span><button data-page-shift="1" ${S.page+1>=S.project.document.pages.length?'disabled':''} aria-label="Page suivante">&rsaquo;</button>`:'Aucun plan import&eacute;';
 if(S.focusCircuit&&!S.project?.circuits.some(c=>c.id===S.focusCircuit&&c.page===S.page))S.focusCircuit=null;
 $('#layer-controls').innerHTML=(S.step===5&&S.project?.circuits.length?`<select id="circuit-focus" aria-label="Circuit visible"><option value="">Tous les circuits</option>${S.project.circuits.filter(c=>c.page===S.page).map(c=>`<option value="${c.id}" ${S.focusCircuit===c.id?'selected':''}>${esc(c.name)} - ${esc(c.bus?'BUS':zoneById(c.zoneId)?.name||'Circuit')}</option>`).join('')}</select>`:'')+Object.entries({elements:'Symboles',rooms:'Pi&egrave;ces',circuits:'Trac&eacute;s',labels:'Rep&egrave;res'}).map(([id,label])=>`<button data-layer="${id}" class="${S.layers[id]?'active':''}">${label}</button>`).join('');
 $('#viewport').dataset.tool=S.tool;updateToolHelp();
}
function updateToolHelp(){
 const labels={sample:'Glissez un cadre autour du symbole, sans sa d\u00e9signation.',legend:'Glissez un cadre autour de la l\u00e9gende du chantier.',room:'Cliquez les sommets de la pi\u00e8ce. Double-cliquez pour terminer.',roomRect:'Glissez pour dessiner le rectangle de la pi\u00e8ce.',target:'Cliquez la position du tableau ou du point d\u2019arriv\u00e9e.',add:'Cliquez sur un \u00e9quipement oubli\u00e9 pour l\u2019ajouter.',passage:'Cliquez les points du passage impos\u00e9, puis Terminer.',obstacle:'Entourez la zone dans laquelle les trac\u00e9s ne doivent pas passer.',exclude:'Entourez la zone \u00e0 exclure du comptage.',measure:'Cliquez deux points d\u2019une cote dont vous connaissez la longueur.'};
 const text=labels[S.tool];$('#tool-help').classList.toggle('hidden',!text);
 if(text)$('#tool-help').innerHTML=`<span>${esc(text)}</span>${['room','passage','obstacle','exclude'].includes(S.tool)?'<button id="finish-shape">Terminer</button>':''}<button id="cancel-tool" title="Annuler (&Eacute;chap)">&times;</button>`;
}

function renderInspector(){
 const item=selectedObject(),type=S.selected?.type;let html=`<div class="inspector-title"><h2>${icon('pin')}${item?'S\u00e9lection':'Votre espace de travail'}</h2>${item?`<button class="icon-button" id="deselect" title="Fermer la s&eacute;lection">${icon('cross')}</button>`:''}</div>`;
 if(!item){html+=`<div class="inspector-illustration">${icon(S.step===5?'route':S.step===4?'room':'cursor')}</div><h3>${S.step===3?'V\u00e9rifiez directement sur le plan':S.step===4?'Gardez la main sur les contours':S.step===5?'Choisissez un trac\u00e9':'Tout commence par votre plan'}</h3><p class="inspector-empty">${S.step===3?'Cliquez sur un rep&egrave;re pour le valider, corriger son type ou l\u2019exclure. Un score ne remplace pas le contr&ocirc;le.':S.step===4?'Les pi&egrave;ces propos&eacute;es restent en pointill&eacute;s jusqu\u2019&agrave; votre validation. D&eacute;placez leurs sommets pour les corriger.':S.step===5?'Cliquez un circuit, puis d&eacute;placez ses poign&eacute;es. Les trac&eacute;s modifi&eacute;s sont verrouill&eacute;s pour ne pas perdre vos corrections.':'Le plan occupe tout l\u2019espace utile. Les informations d\u2019un symbole, d\u2019une pi&egrave;ce ou d\u2019un circuit appara&icirc;tront ici.'}</p><div class="notice blue">${S.project?(window.CE_CLOUD?'Serveur temporaire. Verifiez la copie navigateur et exportez aussi votre fichier .ceprojet.':'Projet enregistre sur cet ordinateur. Exportez aussi une sauvegarde portable.'):'PDF vectoriel et DXF en priorit&eacute;.<br>Le DWG natif doit d\u2019abord &ecirc;tre export&eacute; depuis AutoCAD.'}</div>`;}
 if(type==='legend'&&item){
  html+=`<div class="selected-summary">${item.source?`<img src="${cropURL(item)}" alt="Exemple du symbole">`:icon(familyIcon(item.family))}<span><strong>${esc(item.name)}</strong><small>${item.blockName?'Bloc '+esc(item.blockName):'Exemple propre au chantier'}</small></span></div>`;
  html+=field('name','D&eacute;signation',item.name)+`<label class="form-field"><span>Famille</span><select data-field="family">${familyOptions(item.family)}</select></label>`+field('color','Couleur des rep&egrave;res',item.color,'color');
  if(item.source)html+=`<label class="checkbox-row"><input data-field="sourceCounted" type="checkbox" ${item.source.excludeFromCount===false?'checked':''}>Cet exemple est un vrai &eacute;quipement du plan</label>`;
  if(!item.blockName)html+=`<label class="checkbox-row"><input data-field="rotations" type="checkbox" ${item.rotations!==false?'checked':''}>Chercher dans les 4 orientations</label><label class="checkbox-row"><input data-field="multiScale" type="checkbox" ${item.multiScale!==false?'checked':''}>Comparer aussi plusieurs tailles</label>`;
  html+=`<div class="inspector-actions">${button('analyze-selected','Rechercher','primary','search')}${button('replace-sample','Autre exemple','outline','crop')}</div><div class="inspector-actions">${button('remove-selected','Supprimer','quiet','trash')}</div><p class="microcopy">Le comptage exclut la l&eacute;gende. Un exemple pris dans le plan peut &ecirc;tre inclus en cochant l\u2019option ci-dessus.</p>`;
 }
 if(type==='element'&&item){
  const legend=legendById(item.legendId);html+=`<div class="selected-summary">${legend?.source?`<img src="${cropURL(legend)}" alt="">`:icon('circle')}<span><strong>${esc(legend?.name||'\u00c9quipement')}</strong><small>${esc(item.ref)} &middot; Page ${item.page+1}</small></span></div><span class="badge ${item.status}">${esc(stateNames[item.status])}</span>`;
  html+=`<label class="form-field"><span>Type de mat&eacute;riel</span><select data-field="legendId">${S.project.legend.map(l=>`<option value="${l.id}" ${l.id===item.legendId?'selected':''}>${esc(l.name)}</option>`).join('')}</select></label><label class="form-field"><span>Pi&egrave;ce</span><select data-field="roomId">${zoneOptions(item.roomId)}</select></label>`;
  if(item.onBoundary)html+='<div class="notice">L\u2019&eacute;quipement est pr&egrave;s d\u2019une limite. V&eacute;rifiez sa pi&egrave;ce d\u2019affectation.</div>';
  html+=`<div class="data-line"><span>M&eacute;thode</span><strong>${esc(item.manual?'Ajout / correction manuelle':item.method||'Recherche')}</strong></div>${!item.manual?`<div class="data-line"><span>Similarit&eacute; graphique</span><strong>${Math.round((item.score||0)*100)} %</strong></div><div class="score-bar"><span style="width:${Math.round((item.score||0)*100)}%"></span></div><p class="microcopy">Ce score n\u2019est pas une probabilit&eacute; de justesse.</p>`:''}<label class="form-field"><span>Note</span><textarea data-field="notes" placeholder="Ajouter une pr&eacute;cision\u2026">${esc(item.notes||'')}</textarea></label><div class="inspector-actions">${button('validate-selected','Valider','gold','check')}${button('exclude-selected','Exclure','danger','cross')}</div><div class="inspector-actions">${button('next-pending','Suivant &agrave; v&eacute;rifier','outline','chevron')}</div><div class="microcopy">D&eacute;placez le rep&egrave;re directement sur le plan pour corriger sa position.</div>`;
 }
 if(type==='zone'&&item){
  html+=`<div class="selected-summary"><span class="symbol-swatch" style="--swatch:${item.color}">${icon('room')}</span><span><strong>${esc(item.name)}</strong><small>${item.points.length} sommets modifiables</small></span></div>`+field('name','Nom',item.name);
  if(item.type==='room')html+=`<label class="form-field"><span>Pi&egrave;ce parente (facultatif)</span><select data-field="parentId">${zoneOptions(item.parentId,true,item.id)}</select></label>`;
  html+=field('color','Couleur de la zone',item.color,'color');
  const scale=S.project.scales[String(item.page)];if(item.type==='room')html+=`<div class="data-line"><span>Surface du contour</span><strong>${scale?fnum(area(item.points)*scale*scale,2)+' m\u00b2':'\u00c9chelle non d\u00e9finie'}</strong></div><span class="badge ${item.confirmed?'validated':'pending'}">${item.confirmed?'Contour valid&eacute;':'Contour &agrave; v&eacute;rifier'}</span>`;
  if(!item.confirmed)html+=`<div class="notice">Contr&ocirc;lez les portes et les limites. Les &eacute;quipements ne sont affect&eacute;s qu\u2019apr&egrave;s validation de la pi&egrave;ce.</div>${button('validate-zone','Valider ce contour','gold full','check')}`;
  html+=`<div class="inspector-actions">${button('remove-selected','Supprimer la zone','quiet','trash')}</div><p class="microcopy">D&eacute;placez les poign&eacute;es du contour. La pi&egrave;ce la plus petite contient les &eacute;quipements des sous-pi&egrave;ces.</p>`;
 }
 if(type==='circuit'&&item){
  const length=circuitLength(item);html+=`<div class="selected-summary"><span class="symbol-swatch" style="--swatch:${item.color}">${icon(item.bus?'bus':'route')}</span><span><strong>${esc(item.name)}</strong><small>${item.bus?'BUS distinct':esc(zoneById(item.zoneId)?.name||'Pi\u00e8ce')} &middot; ${item.elementIds.length} &eacute;quipements</small></span></div>`+field('name','Rep&egrave;re du circuit',item.name);
  html+=`<div class="data-line"><span>Longueur estim&eacute;e</span><strong>${length===null?'\u00c9chelle / trajet \u00e0 v\u00e9rifier':fnum(length,2)+' m'}</strong></div>`+field('extraMeters','Mont&eacute;es + descentes + r&eacute;serve (m)',item.extraMeters||0,'number');
  if(item.stale)html+='<div class="notice red">Des &eacute;quipements ou le tableau ont chang&eacute;. Ce trac&eacute; est &agrave; revoir.</div>';
  if(item.routes.some(r=>r.blocked))html+='<div class="notice red">Un passage est bloqu&eacute; ou coupe un obstacle. Aucun trajet valide n\u2019est invent&eacute;.</div>';
  html+=`<label class="form-field"><span>Note</span><textarea data-field="notes">${esc(item.notes||'')}</textarea></label><span class="badge ${item.manual?'validated':'pending'}">${item.manual?'Trac&eacute; modifi&eacute; / verrouill&eacute;':'Proposition de travail'}</span><div class="inspector-actions">${button('toggle-lock',item.manual?'Autoriser le recalcul':'Verrouiller le trac&eacute;','outline','lock')}${button('remove-selected','Supprimer','quiet','trash')}</div><p class="microcopy">Les petits carr&eacute;s ajoutent un sommet. Les ronds d&eacute;placent les sommets internes. Les extr&eacute;mit&eacute;s ne se d&eacute;placent pas ici. Apr&egrave;s d&eacute;placement d'un &eacute;quipement, recalculez le circuit.</p>`;
 }
 if((type==='target'||type==='passage')&&item){html+=`<div class="selected-summary">${icon(type==='target'?'target':'route')}<strong>${esc(item.name)}</strong></div>`+field('name','Nom',item.name)+`<div class="inspector-actions">${button('remove-selected','Supprimer','quiet','trash')}</div><p class="microcopy">${type==='target'?'D&eacute;placez le tableau sur le plan. Les circuits existants devront &ecirc;tre recalcul&eacute;s.':'D&eacute;placez les sommets pour modifier le chemin impos&eacute;.'}</p>`;}
 $('#inspector').innerHTML=html;
 if($('#analyze-selected'))$('#analyze-selected').disabled=!!S.job;
}
function circuitLength(c){const scale=S.project?.scales[String(c.page)];if(!scale||c.stale||c.routes.some(r=>r.blocked))return null;return c.routes.reduce((v,r)=>v+r.points.slice(1).reduce((a,p,i)=>a+dist(p,r.points[i]),0),0)*scale+(Number(c.extraMeters)||0);}
function renderAnalysis(){
 const c=$('#analysis-card');
 if(!S.job){c.classList.add('hidden');return;}
 c.classList.remove('hidden');c.innerHTML=`<h2>${icon('search')} Analyse du plan</h2><div class="job-label">${esc(S.job.message||'Recherche en cours\u2026')}</div><div class="analysis-progress"><span style="width:${Math.round((S.job.progress||0)*100)}%"></span></div><div class="data-line"><span>Vous pouvez continuer &agrave; naviguer.</span><strong>${Math.round((S.job.progress||0)*100)} %</strong></div>${button('cancel-analysis','Annuler l\u2019analyse','quiet full','cross')}`;
}
function renderResults(){
 const p=S.project,els=(p?.elements||[]).filter(e=>e.page===S.page),counts=totalCounts(els),rooms=p?.zones.filter(z=>z.page===S.page&&z.type==='room'&&z.confirmed).length||0,circuits=p?.circuits.filter(c=>c.page===S.page).length||0;
 $('#results').innerHTML=`<h2>${icon('report')} R&eacute;sultats de la page</h2><div class="summary-strip"><div><strong>${counts.validated}</strong><small>&Eacute;QUIPEMENTS VALID&Eacute;S</small></div><div><strong class="amber">${counts.pending}</strong><small>&Agrave; V&Eacute;RIFIER</small></div></div>${(p?.legend||[]).slice(0,5).map(l=>{const c=totalCounts(els.filter(e=>e.legendId===l.id));return `<div class="result-row"><span class="result-dot" style="background:${l.color}"></span><span class="label">${esc(l.name)}</span><strong>${c.validated}</strong><small>${c.pending?'+'+c.pending:''}</small></div>`;}).join('')}<div class="result-row"><span class="label">Pi&egrave;ces valid&eacute;es</span><strong>${rooms}</strong></div><div class="result-row"><span class="label">Circuits de travail</span><strong>${circuits}</strong></div>${button('show-report','R&eacute;capitulatif & exports','primary full','report')}`;
 $('#show-report').disabled=!p;
 $('#canvas-info').textContent=p?`${els.filter(e=>e.status!=='excluded').length} rep\u00e8res \u00b7 ${rooms} pi\u00e8ces \u00b7 ${circuits} circuits${S.filterLegend?' \u00b7 Filtre actif':''}`:'D\u00e9posez votre plan ici';
}
function renderApp(){renderNav();renderStage();renderCatalog();renderTools();renderInspector();renderAnalysis();renderResults();renderOverlay();}
let overlayFrame=null;
function scheduleOverlay(){if(overlayFrame)return;overlayFrame=requestAnimationFrame(()=>{overlayFrame=null;renderOverlay();});}
function renderOverlay(){
 const p=S.project;if(!p)return;const scale=S.camera.scale,unit=1/scale,svg=$('#overlay');let out=[];
 const vw=$('#viewport').clientWidth,vh=$('#viewport').clientHeight,x0=-S.camera.x/scale-40*unit,y0=-S.camera.y/scale-40*unit,x1=x0+vw/scale+80*unit,y1=y0+vh/scale+80*unit;
 const inView=(x,y)=>x>=x0&&x<=x1&&y>=y0&&y<=y1;
 const handle=(x,y,kind,id,role,extra='',fill='#fff',r=4)=>`<circle cx="${x}" cy="${y}" r="${r*unit}" fill="${fill}" stroke="#315496" stroke-width="1.5" vector-effect="non-scaling-stroke" data-kind="${kind}" data-id="${id}" data-role="${role}" ${extra} style="cursor:move"/>`;
 const selected=S.selected;
 for(const z of p.zones.filter(z=>z.page===S.page)){
  const active=selected?.id===z.id;if(!active&&!(z.type==='room'?S.layers.rooms:z.type==='exclude'?S.step===2:S.step===5))continue;
  const points=z.points.map(p=>p.join(',')).join(' '),dashed=!z.confirmed||z.type!=='room';
  out.push(`<g data-kind="zone" data-id="${z.id}"><polygon points="${points}" fill="${z.color}" fill-opacity="${active ? .15 : z.type==='room' ? .065 : .06}" stroke="${z.color}" stroke-width="${active?2.5:1.3}" ${dashed?'stroke-dasharray="6 4"':''} vector-effect="non-scaling-stroke" style="cursor:pointer"/><text x="${Math.min(...z.points.map(p=>p[0]))+8*unit}" y="${Math.min(...z.points.map(p=>p[1]))+17*unit}" fill="${z.color}" font-family="Segoe UI,Arial" font-size="${10*unit}" font-weight="600" paint-order="stroke" stroke="white" stroke-width="${3*unit}" stroke-linejoin="round">${esc(z.name)}${!z.confirmed?' ?':''}</text></g>`);
  if(active)z.points.forEach((p,i)=>out.push(handle(p[0],p[1],'zone',z.id,'zone-handle',`data-vertex="${i}"`)));
 }
 if(S.layers.circuits||S.step===5){
  for(const passage of p.passages.filter(x=>x.page===S.page)){
   const points=passage.points.map(p=>p.join(',')).join(' ');out.push(`<polyline data-kind="passage" data-id="${passage.id}" points="${points}" fill="none" stroke="#f1c344" stroke-opacity=".65" stroke-width="8" stroke-linecap="round" stroke-linejoin="round" vector-effect="non-scaling-stroke" style="cursor:pointer"/>`);
   if(selected?.id===passage.id)passage.points.forEach((p,i)=>out.push(handle(p[0],p[1],'passage',passage.id,'passage-handle',`data-vertex="${i}"`)));
  }
  for(const c of p.circuits.filter(c=>c.page===S.page&&(!S.focusCircuit||c.id===S.focusCircuit)&&(!S.filterLegend||c.legendId===S.filterLegend))){
   const active=selected?.id===c.id;
   c.routes.forEach((r,ri)=>{
    if(r.points.length<2)return;const points=r.points.map(p=>p.join(',')).join(' ');
    out.push(`<polyline data-kind="circuit" data-id="${c.id}" points="${points}" fill="none" stroke="transparent" stroke-width="13" vector-effect="non-scaling-stroke" style="cursor:pointer"/><polyline data-kind="circuit" data-id="${c.id}" points="${points}" fill="none" stroke="${r.blocked?'#dc5b5b':c.color}" stroke-width="${active?3:1.9}" stroke-dasharray="${c.manual?'0':'6 4'}" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke" style="cursor:pointer"/>`);
    if(active){r.points.forEach((pt,vi)=>{if(vi>0&&vi<r.points.length-1)out.push(handle(pt[0],pt[1],'circuit',c.id,'route-handle',`data-route="${ri}" data-vertex="${vi}"`));});r.points.slice(1).forEach((pt,vi)=>{const a=r.points[vi],x=(a[0]+pt[0])/2,y=(a[1]+pt[1])/2;out.push(`<rect x="${x-3*unit}" y="${y-3*unit}" width="${6*unit}" height="${6*unit}" fill="white" stroke="${c.color}" stroke-width="1" vector-effect="non-scaling-stroke" data-kind="circuit" data-id="${c.id}" data-role="route-mid" data-route="${ri}" data-vertex="${vi+1}" style="cursor:copy"/>`);});}
   });
   const first=c.routes.find(r=>r.points.length)?.points[0];if(first&&(active||S.layers.labels))out.push(`<text x="${first[0]+8*unit}" y="${first[1]-11*unit}" font-size="${11*unit}" font-weight="700" fill="${c.color}" paint-order="stroke" stroke="white" stroke-width="${3*unit}">${esc(c.name)}${c.stale?' !':''}</text>`);
  }
 }
 if(S.layers.elements){
  const elements=currentElements().filter(e=>inView(e.x,e.y)).slice(0,6000);
  for(const e of elements){const l=legendById(e.legendId),active=selected?.id===e.id,color=e.status==='excluded'?'#a6afbb':l?.color||'#315496',r=Math.max(5*unit,Math.min(e.w||10,e.h||10)/2+2*unit);
   out.push(`<g data-kind="element" data-id="${e.id}" style="cursor:${S.tool==='select'?'pointer':'inherit'}"><circle cx="${e.x}" cy="${e.y}" r="${r+1.5*unit}" fill="white" fill-opacity=".03" stroke="white" stroke-width="3" vector-effect="non-scaling-stroke"/><circle cx="${e.x}" cy="${e.y}" r="${r}" fill="${color}" fill-opacity="${active ? .12 : .015}" stroke="${color}" stroke-width="${active?2.8:1.5}" ${e.status==='pending'?'stroke-dasharray="3 2"':''} vector-effect="non-scaling-stroke"/>${e.status==='validated'?`<circle cx="${e.x+r*.72}" cy="${e.y-r*.72}" r="${2.4*unit}" fill="${color}" stroke="white" stroke-width="1" vector-effect="non-scaling-stroke"/>`:''}${active||S.layers.labels?`<text x="${e.x+r+3*unit}" y="${e.y-r-2*unit}" font-size="${9*unit}" font-weight="600" fill="${color}" paint-order="stroke" stroke="white" stroke-width="${3*unit}">${esc(e.ref)}</text>`:''}</g>`);
  }
 }
 for(const t of p.targets.filter(t=>t.page===S.page)){
  if(!S.layers.circuits&&S.step!==5&&selected?.id!==t.id)continue;
  const r=7*unit;out.push(`<g data-kind="target" data-id="${t.id}" data-role="target-handle" style="cursor:move"><rect x="${t.x-r}" y="${t.y-r}" width="${2*r}" height="${2*r}" rx="${2*unit}" fill="#f4c84e" stroke="#324b79" stroke-width="1.5" vector-effect="non-scaling-stroke"/><text x="${t.x+r+5*unit}" y="${t.y+3*unit}" font-size="${10*unit}" font-weight="600" fill="#324b79" paint-order="stroke" stroke="white" stroke-width="${3*unit}">${esc(t.name)}</text></g>`);
 }
 if(S.points.length){const pts=S.points.map(p=>p.join(',')).join(' ');out.push(`<polyline points="${pts}" fill="none" stroke="#315496" stroke-width="2" stroke-dasharray="5 3" vector-effect="non-scaling-stroke"/>`);S.points.forEach(p=>out.push(`<circle cx="${p[0]}" cy="${p[1]}" r="${4*unit}" fill="#efc443" stroke="#315496" stroke-width="1" vector-effect="non-scaling-stroke"/>`));}
 if(S.rect){out.push(`<rect x="${S.rect[0]}" y="${S.rect[1]}" width="${S.rect[2]}" height="${S.rect[3]}" fill="#315496" fill-opacity=".07" stroke="#315496" stroke-width="1.5" stroke-dasharray="5 3" vector-effect="non-scaling-stroke"/>`);}
 svg.innerHTML=out.join('');
}
function applyCamera(){const c=S.camera;$('#world').style.transform=`translate(${c.x}px,${c.y}px) scale(${c.scale})`;$('#zoom-label').textContent=Math.round(c.scale*100)+' %';scheduleOverlay();scheduleImage();}
function fitPlan(){if(!S.project)return;const d=S.project.document.pages[S.page],v=$('#viewport');S.camera.scale=Math.max(.025,Math.min((v.clientWidth-38)/d.width,(v.clientHeight-38)/d.height));S.camera.x=(v.clientWidth-d.width*S.camera.scale)/2;S.camera.y=(v.clientHeight-d.height*S.camera.scale)/2;applyCamera();}
function worldPoint(clientX,clientY){const rect=$('#viewport').getBoundingClientRect();return [(clientX-rect.left-S.camera.x)/S.camera.scale,(clientY-rect.top-S.camera.y)/S.camera.scale];}
function boundedPoint(p){const d=S.project.document.pages[S.page];return[Math.max(0,Math.min(d.width,p[0])),Math.max(0,Math.min(d.height,p[1]))];}
function zoomAt(factor,x=null,y=null){if(!S.project)return;const v=$('#viewport'),r=v.getBoundingClientRect();x=x??(r.left+v.clientWidth/2);y=y??(r.top+v.clientHeight/2);const p=worldPoint(x,y),sc=Math.min(20,Math.max(.025,S.camera.scale*factor));S.camera={x:x-r.left-p[0]*sc,y:y-r.top-p[1]*sc,scale:sc};applyCamera();}
function scheduleImage(){clearTimeout(S.renderTimer);S.renderTimer=setTimeout(()=>CETiles.render(S),140);}
function loadImage(force=false){
 if(!S.project)return;const id=S.project.id,page=S.page,d=S.project.document.pages[page],key=id+':'+page;
 if(S.lastRender===key&&!force){CETiles.render(S);return;}S.lastRender=key;CETiles.reset();
 const scale=Math.min(1,1100/Math.max(d.width,d.height));const image=new Image();
 image.onload=()=>{if(S.project?.id===id&&S.page===page&&S.lastRender===key)$('#plan-image').src=image.src;};
 image.onerror=()=>{if(S.lastRender===key)S.lastRender=null;};image.src=`/api/projects/${id}/render?page=${page}&scale=${scale}`;
 CETiles.render(S);
}

async function loadPage(fit=true){
 if(!S.project)return;const id=S.project.id,page=S.page,d=S.project.document.pages[page];S.info=null;S.lastRender=null;
 $('#world').style.width=d.width+'px';$('#world').style.height=d.height+'px';$('#overlay').setAttribute('viewBox',`0 0 ${d.width} ${d.height}`);$('#overlay').setAttribute('width',d.width);$('#overlay').setAttribute('height',d.height);
 renderApp();if(fit)fitPlan();loadImage(true);
 const info=await api(`/api/projects/${id}/page?page=${page}`);if(S.project?.id===id&&S.page===page){S.info=info;renderStage();}
}
async function loadProject(project,reset=true){
 S.project=project;S.base=clone(project);S.dirty=false;S.page=0;S.selected=null;S.filterLegend=null;S.filterStatus='all';S.tool='select';S.points=[];S.rect=null;S.info=null;S.targetId=null;S.passageId=null;S.focusCircuit=null;
 if(reset){S.undo=[];S.redo=[];S.step=1;S.catalog='symbols';S.layers={elements:true,rooms:false,circuits:false,labels:false};}
 try{localStorage.setItem('ce-atelier-last-project',project.id);}catch(e){backupFailure(new Error('Le navigateur refuse de memoriser le dernier chantier.'));}persistStatus(window.CE_CLOUD?'Serveur temporaire':'Enregistre sur cet ordinateur');await loadPage();try{await CEVault.checkpoint(S.project,S.dirty);await CEVault.capture(S.project);$('#local-copies').textContent=window.CE_DESKTOP?'Brouillons PC':'Copie navigateur';}catch(e){backupFailure(e);}
}
function setTool(tool){if(!S.project)return;if(tool==='add'&&!S.project.legend.length){toast('Ajoutez d\u2019abord un type de symbole \u00e0 la l\u00e9gende.');return;}S.tool=tool;S.points=[];S.rect=null;renderTools();renderOverlay();closePanels();}
function setStep(step){if(!S.project&&step!==1)return;S.step=step;S.focusCircuit=null;S.tool='select';S.points=[];S.rect=null;S.layers.rooms=step>=4;S.layers.circuits=step===5;S.catalog=step===4?'rooms':'symbols';renderApp();}
function selectItem(type,id){S.selected={type,id};if(type==='legend')S.filterLegend=id;if(type==='zone')S.layers.rooms=true;if(type==='circuit'||type==='target'||type==='passage')S.layers.circuits=true;renderApp();if(window.innerWidth<=1080)showPanel('right');}
function showPanel(panel){$('#left-panel').classList.toggle('open',panel==='left');$('#right-panel').classList.toggle('open',panel==='right');$$('.mobile-nav button').forEach(b=>b.classList.toggle('active',b.dataset.panel===panel));}
function closePanels(){showPanel('canvas');}

async function fileBase64(file){return await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result).split(',')[1]);r.onerror=()=>reject(new Error('Impossible de lire ce fichier.'));r.readAsDataURL(file);});}
async function importFile(file,backup=false){
 if(!file)return;if(file.size>(window.CE_CLOUD?20:100)*1024*1024)throw new Error(window.CE_CLOUD?'Cet essai accepte des fichiers jusqu a 20 Mo.':'Le fichier depasse 100 Mo.');
 await saveNow();busy(true,backup?'Ouverture de la sauvegarde\u2026':'Lecture du plan et pr\u00e9paration du rendu\u2026');
 const data=await fileBase64(file),project=await api(backup?'/api/restore':'/api/import',backup?{data}:{filename:file.name,data});
 await loadProject(project);closePanels();toast(backup?'Sauvegarde restaur\u00e9e dans un nouveau chantier. L\u2019original n\u2019a pas \u00e9t\u00e9 \u00e9cras\u00e9.':'Plan import\u00e9. Passez \u00e0 L\u00e9gende pour choisir les symboles.');
}
async function loadDemo(){await saveNow();busy(true,'Pr\u00e9paration de la maison exemple\u2026');await loadProject(await api('/api/demo',{}));S.step=3;S.layers.elements=true;renderApp();closePanels();toast('Exemple p\u00e9dagogique : cliquez Analyser la l\u00e9gende. Les quantit\u00e9s attendues sont indiqu\u00e9es sur le plan.');}
async function openProjects(){
 try{await saveNow();}catch(e){backupFailure(e);}
 let projects=[];try{projects=(await api('/api/projects')).projects;}catch(e){toast('Serveur indisponible : les copies locales restent accessibles.',true);}
 infoDialog('Mes chantiers',`<p>${window.CE_CLOUD?'Le stockage du serveur d essai est temporaire. Les copies de secours restent dans ce navigateur.':'Chantiers conserves sur cet ordinateur.'}</p>${projects.map(p=>`<button class="project-entry" data-open-project="${p.id}">${icon('folder')}<span class="project-entry-info"><strong>${esc(p.name)}</strong><small>${new Date(p.updatedAt).toLocaleString('fr-FR')} &middot; revision ${p.revision}</small></span></button>`).join('')||'<p>Aucun chantier sur le serveur.</p>'}<div class="modal-actions">${button('local-copies','Copies de secours du navigateur','gold','shield')}${button('dialog-open-backup','Ouvrir un fichier de sauvegarde','outline','folder')}</div>`);
}
async function openLocalCopies(){
 checkpoint();const copies=await CEVault.list();
 infoDialog('Copies de secours - ce navigateur',`<p>Ces copies ne sont ni synchronisees entre appareils, ni une sauvegarde distante. Elles peuvent disparaitre si vous effacez les donnees du site ou utilisez la navigation privee. Telechargez aussi votre fichier .ceprojet.</p>${copies.map(p=>`<div class="project-entry"><span class="project-entry-info"><strong>${esc(p.name)}</strong><small>${new Date(p.at).toLocaleString('fr-FR')} - ${p.dirty?'modifications locales':'copie enregistree'}</small></span><button class="button pale compact" data-recover-copy="${esc(p.key)}">Rouvrir</button><button class="button quiet compact" data-download-copy="${esc(p.key)}">Exporter</button></div>`).join('')||'<p>Aucune copie locale disponible.</p>'}<p>${button('protect-local','Demander la conservation locale','outline','shield')}</p>`);
}
function saveBlob(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);}
async function recoverCopy(key){
 if(S.project&&S.dirty)await CEVault.checkpoint(S.project,true);
 const r=await CEVault.record(key),archive=await CEVault.exportCopy(key);closeModal();busy(true,'Restauration de la copie locale...');
 const restored=await api('/api/restore',{data:await fileBase64(archive)});await loadProject(restored);toast('Copie restauree dans un nouveau chantier. Aucun original ecrase.');
}

function guessFamily(name){if(/spot|luminaire|clair|applique|ruban|suspension|projecteur/i.test(name))return'eclairage';if(/rj45|seau|data/i.test(name))return'reseau';if(/commande|interrupteur|poussoir|knx|bus/i.test(name))return'commande';if(/prise|2p|pc /i.test(name))return'prise';if(/alimentation|sortie/i.test(name))return'alimentation';return'autre';}
async function addExample(rect){
 const replace=S.replacingId?legendById(S.replacingId):null;S.replacingId=null;
 let name=replace?.name||'';if(!name&&S.info){const[x,y,w,h]=rect;const candidates=S.info.texts.filter(t=>t.x>x+w&&t.x<x+w+140&&Math.abs(t.y+t.h/2-y-h/2)<Math.max(h,15));candidates.sort((a,b)=>Math.abs(a.y-y)*2+a.x-x-(Math.abs(b.y-y)*2+b.x-x));name=candidates[0]?.text||'';}
 const family=replace?.family||guessFamily(name),temp={source:{page:S.page,rect}};
 const data=await formDialog(replace?'Remplacer l\u2019exemple':'Ajouter un symbole',`<p>Encadrez uniquement le dessin du symbole. Sa d&eacute;signation reste modifiable.</p><img class="thumbnail-large" src="${cropURL(temp)}" alt="Exemple choisi"><label class="form-field"><span>D&eacute;signation</span><input name="name" required maxlength="160" value="${esc(name)}" placeholder="Ex. : spot encastr&eacute;"></label><label class="form-field"><span>Famille</span><select name="family">${familyOptions(family)}</select></label><label class="checkbox-row"><input name="exclude" type="checkbox" checked>Cet exemple appartient &agrave; la l&eacute;gende : ne pas le compter</label>`,replace?'Remplacer':'Ajouter &agrave; la l\u00e9gende');
 if(!data)return;const palette=['#da2936','#285fbd','#228964','#8660af','#d99022','#597b91'];
 mutate(p=>{if(replace){const l=p.legend.find(x=>x.id===replace.id);l.name=data.get('name');l.family=data.get('family');l.source={page:S.page,rect,excludeFromCount:!!data.get('exclude')};delete l.blockName;l.proposed=false;S.selected={type:'legend',id:l.id};}else{const l={id:uid(),name:data.get('name'),family:data.get('family'),color:palette[p.legend.length%palette.length],source:{page:S.page,rect,excludeFromCount:!!data.get('exclude')},method:'auto',rotations:true,multiScale:true};p.legend.push(l);S.selected={type:'legend',id:l.id};S.filterLegend=l.id;}S.catalog='symbols';});
 toast('Symbole ajout\u00e9. Vous pouvez lancer sa recherche.');
}
async function extractLegend(rect){
 await saveNow();busy(true,'Lecture de la l\u00e9gende\u2026');const before=clone(S.project),r=await api(`/api/projects/${S.project.id}/legend`,{page:S.page,rect});remember(before);ingest(r.project);S.selected=null;S.filterLegend=null;renderApp();
 toast(r.count?`${r.count} lignes propos\u00e9es. V\u00e9rifiez les noms et les dessins avant le comptage.`:'Aucune ligne de l\u00e9gende n\u2019a pu \u00eatre isol\u00e9e. La zone est exclue du comptage ; ajoutez les exemples un par un.');
}
async function legendFromBlocks(){
 if(!S.info)throw new Error('La lecture du DXF est encore en cours.');
 const grouped={};for(const block of S.info.blocks){(grouped[block.name]??=[]).push(block);}
 const names=Object.keys(grouped).sort();if(!names.length){toast('Aucun bloc INSERT exploitable. Utilisez un exemple graphique.');return;}
 const data=await formDialog('Symboles depuis les blocs DXF',`<p>Choisissez les blocs repr&eacute;sentant du mat&eacute;riel. Les noms et les familles restent modifiables.</p><div class="symbol-list-dialog">${names.map(name=>`<label><input type="checkbox" name="blocks" value="${esc(name)}"><span>${esc(name)} <small class="muted">(${grouped[name].length} insertions)</small></span></label>`).join('')}</div>`,'Ajouter les blocs choisis');
 if(!data)return;const chosen=data.getAll('blocks');if(!chosen.length)return;
 mutate(p=>{for(const name of chosen){if(p.legend.some(l=>l.blockName===name))continue;const b=grouped[name][0];p.legend.push({id:uid(),name,family:guessFamily(name),color:['#da2936','#285fbd','#228964','#8660af'][p.legend.length%4],blockName:name,source:{page:S.page,rect:[b.x-b.w/2-2,b.y-b.h/2-2,b.w+4,b.h+4],excludeFromCount:false},method:'block',rotations:true,multiScale:true});}S.filterLegend=null;});
}
async function addZone(points,type='room'){
 if(points.length<3||area(points)<1){toast('Dessinez un contour plus grand.');return;}
 const base=type==='room'?'Pi\u00e8ce':type==='obstacle'?'Obstacle':'Hors comptage',n=S.project.zones.filter(z=>z.type===type).length+1;
 const data=await formDialog(type==='room'?'Nouvelle pi\u00e8ce':type==='obstacle'?'Passage interdit':'Zone hors comptage',`<label class="form-field"><span>Nom de la zone</span><input name="name" value="${esc(base+' '+n)}" required maxlength="160"></label>${type==='room'?`<label class="form-field"><span>Pi&egrave;ce parente (facultatif)</span><select name="parentId">${zoneOptions(null,true)}</select></label>`:`<p>${type==='obstacle'?'Les circuits propos&eacute;s ne pourront pas traverser ce contour.':'Les prochaines recherches ignoreront cette zone. Les rep&egrave;res existants restent modifiables.'}</p>`}`,'Cr\u00e9er la zone');
 if(!data)return;const parent=data.get('parentId')||null;if(parent&&!points.every(pt=>pointInside(pt,zoneById(parent).points)))throw new Error('La sous-pi\u00e8ce doit \u00eatre contenue dans sa pi\u00e8ce parente.');
 mutate(p=>{const z={id:uid(),name:data.get('name'),page:S.page,points,parentId:parent,type,confirmed:true,color:type==='obstacle'?'#d16b67':type==='exclude'?'#91a0b4':['#3d70c9','#c39b2b','#39877a','#9b78bc','#d77855','#557ca0'][p.zones.length%6]};p.zones.push(z);S.selected={type:'zone',id:z.id};S.layers.rooms=true;S.catalog='rooms';});
}
async function finishShape(){
 const tool=S.tool,points=[];for(const pt of S.points)if(!points.length||dist(pt,points.at(-1))>.05)points.push(pt);
 if(points.length>2&&dist(points[0],points.at(-1))<.05)points.pop();
 if(tool==='passage'){
  if(points.length<2){toast('Placez au moins deux points.');return;}
  setTool('select');const data=await formDialog('Nouveau passage impos\u00e9','<label class="form-field"><span>Nom</span><input name="name" required value="Passage principal" maxlength="160"></label><p>Les circuits rejoignent ce passage pour aller au tableau. Son dessin sera respect&eacute;, sauf s\u2019il traverse un obstacle.</p>','Cr\u00e9er le passage');if(!data)return;
  mutate(p=>{const passage={id:uid(),page:S.page,name:data.get('name'),points};p.passages.push(passage);S.passageId=passage.id;S.selected={type:'passage',id:passage.id};});return;
 }
 if(points.length<3){toast('Placez au moins trois sommets.');return;}
 setTool('select');await addZone(points,tool==='room'?'room':tool);
}
async function addTarget(pt){const data=await formDialog('Placer un tableau','<label class="form-field"><span>Nom du tableau ou du point d\u2019arriv&eacute;e</span><input name="name" value="Tableau principal" required maxlength="160"></label>','Placer');if(!data)return;mutate(p=>{const t={id:uid(),page:S.page,name:data.get('name'),x:pt[0],y:pt[1]};p.targets.push(t);S.targetId=t.id;S.selected={type:'target',id:t.id};});}
async function addElement(pt){
 const def=S.filterLegend||S.project.legend[0]?.id;if(!def)return;
 const data=await formDialog('Ajouter un \u00e9quipement oubli\u00e9',`<label class="form-field"><span>Type</span><select name="legendId">${S.project.legend.map(l=>`<option value="${l.id}" ${l.id===def?'selected':''}>${esc(l.name)}</option>`).join('')}</select></label><p>Ce rep&egrave;re est plac&eacute; manuellement et sera compt&eacute; comme valid&eacute;.</p>`,'Ajouter et valider');
 if(!data)return;if(S.project.elements.some(e=>e.page===S.page&&e.status!=='excluded'&&dist(pt,[e.x,e.y])<3))throw new Error('Un \u00e9quipement existe d\u00e9j\u00e0 \u00e0 cette position.');
 mutate(p=>{const number=Math.max(0,...p.elements.map(e=>Number(e.ref?.split('-').at(-1))||0))+1;const e={id:uid(),ref:'E-'+String(number).padStart(3,'0'),legendId:data.get('legendId'),page:S.page,x:pt[0],y:pt[1],w:10,h:10,status:'validated',manual:true,score:1,method:'manuel',notes:''};p.elements.push(e);S.selected={type:'element',id:e.id};});
}
async function calibrate(points){
 const length=dist(points[0],points[1]);if(length<.1)throw new Error('Les deux points doivent \u00eatre distincts.');
 const data=await formDialog('D\u00e9finir l\u2019\u00e9chelle','<p>Saisissez la longueur r&eacute;elle entre les deux points choisis. Les mesures de cette page seront recalcul&eacute;es.</p><label class="form-field"><span>Distance r&eacute;elle, en m&egrave;tres</span><input name="meters" type="number" min="0.001" max="100000" step="any" required placeholder="Ex. : 4.20"></label>','Valider l\u2019\u00e9chelle');
 if(!data)return;const meters=Number(data.get('meters'));if(!(meters>0))throw new Error('Saisissez une distance positive.');mutate(p=>p.scales[String(S.page)]=meters/length);toast('\u00c9chelle enregistr\u00e9e pour cette page.');
}
async function runAnalysis(ids=null){
 if(S.job)return;if(!S.project.legend.length)throw new Error('Ajoutez d\u2019abord des symboles \u00e0 la l\u00e9gende.');
 await saveNow();const projectId=S.project.id,r=await api(`/api/projects/${projectId}/analyze`,{page:S.page,legendIds:ids||S.project.legend.map(l=>l.id),threshold:S.project.config.threshold});
 S.job={id:r.jobId,projectId,progress:0,message:'Pr\u00e9paration de l\u2019analyse'};S.step=3;S.layers.elements=true;renderApp();closePanels();pollJob(r.jobId,projectId);
}
async function pollJob(id,projectId){
 try{
  const result=await api(`/api/jobs/${id}`);if(!S.job||S.job.id!==id)return;S.job={...S.job,...result};renderAnalysis();
  if(result.status==='running'){setTimeout(()=>pollJob(id,projectId),450);return;}
  if(S.project?.id===projectId){await saveNow();remember();ingest(await api(`/api/projects/${projectId}`));renderApp();}
  S.job=null;renderApp();toast(result.message,result.status==='error',9000);if(result.result?.warnings?.length)infoDialog('Symboles a verifier',result.result.warnings.map(w=>'<p>'+esc(w)+'</p>').join(''));checkpoint();if(result.result?.occupied)toast(`${result.result.occupied} propositions proches d\u2019un rep\u00e8re d\u00e9j\u00e0 enregistr\u00e9 n\u2019ont pas \u00e9t\u00e9 ajout\u00e9es (doublons ou corrections conserv\u00e9es).`,false,9000);
 }catch(e){S.job=null;renderApp();toast(e.message,true,10000);}
}
async function proposeRooms(){await saveNow();busy(true,'Recherche de noms et de contours de pi\u00e8ces\u2026');remember();const r=await api(`/api/projects/${S.project.id}/rooms`,{page:S.page});ingest(r.project);S.step=4;S.catalog='rooms';S.layers.rooms=true;S.selected=null;renderApp();toast(`${r.count} contour${r.count>1?'s':''} propos\u00e9${r.count>1?'s':''}. ${r.message}`,false,10000);}
async function generateCircuits(){
 if(!S.targetId)throw new Error('Placez puis choisissez un tableau sur la page.');await saveNow();busy(true,'Construction des circuits et recherche des passages\u2026');remember();const r=await api(`/api/projects/${S.project.id}/circuits`,{page:S.page,targetId:S.targetId,passageId:S.passageId});ingest(r.project);S.layers.circuits=true;S.filterLegend=null;S.selected=null;renderApp();
 toast(`${r.report.circuits} circuits pr\u00e9par\u00e9s. ${r.report.blocked?`${r.report.blocked} liaison(s) bloqu\u00e9e(s). `:''}${r.report.unassigned?`${r.report.unassigned} \u00e9quipement(s) sans pi\u00e8ce non utilis\u00e9(s). `:''}${r.report.kept?`${r.report.kept} circuit(s) modifi\u00e9(s) conserv\u00e9(s).`:''}`,!!r.report.blocked,10000);
}
async function validateVisible(){const elements=currentElements().filter(e=>e.status==='pending');if(!elements.length)return;if(!(await confirmDialog('Valider les rep\u00e8res affich\u00e9s',`Confirmez que vous avez v\u00e9rifi\u00e9 les ${elements.length} propositions du filtre actif. Cette action les compte comme valid\u00e9es.`,'Valider les '+elements.length+' rep\u00e8res')))return;const ids=new Set(elements.map(e=>e.id));mutate(p=>p.elements.forEach(e=>{if(ids.has(e.id))e.status='validated';}));toast('Rep\u00e8res valid\u00e9s. Vous pouvez passer aux pi\u00e8ces.');}
function showReport(){
 if(!S.project)return;const p=S.project,rows=p.legend.map(l=>({name:l.name,...totalCounts(p.elements.filter(e=>e.legendId===l.id))}));
 infoDialog('R\u00e9capitulatif du chantier',`<p><strong>${esc(p.name)}</strong><br>${p.document.pages.length} page(s). Les quantit&eacute;s ci-dessous couvrent toutes les pages, sans double comptage des sous-pi&egrave;ces.</p><table class="report-table"><thead><tr><th>D&eacute;signation</th><th>Valid&eacute;s</th><th>&Agrave; v&eacute;rifier</th><th>Exclus</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(r.name)}</td><td>${r.validated}</td><td>${r.pending}</td><td>${r.excluded}</td></tr>`).join('')}</tbody></table><div class="notice">Les longueurs d&eacute;pendent de l'&eacute;chelle et des r&eacute;serves renseign&eacute;es. Le trac&eacute; ne vaut pas validation technique ou r&eacute;glementaire.</div><div class="export-grid"><button data-export="pdf" class="button primary">${icon('report')}Plan annot&eacute; PDF</button><button data-export="csv" class="button outline">${icon('report')}Quantit&eacute;s pour Excel (CSV)</button><button data-export="svg" class="button outline">${icon('route')}Page vectorielle modifiable (SVG)</button><button data-export="project" class="button gold">${icon('save')}Sauvegarde avec plan source</button></div><p class="microcopy">PDF : toutes les pages et un r&eacute;capitulatif. SVG : page active. Sauvegarde .ceprojet : travail enti&egrave;rement modifiable dans cet atelier.</p>`);
}
async function download(kind){
 if(kind==='project'){
  if(!S.project)return;
  try{await saveNow();}catch(e){toast('Serveur indisponible : export de votre copie locale.',false);}
  try{const blob=await CEVault.portable(S.project,S.dirty);saveBlob(blob,(S.project.name||'Chantier').replace(/[^a-z0-9_-]/gi,'_')+'.ceprojet');toast('Sauvegarde avec le plan source et vos dernieres modifications.');return;}catch(e){backupFailure(e);}
 }
 await saveNow();const r=await fetch(`/api/projects/${S.project.id}/export?kind=${kind}&page=${S.page}`,{cache:'no-store'});
 if(!r.ok){const e=await r.json();throw new Error(e.error||'Export indisponible.');}
 const suffix={project:'ceprojet',pdf:'pdf',csv:'csv',svg:'svg'}[kind];saveBlob(await r.blob(),S.project.name.replace(/[^a-z0-9_-]/gi,'_')+'.'+suffix);
}

async function removeSelected(){
 const item=selectedObject(),type=S.selected?.type;if(!item)return;
 const count=type==='legend'?S.project.elements.filter(e=>e.legendId===item.id).length:0;
 if(!(await confirmDialog('Supprimer la s\u00e9lection',type==='legend'?`Supprimer ce type de symbole et ses ${count} rep\u00e8res ? Les circuits associ\u00e9s seront aussi retir\u00e9s.`:`Supprimer \u00ab ${item.name||item.ref} \u00bb ? Vous pourrez annuler cette action.`,'Supprimer')))return;
 mutate(p=>{const key={legend:'legend',element:'elements',zone:'zones',circuit:'circuits',target:'targets',passage:'passages'}[type];p[key]=p[key].filter(x=>x.id!==item.id);if(type==='legend'){const ids=new Set(p.elements.filter(e=>e.legendId===item.id).map(e=>e.id));p.elements=p.elements.filter(e=>e.legendId!==item.id);p.circuits=p.circuits.filter(c=>c.legendId!==item.id&&!c.elementIds.some(id=>ids.has(id)));S.filterLegend=null;}if(type==='zone'){p.zones.forEach(z=>{if(z.parentId===item.id)z.parentId=null;});p.elements.forEach(e=>{if(e.roomId===item.id)e.roomManual=false;});}S.selected=null;});
}
function undo(){if(!S.undo.length||!S.project)return;const revision=S.project.revision;S.redo.push(clone(S.project));S.project=S.undo.pop();S.project.revision=revision;S.selected=null;changed();renderApp();}
function redo(){if(!S.redo.length||!S.project)return;const revision=S.project.revision;S.undo.push(clone(S.project));S.project=S.redo.pop();S.project.revision=revision;S.selected=null;changed();renderApp();}
function nextPending(){const els=currentElements().filter(e=>e.status==='pending');if(!els.length){toast('Plus de proposition \u00e0 v\u00e9rifier dans ce filtre.');return;}const ix=els.findIndex(e=>e.id===S.selected?.id),e=els[(ix+1)%els.length];S.selected={type:'element',id:e.id};renderApp();const v=$('#viewport');S.camera.x=v.clientWidth/2-e.x*S.camera.scale;S.camera.y=v.clientHeight/2-e.y*S.camera.scale;applyCamera();}

const actions={
 'import-plan':()=>$('#file-input').click(),'welcome-import':()=>$('#file-input').click(),'open-backup':()=>$('#backup-input').click(),
 'load-demo':loadDemo,'open-projects':openProjects,'local-copies':openLocalCopies,'protect-local':async()=>{toast(await CEVault.protect()?'Conservation locale autorisee. Gardez aussi une sauvegarde externe.':'Le navigateur n a pas accorde la conservation. Exportez regulierement votre projet.');},'save-project':()=>download('project'),
 'dialog-import':()=>{closeModal();$('#file-input').click();},'dialog-open-backup':()=>{closeModal();$('#backup-input').click();},
 'catalog-add':()=>setTool(S.catalog==='rooms'?'room':'sample'),
 'tab-symbols':()=>{S.catalog='symbols';renderCatalog();},'tab-rooms':()=>{S.catalog='rooms';renderCatalog();},
 'start-legend':()=>setTool('legend'),'start-sample':()=>{S.replacingId=null;setTool('sample');},'start-exclude':()=>setTool('exclude'),
 'start-room':()=>setTool('room'),'start-roomRect':()=>setTool('roomRect'),'start-target':()=>setTool('target'),
 'start-passage':()=>setTool('passage'),'start-obstacle':()=>setTool('obstacle'),'calibrate':()=>setTool('measure'),
 'from-blocks':legendFromBlocks,'propose-rooms':proposeRooms,'generate-circuits':generateCircuits,
 'analyze-all':()=>runAnalysis(),'analyze-selected':()=>S.selected?.type==='legend'?runAnalysis([S.selected.id]):null,
 'validate-visible':validateVisible,'show-report':showReport,
 'replace-sample':()=>{S.replacingId=S.selected?.id;setTool('sample');},
 'validate-selected':()=>mutate(p=>{const e=p.elements.find(e=>e.id===S.selected?.id);if(e)e.status='validated';}),
 'exclude-selected':()=>mutate(p=>{const e=p.elements.find(e=>e.id===S.selected?.id);if(e)e.status='excluded';}),
 'validate-zone':()=>mutate(p=>{const z=p.zones.find(e=>e.id===S.selected?.id);if(z)z.confirmed=true;}),
 'toggle-lock':()=>mutate(p=>{const c=p.circuits.find(c=>c.id===S.selected?.id);if(c)c.manual=!c.manual;}),
 'remove-selected':removeSelected,'next-pending':nextPending,'deselect':()=>{S.selected=null;renderApp();},
 'clear-filter':()=>{S.filterLegend=null;S.selected=null;renderApp();},
 'undo':undo,'redo':redo,'zoom-in':()=>zoomAt(1.25),'zoom-out':()=>zoomAt(.8),'fit':fitPlan,'zoom-label':fitPlan,
 'finish-shape':finishShape,'cancel-tool':()=>setTool('select'),
 'cancel-analysis':async()=>{if(S.job){await api(`/api/jobs/${S.job.id}/cancel`,{});S.job.message='Annulation demand\u00e9e\u2026';renderAnalysis();}},
 'document-details':()=>{if(!S.project)return;const d=S.project.document,i=S.info;infoDialog('Informations du plan',`<p><strong>${esc(d.filename)}</strong></p><div class="data-line"><span>Format</span><strong>${esc(d.kind.toUpperCase())}</strong></div><div class="data-line"><span>Pages</span><strong>${d.pages.length}</strong></div><div class="data-line"><span>Objets vectoriels (page active)</span><strong>${i?.vectorCount??'Lecture en cours'}</strong></div><div class="data-line"><span>Textes exploitables</span><strong>${i?.textCount??'Lecture en cours'}</strong></div><div class="data-line"><span>Blocs DXF</span><strong>${i?.blocks?.length||0}</strong></div>${(d.warnings||[]).map(w=>`<div class="notice">${esc(w)}</div>`).join('')}<p class="microcopy">Les scans n\u2019ont pas les m&ecirc;mes informations qu\u2019un plan vectoriel. Aucun OCR ni service distant n\u2019est activ&eacute;.</p>`);},
 'project-name':async()=>{if(!S.project)return;const d=await formDialog('Renommer le chantier',`<label class="form-field"><span>Nom du chantier</span><input name="name" required maxlength="120" value="${esc(S.project.name)}"></label>`);if(d)mutate(p=>p.name=d.get('name'));}
};

document.addEventListener('click',e=>{
 const b=e.target.closest('button');if(!b||b.disabled)return;
 if(b.hasAttribute('data-close-modal')){e.preventDefault();closeModal();return;}
 if(b.dataset.step){setStep(Number(b.dataset.step));return;}
 if(b.dataset.tool){setTool(b.dataset.tool);return;}
 if(b.dataset.panel){showPanel(b.dataset.panel);return;}
 if(b.dataset.selectId){selectItem(b.dataset.selectType,b.dataset.selectId);return;}
 if(b.dataset.layer){S.layers[b.dataset.layer]=!S.layers[b.dataset.layer];renderTools();renderOverlay();return;}
 if(b.dataset.pageShift){guarded(async()=>{await saveNow();S.page+=Number(b.dataset.pageShift);S.selected=null;S.points=[];S.rect=null;S.tool='select';await loadPage();});return;}
 if(b.dataset.recoverCopy){guarded(()=>recoverCopy(b.dataset.recoverCopy));return;}
 if(b.dataset.downloadCopy){guarded(async()=>{saveBlob(await CEVault.exportCopy(b.dataset.downloadCopy),'Cedric_Elec_Secours.ceprojet');});return;}
 if(b.dataset.openProject){guarded(async()=>{await saveNow();closeModal();busy(true,'Ouverture du chantier\u2026');await loadProject(await api(`/api/projects/${b.dataset.openProject}`));});return;}
 if(b.dataset.export){guarded(()=>download(b.dataset.export));return;}
 if(actions[b.id]){e.preventDefault();guarded(actions[b.id]);}
});
document.addEventListener('change',e=>{
 const el=e.target;if(el.id==='file-input'||el.id==='backup-input'){const file=el.files[0];el.value='';guarded(()=>importFile(file,el.id==='backup-input'));return;}
 if(el.id==='circuit-focus'){S.focusCircuit=el.value||null;S.filterLegend=null;S.selected=S.focusCircuit?{type:'circuit',id:S.focusCircuit}:null;renderApp();return;}
 if(el.id==='filter-status'){S.filterStatus=el.value;renderApp();return;}
 if(el.id==='threshold'){mutate(p=>p.config.threshold=Number(el.value)/100);return;}
 if(el.id==='domotique'){mutate(p=>p.config.domotique=el.checked);return;}
 if(el.id==='target-choice'){S.targetId=el.value||null;renderStage();return;}
 if(el.id==='passage-choice'){S.passageId=el.value||null;return;}
 if(el.dataset.field&&S.selected){
  const item=selectedObject(),type=S.selected.type,key=el.dataset.field;if(!item)return;
  let value=el.type==='checkbox'?el.checked:el.type==='number'?Number(el.value):el.value;
  if(key==='extraMeters'&&(!Number.isFinite(value)||value<0)){toast('Saisissez une longueur positive.',true);renderInspector();return;}
  if(key==='parentId'&&value){let par=value;const seen=new Set([item.id]);while(par){if(seen.has(par)){toast('Une pi\u00e8ce ne peut pas \u00eatre sa propre parente.',true);renderInspector();return;}seen.add(par);par=zoneById(par)?.parentId;}if(!item.points.every(pt=>pointInside(pt,zoneById(value).points))){toast('La sous-pi\u00e8ce doit \u00eatre dans la pi\u00e8ce parente.',true);renderInspector();return;}}
  mutate(p=>{const obj=selectedObject();if(key==='sourceCounted'){if(obj.source)obj.source.excludeFromCount=!value;}
   else {obj[key]=key==='name'?(String(value).trim()||'Sans nom'):key==='parentId'||key==='roomId'?(value||null):value;}
   if(type==='legend')obj.proposed=false;
   if(type==='element'&&key==='roomId')obj.roomManual=!!value;
   if(type==='element'&&key==='legendId'){obj.manual=true;obj.status='pending';}
  });
 }
});
document.addEventListener('input',e=>{if(e.target.id==='threshold')$('#threshold-value').textContent=e.target.value+' %';});
$('#modal').addEventListener('cancel',e=>{e.preventDefault();closeModal();});

const viewport=$('#viewport');let spaceDown=false;
function pointerDown(e){
 if(!S.project||e.button===2)return;
 viewport.setPointerCapture(e.pointerId);S.pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
 if(S.pointers.size===2){
  const pts=[...S.pointers.values()],mid=[(pts[0].x+pts[1].x)/2,(pts[0].y+pts[1].y)/2];
  if(S.drag?.mode==='object'&&S.drag.snapshot)S.project=S.drag.snapshot;
  S.pinch={distance:Math.hypot(pts[0].x-pts[1].x,pts[0].y-pts[1].y),scale:S.camera.scale,anchor:worldPoint(...mid)};S.drag=null;S.rect=null;S.gesture=true;return;
 }
 if(S.pointers.size>1)return;
 const point=worldPoint(e.clientX,e.clientY),bounded=boundedPoint(point),target=e.target.closest('[data-kind]');
 if(S.tool==='pan'||spaceDown||e.button===1){S.drag={mode:'pan',start:[e.clientX,e.clientY],camera:{...S.camera},moved:false};viewport.classList.add('dragging');return;}
 if(['sample','legend','roomRect'].includes(S.tool)){S.drag={mode:'rect',start:bounded,tool:S.tool};S.rect=[...bounded,0,0];renderOverlay();return;}
 if(S.tool==='select'&&target){
  const type=target.dataset.kind,id=target.dataset.id,role=target.dataset.role;
  S.selected={type,id};const object=selectedObject(),snapshot=clone(S.project);
  S.drag={mode:'object',type,id,role,start:point,clientStart:[e.clientX,e.clientY],original:clone(object),snapshot,dirty:false,vertex:Number(target.dataset.vertex),route:Number(target.dataset.route)};
  if(role==='route-mid'){
   const route=object.routes[S.drag.route],i=S.drag.vertex,a=route.points[i-1],b=route.points[i];route.points.splice(i,0,[(a[0]+b[0])/2,(a[1]+b[1])/2]);object.manual=true;S.drag.role='route-handle';S.drag.dirty=true;
  }
  renderInspector();renderCatalog();renderOverlay();return;
 }
 if(S.tool==='select'){S.drag={mode:'pan',start:[e.clientX,e.clientY],camera:{...S.camera},moved:false,deselect:true};return;}
 S.drag={mode:'click',tool:S.tool,start:point,clientStart:[e.clientX,e.clientY]};
}
function pointerMove(e){
 if(!S.project)return;
 if(S.pointers.has(e.pointerId))S.pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
 if(S.pinch&&S.pointers.size>=2){const pts=[...S.pointers.values()],mid=[(pts[0].x+pts[1].x)/2,(pts[0].y+pts[1].y)/2],r=viewport.getBoundingClientRect(),d=Math.hypot(pts[0].x-pts[1].x,pts[0].y-pts[1].y);const scale=Math.min(20,Math.max(.025,S.pinch.scale*d/Math.max(1,S.pinch.distance)));S.camera={x:mid[0]-r.left-S.pinch.anchor[0]*scale,y:mid[1]-r.top-S.pinch.anchor[1]*scale,scale};applyCamera();return;}
 const drag=S.drag;if(!drag)return;const p=boundedPoint(worldPoint(e.clientX,e.clientY));
 if(drag.mode==='pan'){const dx=e.clientX-drag.start[0],dy=e.clientY-drag.start[1];if(Math.hypot(dx,dy)>2)drag.moved=true;S.camera.x=drag.camera.x+dx;S.camera.y=drag.camera.y+dy;applyCamera();return;}
 if(drag.mode==='rect'){S.rect=[Math.min(drag.start[0],p[0]),Math.min(drag.start[1],p[1]),Math.abs(drag.start[0]-p[0]),Math.abs(drag.start[1]-p[1])];scheduleOverlay();return;}
 if(drag.mode!=='object')return;
 if(Math.hypot(e.clientX-drag.clientStart[0],e.clientY-drag.clientStart[1])<3&&!drag.dirty)return;
 const object=selectedObject();if(!object)return;
 if(drag.type==='element'||drag.type==='target'){
  const position=boundedPoint([drag.original.x+p[0]-drag.start[0],drag.original.y+p[1]-drag.start[1]]);object.x=position[0];object.y=position[1];if(drag.type==='element'){object.manual=true;object.roomManual=false;}drag.dirty=true;
 }else if(drag.role==='zone-handle'||drag.role==='passage-handle'){object.points[drag.vertex]=p;drag.dirty=true;}
 else if(drag.role==='route-handle'){
  const route=object.routes[drag.route];let position=p;
  if(e.shiftKey){const before=route.points[drag.vertex-1];if(before)position=Math.abs(p[0]-before[0])>Math.abs(p[1]-before[1])?[p[0],before[1]]:[before[0],p[1]];}
  route.points[drag.vertex]=position;object.manual=true;drag.dirty=true;
 }
 if(drag.dirty)scheduleOverlay();
}
function pointerUp(e){
 if(!S.project)return;S.pointers.delete(e.pointerId);
 if(S.gesture){if(!S.pointers.size){S.gesture=false;S.pinch=null;S.drag=null;}return;}
 const drag=S.drag;S.drag=null;viewport.classList.remove('dragging');if(!drag)return;
 if(drag.mode==='pan'){if(!drag.moved&&drag.deselect){S.selected=null;renderApp();}return;}
 if(drag.mode==='object'){
  if(drag.dirty){remember(drag.snapshot);assignRooms();changed();renderApp();}
  else if(window.innerWidth<=1080)showPanel('right');
  return;
 }
 if(drag.mode==='rect'){
  const rect=S.rect;S.rect=null;const tool=drag.tool;setTool('select');
  if(!rect||rect[2]*S.camera.scale<5||rect[3]*S.camera.scale<5){toast('Glissez pour encadrer une zone plus grande.');return;}
  guarded(async()=>{if(tool==='sample')await addExample(rect);else if(tool==='legend')await extractLegend(rect);else await addZone([[rect[0],rect[1]],[rect[0]+rect[2],rect[1]],[rect[0]+rect[2],rect[1]+rect[3]],[rect[0],rect[1]+rect[3]]]);});return;
 }
 if(drag.mode==='click'){
  if(Math.hypot(e.clientX-drag.clientStart[0],e.clientY-drag.clientStart[1])>8)return;
  const point=worldPoint(e.clientX,e.clientY),bounds=S.project.document.pages[S.page];if(point[0]<0||point[1]<0||point[0]>bounds.width||point[1]>bounds.height)return;
  if(['room','obstacle','exclude','passage','measure'].includes(drag.tool)){
   if(!S.points.length||dist(point,S.points.at(-1))>1/S.camera.scale)S.points.push(point);renderOverlay();
   if(drag.tool==='measure'&&S.points.length===2){const pts=clone(S.points);setTool('select');guarded(()=>calibrate(pts));}
  }else if(drag.tool==='target'){setTool('select');guarded(()=>addTarget(point));}
  else if(drag.tool==='add'){setTool('select');guarded(()=>addElement(point));}
 }
}
viewport.addEventListener('pointerdown',pointerDown);viewport.addEventListener('pointermove',pointerMove);viewport.addEventListener('pointerup',pointerUp);
viewport.addEventListener('pointercancel',e=>{S.pointers.delete(e.pointerId);if(S.drag?.mode==='object'&&S.drag.snapshot)S.project=S.drag.snapshot;S.drag=null;S.pinch=null;S.gesture=false;S.rect=null;viewport.classList.remove('dragging');renderOverlay();});
viewport.addEventListener('wheel',e=>{if(!S.project)return;e.preventDefault();zoomAt(Math.exp(-e.deltaY*.0015),e.clientX,e.clientY);},{passive:false});
viewport.addEventListener('dblclick',e=>{if(['room','obstacle','exclude','passage'].includes(S.tool)){e.preventDefault();guarded(finishShape);}});
viewport.addEventListener('contextmenu',e=>e.preventDefault());
window.addEventListener('keydown',e=>{
 if($('#modal').open)return;if(['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName)||e.target.isContentEditable)return;
 if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'){e.preventDefault();e.shiftKey?redo():undo();return;}
 if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='y'){e.preventDefault();redo();return;}
 if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'){e.preventDefault();if(S.project)guarded(()=>download('project'));return;}
 if(e.key==='Escape'){setTool('select');closePanels();return;}
 if(e.key===' '){e.preventDefault();spaceDown=true;return;}
 if(e.key.toLowerCase()==='v')setTool('select');if(e.key.toLowerCase()==='h')setTool('pan');
 if(e.key==='Enter'&&['room','exclude','obstacle','passage'].includes(S.tool))guarded(finishShape);
 if(e.key==='Delete'&&S.selected)guarded(removeSelected);
});
window.addEventListener('keyup',e=>{if(e.key===' ')spaceDown=false;});
window.addEventListener('blur',()=>{spaceDown=false;});
window.addEventListener('beforeunload',e=>{if(S.dirty){e.preventDefault();e.returnValue='';}});
window.addEventListener('dragover',e=>{e.preventDefault();viewport.classList.add('drop-active');});
window.addEventListener('dragleave',e=>{if(!e.relatedTarget)viewport.classList.remove('drop-active');});
window.addEventListener('drop',e=>{e.preventDefault();viewport.classList.remove('drop-active');const file=e.dataTransfer?.files?.[0];if(file)guarded(()=>importFile(file,/\.(ceprojet|zip)$/i.test(file.name)));});
let resizeTimer;window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{if(S.project)fitPlan();},180);});

async function init(){
 renderApp();try{const health=await api('/api/health');S.dataDirectory=health.dataDirectory||'Serveur prive - stockage temporaire';}catch(e){toast('Le serveur est indisponible. Les copies du navigateur peuvent etre exportees.',true);}
 let last=null;try{last=localStorage.getItem('ce-atelier-last-project');}catch(e){backupFailure(e);}if(last){
  let cached=null;try{cached=await CEVault.latest(last);}catch(e){backupFailure(e);}
  try{
   const remote=await api(`/api/projects/${last}`);
   if(cached?.dirty){if(await confirmDialog('Modifications locales retrouvees','Une copie contient des modifications non confirmees par le serveur. Ouvrir cette copie sans ecraser le chantier du serveur ?','Rouvrir la copie')){await recoverCopy(cached.key);return;}}
   await loadProject(remote);
  }catch(e){if(cached){toast('Le chantier n est plus sur le serveur. Votre copie locale est disponible.');await openLocalCopies();}else{toast('Rouvrez un fichier .ceprojet pour recuperer votre chantier.',true);}}
 }
}
// Etat lisible depuis les outils du navigateur pour faciliter les diagnostics locaux.
window.CE_ATELIER={tiles:CETiles,backup:CEVault,get snapshot(){return clone({project:S.project,page:S.page,step:S.step,camera:S.camera,selected:S.selected,tool:S.tool,job:S.job});},save:saveNow};
if(!window.CE_DESKTOP)guarded(init);else renderApp();
