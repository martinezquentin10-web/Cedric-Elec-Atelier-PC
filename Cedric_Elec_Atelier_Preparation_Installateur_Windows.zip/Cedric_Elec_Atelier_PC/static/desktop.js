'use strict';
// Only active inside the packaged local application, never on the hosted site.
window.CEDesktop = (() => {
 let readyResolve;const ready=new Promise(r=>readyResolve=r);let booted=false,sequence=0;
 async function native(method,...args){await ready;const r=await window.pywebview.api[method](...args);if(!r?.ok)throw new Error(r?.error||'Action locale impossible.');return r;}
 async function activate(){
  if(booted)return;booted=true;readyResolve();
  try{
   const info=await native('info');S.dataDirectory=info.directory;
   $('#local-copies').textContent='Brouillons PC';
   $('#local-copies').title='Brouillons enregistres sur le disque de cet ordinateur';
   if(!S.project&&info.recentProjectId)await loadProject(await api('/api/projects/'+info.recentProjectId));
   const copies=await native('recovery_list');
   if(copies.copies.length)toast('Des modifications non confirmees sont disponibles dans Brouillons PC.',false,12000);
  }catch(e){toast(e.message,true,12000);}
 }
 const capture=CEVault.capture;
 CEVault.capture=async project=>window.CE_DESKTOP?true:capture(project);
 const checkpointOld=CEVault.checkpoint;
 CEVault.checkpoint=async (project,dirty=false)=>{
  if(!window.CE_DESKTOP)return checkpointOld(project,dirty);
  if(!project)return true;
  await native('checkpoint',clone(project),++sequence,dirty);return true;
 };
 const downloadOld=download;
 download=async kind=>{
  if(!window.CE_DESKTOP)return downloadOld(kind);
  if(!S.project)return;
  await saveNow();
  const r=await native('save_export',S.project.id,kind,S.page);
  if(!r.cancelled)toast('Fichier enregistre : '+r.filename);
 };
 const saveBlobOld=saveBlob;
 saveBlob=async (blob,name)=>{
  if(!window.CE_DESKTOP)return saveBlobOld(blob,name);
  try{const b64=await fileBase64(blob);const r=await native('save_blob',name,b64);if(!r.cancelled)toast('Fichier enregistre : '+r.filename);}
  catch(e){toast(e.message,true,10000);}
 };
 async function recovery(){
  await saveNow();
  const {copies}=await native('recovery_list');
  infoDialog('Brouillons conserves sur ce PC',`<p>La recuperation cree une copie independante. Elle ne remplace jamais le chantier existant.</p>${copies.length?copies.map(c=>`<p><strong>${esc(c.name)}</strong><br>${esc(c.at)}<br><button class="button outline" data-desktop-recovery="${esc(c.key)}">Recuperer une copie</button></p>`).join(''):'<p>Aucune modification non confirmee a recuperer.</p>'}<p class="microcopy">Ces copies sont sur le meme disque. Une sauvegarde sur un disque externe reste necessaire contre une panne du PC.</p>`);
 }
 document.addEventListener('click',e=>{
  const target=e.target.closest('button');
  if(target?.id==='local-copies'){e.preventDefault();e.stopImmediatePropagation();guarded(recovery);}
  if(target?.dataset.desktopRecovery){e.preventDefault();e.stopImmediatePropagation();guarded(async()=>{const r=await native('recover',target.dataset.desktopRecovery);closeModal();await loadProject(r.project);toast('Copie recuperee. Le chantier d\u2019origine est conserve.');});}
 },true);
 async function requestClose(){
  try{
   if(S.project)await CEVault.checkpoint(S.project,S.dirty);
   await saveNow();
   if(S.project)await CEVault.checkpoint(S.project,false);
   await native('complete_close');
  }catch(e){await native('cancel_close');toast('Fermeture interrompue : '+e.message+' La fenetre reste ouverte.',true,0);}
 }
 window.addEventListener('pywebviewready',activate,{once:true});
 if(window.pywebview?.api)activate();
 return {requestClose};
})();
