'use strict';
// Bounded, cancellable display tiles. No giant whole-page bitmap at high zoom.
const CETiles=(()=>{
 const size=512,cache=new Map(),pending=new Map();let epoch=0,queue=[],active=0,pageKey='',wanted=new Set();
 const cap=80;
 function layer(){return document.querySelector('#plan-tiles');}
 function reset(){epoch++;queue=[];for(const p of pending.values())p.abort();pending.clear();for(const v of cache.values()){v.el.remove();URL.revokeObjectURL(v.url);}cache.clear();wanted.clear();layer()?.replaceChildren();pageKey='';}
 function render(state){
  if(!state.project)return;
  const id=state.project.id,page=state.page,d=state.project.document.pages[page],v=document.querySelector('#viewport'),c=state.camera;
  if(pageKey!==id+':'+page){reset();pageKey=id+':'+page;}
  const scale=Math.min(64,Math.max(.03125,2**Math.ceil(Math.log2(c.scale*Math.min(2,window.devicePixelRatio||1)))));
  const x0=Math.max(0,-c.x/c.scale),y0=Math.max(0,-c.y/c.scale),x1=Math.min(d.width,(v.clientWidth-c.x)/c.scale),y1=Math.min(d.height,(v.clientHeight-c.y)/c.scale);
  const tasks=[];wanted=new Set();const generation=++epoch;
  if(x1>x0&&y1>y0){for(let y=Math.floor(y0*scale/size);y<=Math.floor(Math.max(y0,y1-1e-6)*scale/size);y++)for(let x=Math.floor(x0*scale/size);x<=Math.floor(Math.max(x0,x1-1e-6)*scale/size);x++){
   const key=`${pageKey}:${scale}:${x}:${y}`;wanted.add(key);
   const old=cache.get(key);if(old){cache.delete(key);cache.set(key,old);old.el.style.display='block';continue;}
   tasks.push({id,page,scale,x,y,key,generation,width:Math.min(size/scale,d.width-x*size/scale),height:Math.min(size/scale,d.height-y*size/scale)});
  }}
  for(const [key,controller] of pending){if(!wanted.has(key)){controller.abort();pending.delete(key);}}
  for(const [key,item] of cache){item.el.style.display=wanted.has(key)?'block':'none';}
  const cx=(x0+x1)/2,cy=(y0+y1)/2;
  queue=tasks.filter(t=>!pending.has(t.key)).sort((a,b)=>Math.hypot(a.x*size/scale-cx,a.y*size/scale-cy)-Math.hypot(b.x*size/scale-cx,b.y*size/scale-cy));
  pump();
 }
 async function pump(){
  while(active<2&&queue.length){const t=queue.shift();if(!wanted.has(t.key)||pending.has(t.key)||cache.has(t.key))continue;
   const controller=new AbortController();pending.set(t.key,controller);active++;
   (async()=>{let objectURL=null;try{
    const r=await fetch(`/api/projects/${t.id}/tile?page=${t.page}&scale=${t.scale}&x=${t.x}&y=${t.y}`,{signal:controller.signal,cache:'no-store'});
    if(!r.ok)throw new Error('Rendu indisponible');
    const blob=await r.blob();if(!wanted.has(t.key)||controller.signal.aborted)return;
    objectURL=URL.createObjectURL(blob);const img=new Image();img.src=objectURL;await img.decode();
    if(!wanted.has(t.key)||controller.signal.aborted)return;
    img.draggable=false;img.alt='';img.style.cssText=`position:absolute;pointer-events:none;left:${t.x*size/t.scale}px;top:${t.y*size/t.scale}px;width:${t.width}px;height:${t.height}px`;
    layer().append(img);cache.set(t.key,{url:objectURL,el:img});objectURL=null;
    while(cache.size>cap){const key=[...cache.keys()].find(k=>!wanted.has(k));if(!key)break;const e=cache.get(key);e.el.remove();URL.revokeObjectURL(e.url);cache.delete(key);}
   }catch(e){if(e.name!=='AbortError')document.querySelector('#render-quality').textContent='Rendu HD en attente';}
   finally{if(objectURL)URL.revokeObjectURL(objectURL);if(pending.get(t.key)===controller)pending.delete(t.key);active--;if(!pending.size&&!queue.length)document.querySelector('#render-quality').textContent='Zoom HD';pump();}})();
  }
 }
 return {render,reset,get stats(){return {cached:cache.size,pending:pending.size,queued:queue.length,active};}};
})();

// Local emergency copies; same browser/origin, NOT cloud synchronisation.
const CEVault=(()=>{
 let dbPromise=null;const jobs=new Map();
 let tabId=Array.from(crypto.getRandomValues(new Uint8Array(16)),b=>b.toString(16).padStart(2,'0')).join('');try{tabId=sessionStorage.getItem('ce-vault-tab')||tabId;sessionStorage.setItem('ce-vault-tab',tabId);}catch(e){/* Other functions continue when browser storage is denied. */}
 function db(){if(dbPromise)return dbPromise;dbPromise=new Promise((resolve,reject)=>{const r=indexedDB.open('cedric-elec-secours-v1',1);r.onupgradeneeded=()=>{const d=r.result;d.createObjectStore('copies',{keyPath:'key'});d.createObjectStore('documents',{keyPath:'id'});};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);r.onblocked=()=>reject(new Error('Fermez les anciens onglets pour activer la copie de secours.'));});return dbPromise;}
 async function request(store,mode,fn){const d=await db();return new Promise((resolve,reject)=>{const tx=d.transaction(store,mode),r=fn(tx.objectStore(store));let result;r.onsuccess=()=>{result=r.result;};tx.oncomplete=()=>resolve(result);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||new Error('Copie locale interrompue.'));});}
 const docKey=p=>p.document.sha256||p.id;
 const copyKey=p=>p.id+':'+tabId;
 async function checkpoint(project,dirty=false){if(!project)return;const p=JSON.parse(JSON.stringify(project));const stamp=Date.now();
  await request('copies','readwrite',s=>s.put({key:copyKey(p),projectId:p.id,documentId:docKey(p),project:p,dirty,at:stamp,name:p.name}));
  return !!(await request('documents','readonly',s=>s.get(docKey(p))));
 }
 async function capture(project){
  if(!project)return;
  const id=docKey(project);if(jobs.has(id))return jobs.get(id);
  const job=(async()=>{const old=await request('documents','readonly',s=>s.get(id));if(!old){
   const r=await fetch(`/api/projects/${project.id}/export?kind=project`,{cache:'no-store'});
   if(!r.ok)throw new Error('Copie du plan source en attente. Terminez l\u2019analyse puis r\u00e9essayez.');
   const archive=await r.blob();if(archive.size>35*1024*1024)throw new Error('Plan trop volumineux pour la copie locale de cet essai.');
   await request('documents','readwrite',s=>s.put({id,archive,at:Date.now()}));
  }return true;})();jobs.set(id,job);try{return await job;}finally{jobs.delete(id);}
 }
 async function list(){return (await request('copies','readonly',s=>s.getAll())).sort((a,b)=>b.at-a.at);}
 async function latest(projectId){return (await list()).find(r=>r.projectId===projectId);}
 async function record(key){const r=await request('copies','readonly',s=>s.get(key));if(!r)throw new Error('Copie locale introuvable.');const d=await request('documents','readonly',s=>s.get(r.documentId));if(!d)throw new Error('Le plan source n\u2019a pas pu \u00eatre sauvegard\u00e9. Importez votre fichier original.');return {...r,archive:d.archive};}
 // Rebuild a standard ZIP central directory, replacing project.json only.
 // Existing compressed source entries and CRCs remain byte-for-byte intact.
 function crc32(data){let c=0xffffffff;for(const b of data){c^=b;for(let j=0;j<8;j++)c=(c>>>1)^((c&1)?0xedb88320:0);}return (c^0xffffffff)>>>0;}
 async function pack(r){
  const raw=new Uint8Array(await r.archive.arrayBuffer()),dv=new DataView(raw.buffer);let end=-1;
  for(let i=raw.length-22;i>=Math.max(0,raw.length-65557);i--){if(dv.getUint32(i,true)===0x06054b50&&i+22+dv.getUint16(i+20,true)===raw.length){end=i;break;}}
  if(end<0)throw new Error('Archive de secours non reconnue.');
  const count=dv.getUint16(end+10,true),start=dv.getUint32(end+16,true),decoder=new TextDecoder();let off=start;const directory=[];
  for(let i=0;i<count;i++){
   if(dv.getUint32(off,true)!==0x02014b50)throw new Error('Archive endommagee.');
   const nameLength=dv.getUint16(off+28,true),extra=dv.getUint16(off+30,true),comment=dv.getUint16(off+32,true),size=46+nameLength+extra+comment;
   const name=decoder.decode(raw.subarray(off+46,off+46+nameLength));if(name!=='project.json')directory.push(raw.slice(off,off+size));off+=size;
  }
  const enc=new TextEncoder(),name=enc.encode('project.json'),payload=enc.encode(JSON.stringify(r.project)),crc=crc32(payload);
  const local=new Uint8Array(30+name.length),l=new DataView(local.buffer);l.setUint32(0,0x04034b50,true);l.setUint16(4,20,true);l.setUint16(6,0x800,true);l.setUint32(14,crc,true);l.setUint32(18,payload.length,true);l.setUint32(22,payload.length,true);l.setUint16(26,name.length,true);local.set(name,30);
  const central=new Uint8Array(46+name.length),c=new DataView(central.buffer);c.setUint32(0,0x02014b50,true);c.setUint16(4,20,true);c.setUint16(6,20,true);c.setUint16(8,0x800,true);c.setUint32(16,crc,true);c.setUint32(20,payload.length,true);c.setUint32(24,payload.length,true);c.setUint16(28,name.length,true);c.setUint32(42,start,true);central.set(name,46);directory.push(central);
  const directorySize=directory.reduce((n,a)=>n+a.length,0),tail=new Uint8Array(22),e=new DataView(tail.buffer);e.setUint32(0,0x06054b50,true);e.setUint16(8,directory.length,true);e.setUint16(10,directory.length,true);e.setUint32(12,directorySize,true);e.setUint32(16,start+local.length+payload.length,true);
  return new Blob([raw.subarray(0,start),local,payload,...directory,tail],{type:'application/zip'});
 }
 async function portable(project,dirty=false){await checkpoint(project,dirty);return pack(await record(copyKey(project)));}
 async function exportCopy(key){return pack(await record(key));}
 async function protect(){return !!(navigator.storage&&await navigator.storage.persist());}
 return {checkpoint,capture,list,latest,record,portable,exportCopy,protect};
})();
