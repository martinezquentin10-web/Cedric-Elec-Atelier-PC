"""Interface native limitee : dialogues utilisateur et projets locaux seulement."""
from __future__ import annotations
import base64
import functools
import json
import re
import threading
import uuid
from pathlib import Path
from urllib.parse import urlsplit
import app
from desktop_store import atomic_bytes


def bridge(method):
    @functools.wraps(method)
    def wrapped(self, *args, **kwargs):
        try:
            current = urlsplit(self._window.get_current_url() or '')
            if current.scheme + '://' + current.netloc != self._runtime.origin:
                raise PermissionError('Action native refusee depuis une autre page.')
            return method(self, *args, **kwargs)
        except Exception as exc:
            return {'ok': False, 'error': str(exc)[:600]}
    return wrapped


class DesktopApi:
    def __init__(self, runtime):
        self._runtime = runtime
        self._window = None
        self._session = uuid.uuid4().hex
        self._can_close = False
        self._close_requested = False

    @bridge
    def info(self):
        projects = self._runtime.store.list()
        return {'ok': True, 'version': app.VERSION,
                'directory': str(self._runtime.store.root),
                'recentProjectId': projects[0]['id'] if projects else None}

    @bridge
    def checkpoint(self, project, sequence, dirty=True):
        return self._runtime.store.checkpoint(project, int(sequence), self._session, bool(dirty))

    @bridge
    def recovery_list(self):
        return {'ok': True, 'copies': self._runtime.store.recovery_list()}

    @bridge
    def recover(self, identifier):
        project = self._runtime.store.recover(str(identifier))
        return {'ok': True, 'project': project}

    @bridge
    def save_export(self, identifier, kind, page=0):
        import webview
        if kind not in {'project', 'pdf', 'csv', 'svg'}:
            raise ValueError('Format non autorise.')
        project = self._runtime.store.load(str(identifier))
        folder = self._runtime.store.folder(str(identifier))
        page = int(page)
        if not 0 <= page < len(project['document']['pages']):
            raise ValueError('Page invalide.')
        suffix = {'project': '.ceprojet', 'pdf': '.pdf', 'csv': '.csv', 'svg': '.svg'}[kind]
        suggested = re.sub(r'[^a-zA-Z0-9_-]+', '_', project['name'])[:90] + suffix
        selection = self._window.create_file_dialog(webview.SAVE_DIALOG, save_filename=suggested,
                                                    file_types=(f'Fichier (*{suffix})',))
        if not selection:
            return {'ok': True, 'cancelled': True}
        path = Path(selection[0] if isinstance(selection, (tuple, list)) else selection)
        if path.suffix.lower() != suffix:
            path = path.with_name(path.name + suffix)
        # Dialogues are the only way to select an output path. No path argument
        # is accepted from the HTML interface.
        if kind == 'project':
            data = self._runtime.store.archive(str(identifier))
        elif kind == 'csv':
            data = app.export_csv(project)
        elif kind == 'pdf':
            data = app.export_pdf(folder, project)
        else:
            data = app.export_svg(folder, project, page)
        atomic_bytes(path, data)
        return {'ok': True, 'filename': path.name}

    @bridge
    def save_blob(self, name, encoded):
        import webview
        name = Path(str(name)).name
        suffix = Path(name).suffix.lower()
        if suffix not in {'.ceprojet', '.pdf', '.csv', '.svg', '.png'}:
            raise ValueError('Extension de sauvegarde refusee.')
        if not isinstance(encoded, str) or len(encoded) > 190 * 1024 * 1024:
            raise ValueError('Fichier trop volumineux.')
        data = base64.b64decode(encoded, validate=True)
        chosen = self._window.create_file_dialog(webview.SAVE_DIALOG, save_filename=name,
                                                  file_types=(f'Fichier (*{suffix})',))
        if not chosen:
            return {'ok': True, 'cancelled': True}
        path = Path(chosen[0] if isinstance(chosen, (list, tuple)) else chosen)
        if path.suffix.lower() != suffix:
            path = path.with_name(path.name + suffix)
        atomic_bytes(path, data)
        return {'ok': True, 'filename': path.name}

    @bridge
    def cancel_close(self):
        self._close_requested = False
        return {'ok': True}

    @bridge
    def complete_close(self):
        active = [job for job in app.JOBS.values() if job['status'] == 'running']
        if active and not self._window.create_confirmation_dialog(
                'Analyse en cours', 'Arreter cette analyse et fermer ? Les resultats deja enregistres restent conserves.'):
            self._close_requested = False
            return {'ok': True, 'cancelled': True}
        for job in active:
            job['cancel'].set()
        self._can_close = True
        threading.Thread(target=self._window.destroy, daemon=True).start()
        return {'ok': True}

    def _on_closing(self):
        if self._can_close:
            return True
        if self._close_requested:
            return False
        self._close_requested = True
        def request():
            try:
                self._window.run_js('window.CEDesktop.requestClose();')
            except Exception:
                # Never silently dismiss the application after a failed save.
                self._close_requested = False
                self._window.create_confirmation_dialog(
                    'Fermeture interrompue', 'La sauvegarde avant fermeture ne peut pas etre confirmee. La fenetre reste ouverte. Vos projets deja enregistres ne sont pas supprimes.')
        threading.Thread(target=request, daemon=True).start()
        return False
