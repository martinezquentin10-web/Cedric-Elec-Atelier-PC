"""Exports de travail : PDF annote, SVG editable et CSV lisible dans Excel."""
from __future__ import annotations
import csv
import io
import math
from collections import defaultdict
from pathlib import Path
from xml.sax.saxutils import escape
import pymupdf as fitz
from geometry import counts,route_length
from engine import PDF_LOCK


def rgb(value):
    try:return tuple(int(value[i:i+2],16)/255 for i in (1,3,5))
    except (ValueError,TypeError):return (.2,.35,.65)


def safe_cell(value):
    text=str(value)
    if text[:1] in ('=','+','-','@','\t','\r'):text="'"+text
    return text


def export_csv(project):
    output=io.StringIO(newline='');writer=csv.writer(output,delimiter=';')
    writer.writerow(['Chantier','Page','Piece','Designation','Valides','A verifier','Exclus'])
    legends={x['id']:x for x in project['legend']};zones={z['id']:z for z in project['zones']}
    groups=defaultdict(lambda:{'validated':0,'pending':0,'excluded':0})
    for e in project['elements']:groups[(e['page'],e.get('roomId'),e['legendId'])][e['status']]+=1
    for (page,room,legend),totals in sorted(groups.items(),key=lambda x:str(x[0])):
        row=[project['name'],page+1,zones.get(room,{}).get('name','Non affecte'),legends.get(legend,{}).get('name','?'),totals['validated'],totals['pending'],totals['excluded']]
        writer.writerow([safe_cell(x) for x in row])
    writer.writerow([]);writer.writerow(['CIRCUITS DE TRAVAIL - LONGUEURS INDICATIVES, HORS ELEMENTS NON RENSEIGNES'])
    writer.writerow(['Repere','Page','Type','Equipements','Longueur m (reserve renseignee incluse)','Etat'])
    for c in project['circuits']:
        length=route_length(c,project['scales'].get(str(c['page'])))
        state='A recalculer' if c.get('stale') else 'Passage bloque' if any(r.get('blocked') for r in c['routes']) else 'Trace de travail'
        writer.writerow([safe_cell(x) for x in [c['name'],c['page']+1,'BUS' if c.get('bus') else legends.get(c['legendId'],{}).get('name',''),len(c['elementIds']),'' if length is None else str(length).replace('.',','),state]])
    return ('\ufeff'+output.getvalue()).encode('utf-8')


def export_pdf(folder,project):
    with PDF_LOCK:
        doc=fitz.open(folder/'work.pdf')
        legends={l['id']:l for l in project['legend']}
        for index,page in enumerate(doc):
            size=max(.6,min(page.rect.width,page.rect.height)/800)
            for z in project['zones']:
                if z['page']!=index:continue
                points=[fitz.Point(*p) for p in z['points']]
                shape=page.new_shape();shape.draw_polyline(points+[points[0]])
                color=rgb(z.get('color','#315eb3'))
                shape.finish(color=color,fill=color,fill_opacity=.07 if z.get('type')=='room' else .12,width=size,dashes=None if z.get('confirmed',True) else '[4 3] 0',closePath=True)
                shape.commit()
                page.insert_text((min(p[0] for p in z['points'])+4,max(12,min(p[1] for p in z['points'])+12*size)),z['name'][:80],fontsize=8*size,color=color)
            for c in project['circuits']:
                if c['page']!=index:continue
                color=rgb(c['color'])
                for route in c['routes']:
                    if len(route['points'])<2:continue
                    shape=page.new_shape();shape.draw_polyline([fitz.Point(*p) for p in route['points']]);shape.finish(color=color,width=1.4*size,dashes='[5 3] 0',closePath=False);shape.commit()
                first=next((r['points'][0] for r in c['routes'] if r['points']),None)
                if first:page.insert_text((first[0]+5,first[1]-5),c['name']+(' !' if c.get('stale') else ''),fontsize=8*size,color=color)
            for e in project['elements']:
                if e['page']!=index or e['status']=='excluded':continue
                color=rgb(legends.get(e['legendId'],{}).get('color','#315eb3'))
                r=max(4*size,min(e.get('w',10),e.get('h',10))/2+2*size)
                shape=page.new_shape();shape.draw_circle((e['x'],e['y']),r);shape.finish(color=color,width=size,dashes=None if e['status']=='validated' else '[2 2] 0');shape.commit()
                page.insert_text((e['x']+r+1,e['y']-r),e['ref'],fontsize=6.5*size,color=color)
            for t in project['targets']:
                if t['page']==index:
                    page.draw_rect(fitz.Rect(t['x']-5*size,t['y']-5*size,t['x']+5*size,t['y']+5*size),color=(.17,.25,.42),fill=(1,.85,.3),width=size)
                    page.insert_text((t['x']+7*size,t['y']),t['name'],fontsize=8*size,color=(.17,.25,.42))
        def report_page():
            p=doc.new_page(width=595,height=842)
            p.draw_rect(fitz.Rect(0,0,595,100),fill=(.16,.28,.50),color=None)
            p.insert_image(fitz.Rect(28,18,89,79),filename=str(Path(__file__).parent/'static/logo.png'))
            p.insert_text((108,46),'CEDRIC ELEC  /  ATELIER',fontsize=20,color=(1,1,1))
            p.insert_text((108,73),'RECAPITULATIF DE TRAVAIL',fontsize=11,color=(.97,.81,.30))
            p.insert_text((40,130),project['name'][:70],fontsize=16,color=(.14,.21,.32))
            return p
        report=report_page();y=158
        for line in ['Les resultats proposes doivent etre verifies sur le plan.','Les traces ne constituent pas une validation reglementaire.','Longueurs 2D : echelle requise ; montees, descentes et reserves a renseigner.',"Un score de similarite n'est pas une probabilite de justesse."]:
            report.insert_text((40,y),line,fontsize=9,color=(.4,.44,.5));y+=15
        y+=22
        report.insert_text((40,y),'Designation',fontsize=10,color=(.2,.28,.4));report.insert_text((325,y),'Valides',fontsize=10);report.insert_text((400,y),'A verifier',fontsize=10);report.insert_text((490,y),'Exclus',fontsize=10)
        y+=18
        for row in counts(project):
            if y>765:report=report_page();y=170
            report.draw_line((40,y+7),(555,y+7),color=(.87,.89,.92),width=.5)
            report.insert_textbox(fitz.Rect(40,y-10,310,y+8),row['name'][:55],fontsize=10)
            for x,k in [(335,'validated'),(420,'pending'),(500,'excluded')]:report.insert_text((x,y),str(row[k]),fontsize=10)
            y+=28
        y+=25
        for c in project['circuits']:
            if y>775:report=report_page();y=170
            length=route_length(c,project['scales'].get(str(c['page'])))
            m='Trajet a revoir / bloque / echelle absente' if length is None else f'{length:.2f} m (reserve saisie incluse)'
            report.insert_text((40,y),f"{c['name']}  |  {len(c['elementIds'])} equipements  |  {m}"[:105],fontsize=9);y+=19
        result=doc.tobytes(garbage=3,deflate=True);doc.close();return result


def export_svg(folder,project,page_number):
    with PDF_LOCK:
        with fitz.open(folder/'work.pdf') as doc:svg=doc[page_number].get_svg_image(text_as_path=True)
    overlay=['<g id="cedric-elec-annotations">']
    for z in project['zones']:
        if z['page']!=page_number:continue
        pts=' '.join(f'{x},{y}' for x,y in z['points'])
        overlay.append(f'<polygon id="piece-{z["id"]}" points="{pts}" fill="{z["color"]}" fill-opacity="0.07" stroke="{z["color"]}" stroke-width="1"/>')
    for c in project['circuits']:
        if c['page']!=page_number:continue
        overlay.append(f'<g id="circuit-{escape(c["id"])}" fill="none" stroke="{c["color"]}" stroke-width="1.5">')
        for r in c['routes']:
            pts=' '.join(f'{x},{y}' for x,y in r['points'])
            overlay.append(f'<polyline points="{pts}"/>')
        overlay.append('</g>')
    for e in project['elements']:
        if e['page']!=page_number or e['status']=='excluded':continue
        legend=next((l for l in project['legend'] if l['id']==e['legendId']),{})
        color=legend.get('color','#315496');rad=max(4,min(e.get('w',10),e.get('h',10))/2)
        overlay.append(f'<g id="equipement-{e["id"]}"><circle cx="{e["x"]}" cy="{e["y"]}" r="{rad}" fill="none" stroke="{color}" stroke-width="1.2"/><text x="{e["x"]+rad+2}" y="{e["y"]-rad}" font-family="Arial" font-size="7" fill="{color}">{escape(e["ref"])}</text></g>')
    for t in project['targets']:
        if t['page']!=page_number:continue
        overlay.append(f'<g id="tableau-{t["id"]}"><rect x="{t["x"]-5}" y="{t["y"]-5}" width="10" height="10" fill="#eebf39" stroke="#315496"/><text x="{t["x"]+8}" y="{t["y"]}" font-family="Arial" font-size="9">{escape(t["name"])}</text></g>')
    overlay.append('</g>')
    return svg.replace('</svg>',''.join(overlay)+'</svg>').encode('utf-8')
