"""Stockage atomique, revisions et sauvegardes portables non executables."""
from __future__ import annotations
import base64
import copy
import hashlib
import io
import json
import math
import os
import re
import threading
import time
import zipfile
from pathlib import Path
from datetime import datetime,timezone

from geometry import uid,assign_rooms,mark_stale_circuits,polygon_area,inside,simple_polygon
from engine import prepare_document

ID_RE=re.compile(r'^[a-f0-9]{32}$')
LOCK=threading.RLock()


def now():return datetime.now(timezone.utc).isoformat()


def project_base(name):
    return {'schemaVersion':1,'id':uid(),'name':str(name)[:120] or 'Nouveau chantier','revision':0,'createdAt':now(),'updatedAt':now(),
      'document':None,'legend':[],'elements':[],'zones':[],'targets':[],'passages':[],'circuits':[],'scales':{},'config':{'domotique':True,'threshold':.88},'demo':False}


def validate_project(p):
    if not isinstance(p,dict) or p.get('schemaVersion')!=1:raise ValueError('Format de projet non reconnu (version 1 attendue).')
    if not ID_RE.fullmatch(str(p.get('id',''))):raise ValueError('Identifiant de projet invalide.')
    p['name']=str(p.get('name','Chantier'))[:120]
    pages=p.get('document',{}).get('pages',[])
    if not 0<len(pages)<=250:raise ValueError('Pages absentes ou invalides.')
    for page in pages:
        if any(not isinstance(page.get(k),(int,float)) or not math.isfinite(page[k]) or not 0<page[k]<100000 for k in ('width','height')):raise ValueError('Dimensions de page invalides.')
    def pt(v):
        return isinstance(v,(list,tuple)) and len(v)==2 and all(isinstance(n,(float,int)) and math.isfinite(n) and abs(n)<1e7 for n in v)
    def pagevalid(item):
        n=item.get('page');return isinstance(n,int) and 0<=n<len(pages)
    for key,limit in [('legend',500),('elements',100000),('zones',10000),('targets',1000),('passages',1000),('circuits',10000)]:
        values=p.get(key,[])
        if not isinstance(values,list) or len(values)>limit:raise ValueError('Trop d\u2019objets dans le projet : '+key)
        ids=set()
        for obj in values:
            if not isinstance(obj,dict) or not ID_RE.fullmatch(str(obj.get('id',''))) or obj['id'] in ids:raise ValueError('Identifiant d\u2019objet invalide ou duplique.')
            ids.add(obj['id'])
            if key!='legend' and not pagevalid(obj):raise ValueError('Numero de page invalide.')
            for field in ('name','notes','ref','blockName'):
                if field in obj:obj[field]=str(obj[field])[:1000 if field=='notes' else 160]
            if 'color' in obj and not re.fullmatch(r'#[0-9a-fA-F]{6}',str(obj['color'])):obj['color']='#355da7'
            if key in ('elements','targets'):
                if not pt([obj.get('x'),obj.get('y')]):raise ValueError('Position invalide.')
            if key=='elements' and obj.get('status') not in ('validated','pending','excluded'):raise ValueError('Statut d\u2019element invalide.')
            if key in ('zones','passages'):
                points=obj.get('points',[])
                if not isinstance(points,list) or not (3 if key=='zones' else 2)<=len(points)<=500 or not all(pt(v) for v in points):raise ValueError('Contour incomplet ou invalide.')
                if key=='zones' and (polygon_area(points)<.2 or not simple_polygon(points) or obj.get('type') not in ('room','exclude','obstacle')):raise ValueError('Zone vide ou type invalide.')
            if key=='legend':
                s=obj.get('source')
                if s:
                    r=s.get('rect',[])
                    if not pagevalid(s) or not isinstance(r,list) or len(r)!=4 or not all(isinstance(n,(int,float)) and math.isfinite(n) for n in r) or min(r[2:])<=0:raise ValueError('Exemple de legende invalide.')
                if obj.get('family') not in ('eclairage','prise','commande','reseau','alimentation','autre'):obj['family']='autre'
            if key=='circuits':
                if not isinstance(obj.get('routes'),list) or len(obj['routes'])>10000:raise ValueError('Traces invalides.')
                for route in obj['routes']:
                    points=route.get('points',[])
                    if len(points)>5000 or not all(pt(v) for v in points):raise ValueError('Sommets de trace invalides.')
                if not isinstance(obj.get('extraMeters',0),(int,float)) or not math.isfinite(obj.get('extraMeters',0)) or obj.get('extraMeters',0)<0:raise ValueError('Reserve de longueur invalide.')
        p[key]=values
    legends={x['id'] for x in p['legend']}
    if any(e['legendId'] not in legends for e in p['elements']):raise ValueError('Un equipement fait reference a une legende absente.')
    zones={z['id']:z for z in p['zones']}
    for z in p['zones']:
        seen={z['id']};parent=z.get('parentId')
        while parent:
            if parent in seen or parent not in zones:raise ValueError('Hierarchie de pieces circulaire ou incomplete.')
            seen.add(parent)
            if z.get('type')!='room' or zones[parent].get('type')!='room' or not all(inside(pt,zones[parent]['points']) for pt in z['points']):raise ValueError('Une sous-piece doit rester dans sa piece parente.')
            if zones[parent]['page']!=z['page']:raise ValueError('Une sous-piece et sa piece parente doivent etre sur la meme page.')
            parent=zones[parent].get('parentId')
    scales=p.get('scales',{})
    if not isinstance(scales,dict) or any(not str(k).isdigit() or int(k)>=len(pages) or not isinstance(v,(int,float)) or not math.isfinite(v) or not 0<v<10000 for k,v in scales.items()):raise ValueError('Echelle invalide.')
    cfg=p.setdefault('config',{})
    cfg['domotique']=bool(cfg.get('domotique',True))
    cfg['threshold']=max(.65,min(.99,float(cfg.get('threshold',.88))))
    used_refs=set();next_ref=max([int(e.get('ref','E-0').split('-')[-1]) for e in p['elements'] if str(e.get('ref','')).split('-')[-1].isdigit()]+[0])+1
    for e in p['elements']:
        if not e.get('ref') or e['ref'] in used_refs:e['ref']=f'E-{next_ref:03d}';next_ref+=1
        used_refs.add(e['ref'])
    assign_rooms(p);mark_stale_circuits(p)
    return p


class Store:
    def __init__(self,root):
        self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True)
    def folder(self,identifier):
        if not ID_RE.fullmatch(str(identifier)):raise ValueError('Identifiant invalide.')
        return self.root/identifier
    def load(self,identifier):
        with LOCK:
            path=self.folder(identifier)/'project.json'
            if not path.exists():raise FileNotFoundError('Projet introuvable.')
            return json.loads(path.read_text(encoding='utf-8'))
    def write(self,p,expected=None):
        with LOCK:
            p=validate_project(copy.deepcopy(p));folder=self.folder(p['id']);folder.mkdir(exist_ok=True)
            path=folder/'project.json'
            if path.exists():
                current=json.loads(path.read_text(encoding='utf-8'))
                if expected is not None and current['revision']!=expected:raise RevisionConflict('Une autre fenetre a modifie ce projet. Rechargez sa derniere version avant de poursuivre.')
                snapshots=folder/'revisions';snapshots.mkdir(exist_ok=True)
                (snapshots/f"{current['revision']:08d}.json").write_text(json.dumps(current,ensure_ascii=False),encoding='utf-8')
                for f in sorted(snapshots.glob('*.json'))[:-15]:f.unlink()
                p['revision']=current['revision']+1
            p['updatedAt']=now()
            tmp=folder/'project.tmp'
            with tmp.open('w',encoding='utf-8') as handle:
                json.dump(p,handle,ensure_ascii=False,allow_nan=False);handle.flush();os.fsync(handle.fileno())
            os.replace(tmp,path)
            return p
    def create(self,filename,raw,name=None):
        p=project_base(name or Path(filename).stem)
        folder=self.folder(p['id']);folder.mkdir()
        try:
            p['document'],scale=prepare_document(folder,filename,raw)
            p['document']['sha256']=hashlib.sha256(raw).hexdigest()
            if scale:p['scales']['0']=scale
            return self.write(p)
        except Exception:
            import shutil
            shutil.rmtree(folder,ignore_errors=True)
            raise
    def list(self):
        result=[]
        for file in self.root.glob('*/project.json'):
            try:
                p=json.loads(file.read_text(encoding='utf-8'))
                result.append({k:p[k] for k in ('id','name','revision','updatedAt','demo') if k in p}|{'filename':p.get('document',{}).get('filename',''),'elements':len(p.get('elements',[]))})
            except (OSError,ValueError):continue
        return sorted(result,key=lambda p:p['updatedAt'],reverse=True)
    def archive(self,identifier):
        p=self.load(identifier);folder=self.folder(identifier)
        buf=io.BytesIO()
        with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
            z.writestr('project.json',json.dumps(p,ensure_ascii=False,allow_nan=False))
            z.write(folder/('original'+p['document']['sourceExtension']),'original'+p['document']['sourceExtension'])
            z.writestr('LISEZ-MOI.txt','Sauvegarde Cedric Elec Atelier. Rouvrir depuis le bouton Ouvrir un projet. Le plan source est inclus. Aucun code executable.')
        return buf.getvalue()
    def restore(self,raw):
        if len(raw)>125*1024*1024:raise ValueError('Sauvegarde trop volumineuse.')
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            infos=z.infolist()
            if sum(i.file_size for i in infos)>180*1024*1024 or len(infos)>6:raise ValueError('Archive trop volumineuse ou non reconnue.')
            if 'project.json' not in z.namelist():raise ValueError('Archive sans projet.json : choisissez une sauvegarde .ceprojet.')
            data=json.loads(z.read('project.json'))
            validate_project(data)
            ext=data['document']['sourceExtension']
            if ext not in ('.pdf','.dxf','.png','.jpg','.jpeg','.webp'):raise ValueError('Type de plan invalide.')
            source=z.read('original'+ext)
            # Never extract paths from a ZIP; only known members are read.
        p=self.create(data['document']['filename'],source,data['name'])
        for key in ('legend','elements','zones','targets','passages','circuits','scales','config','demo'):
            p[key]=data.get(key,p[key])
        p['restoredFrom']={'id':data['id'],'revision':data['revision'],'at':now()}
        return self.write(p)


class RevisionConflict(Exception):pass
