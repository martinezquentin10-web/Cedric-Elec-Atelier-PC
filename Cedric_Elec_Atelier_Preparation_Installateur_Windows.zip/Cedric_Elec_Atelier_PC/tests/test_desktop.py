import copy
import http.cookiejar
import json
import os
from pathlib import Path
import threading
import time
import urllib.error
import urllib.request

import pytest
from desktop_workers import WorkerLane, WorkerFailure
from desktop_store import DesktopStore, atomic_bytes
from desktop_api import DesktopApi


def probe(operation, args, kwargs, progress):
    if operation == 'crash':
        os._exit(31)
    if operation == 'sleep':
        time.sleep(args[0])
        return 'finished'
    if operation == 'progress':
        progress('Etape 1', .5)
    if operation == 'error':
        raise ValueError('Exemple invalide')
    return os.getpid()


@pytest.fixture
def lane():
    worker = WorkerLane('test', target=probe)
    yield worker
    worker.close()


def test_worker_is_another_process(lane):
    assert lane.call('pid') != os.getpid()


def test_worker_reused(lane):
    assert lane.call('pid') == lane.call('pid')


def test_worker_progress(lane):
    received=[]
    lane.call('progress', progress=lambda *v: received.append(v))
    assert received == [('Etape 1', .5)]


def test_worker_error_does_not_poison_lane(lane):
    first=lane.call('pid')
    with pytest.raises(ValueError, match='Exemple invalide'):
        lane.call('error')
    assert lane.call('pid') == first


def test_worker_crash_recovers_without_restarting_parent(lane):
    first=lane.call('pid')
    with pytest.raises(WorkerFailure):
        lane.call('crash')
    assert lane.call('pid') != first


def test_worker_timeout_is_recoverable(lane):
    first=lane.call('pid')
    with pytest.raises(WorkerFailure, match='delai'):
        lane.call('sleep', 5, timeout=.25)
    assert lane.call('pid') != first


def test_worker_cancel_before_start(lane):
    cancel=threading.Event();cancel.set()
    with pytest.raises(InterruptedError):
        lane.call('pid',cancel=cancel)
    assert lane.call('pid')


def test_worker_cancel_during_task(lane):
    first=lane.call('pid');cancel=threading.Event()
    timer=threading.Timer(.25,cancel.set);timer.start()
    try:
        with pytest.raises(InterruptedError):
            lane.call('sleep',5,cancel=cancel)
    finally:
        timer.cancel()
    assert lane.call('pid') != first


def test_worker_close_prevents_new_tasks(lane):
    lane.close()
    with pytest.raises(WorkerFailure):
        lane.call('pid')


def test_worker_recycles_after_limit():
    lane=WorkerLane('recycle',target=probe,recycle=2)
    try:
        p1=lane.call('pid');assert lane.call('pid') == p1
        assert lane.call('pid') != p1
    finally:
        lane.close()


def test_two_lanes_independent(lane):
    other=WorkerLane('second',target=probe)
    try:
        assert other.call('pid') != lane.call('pid')
    finally:
        other.close()


@pytest.fixture
def store(tmp_path):
    from demo import create_demo
    pdf=tmp_path/'plan.pdf';create_demo(pdf)
    store=DesktopStore(tmp_path/'data'/'Projets')
    project=store.create('Plan.pdf',pdf.read_bytes())
    return store,project


def test_disk_draft_after_store_reopen(store):
    s,p=store;p['name']='Modifications avant panne'
    s.checkpoint(p,1,'session',True)
    reopened=DesktopStore(s.root)
    assert reopened.recovery_list()[0]['name']=='Modifications avant panne'


def test_out_of_order_checkpoint_does_not_revert(store):
    s,p=store;p['name']='Nouveau'
    s.checkpoint(p,5,'session',True)
    p['name']='Ancien';s.checkpoint(p,2,'session',True)
    assert s.recovery_list()[0]['name']=='Nouveau'


def test_clean_checkpoint_not_shown_as_lost(store):
    s,p=store;s.checkpoint(p,1,'session',True)
    s.checkpoint(p,2,'session',False)
    assert s.recovery_list()==[]


def test_recovery_new_project_preserves_original(store):
    s,p=store;old=s.load(p['id']);p['name']='Avant fermeture'
    s.checkpoint(p,1,'session',True)
    copy=s.recover(p['id'])
    assert copy['id']!=p['id']
    assert copy['name'].startswith('Avant fermeture')
    assert s.load(p['id'])==old


def test_no_draft_document_substitution(store):
    s,p=store;p['document']['filename']='Autre.pdf'
    with pytest.raises(ValueError,match='source'):
        s.checkpoint(p,1,'session')


def test_recovery_path_traversal_rejected(store):
    s,p=store
    with pytest.raises(ValueError):
        s.recover('../autre')


def test_atomic_write_leaves_no_temporary_file(tmp_path):
    dest=tmp_path/'x.txt';atomic_bytes(dest,b'first');atomic_bytes(dest,b'second')
    assert dest.read_bytes()==b'second'
    assert len(list(tmp_path.iterdir()))==1


def test_bridge_rejects_remote_page(store):
    s,p=store
    class Runtime:origin='http://127.0.0.1:12345';store=s
    class Window:
        def get_current_url(self):return 'https://example.invalid/'
    api=DesktopApi(Runtime());api._window=Window()
    assert api.info()['ok'] is False


def test_bridge_info_only_from_own_origin(store):
    s,p=store
    class Runtime:origin='http://127.0.0.1:12345';store=s
    class Window:
        def get_current_url(self):return 'http://127.0.0.1:12345/'
    api=DesktopApi(Runtime());api._window=Window()
    assert api.info()['recentProjectId']==p['id']


def test_opening_new_session_does_not_erase_old_dirty_draft(store):
    s,p=store;original=copy.deepcopy(p)
    p['name']='Travail non enregistre'
    s.checkpoint(p,1,'ancienne-session',True)
    reopened=DesktopStore(s.root)
    reopened.checkpoint(original,1,'nouvelle-session',False)
    rows=reopened.recovery_list()
    assert len(rows)==1 and rows[0]['name']=='Travail non enregistre'
    recovered=reopened.recover(rows[0]['key'])
    assert recovered['name'].startswith('Travail non enregistre')


def test_concurrent_drafts_are_kept_separately(store):
    s,p=store
    p['name']='Premiere session';s.checkpoint(p,1,'A',True)
    p['name']='Deuxieme session';s.checkpoint(p,1,'B',True)
    assert {r['name'] for r in s.recovery_list()}=={'Premiere session','Deuxieme session'}


def test_draft_reference_cannot_escape_directory(store):
    s,p=store
    for ref in [p['id']+'.../../other',p['id']+'..',p['id']+'.exe']:
        with pytest.raises(ValueError):s.recover(ref)


def test_tile_pixels_unchanged_in_isolated_worker(store):
    from engine import render_tile
    s,p=store;folder=s.folder(p['id'])
    expected=render_tile(folder,0,4,1,1)
    lane=WorkerLane('image-test')
    try:
        assert lane.call('render_tile',folder,0,4,1,1)==expected
    finally:lane.close()


@pytest.fixture
def desktop_http(tmp_path):
    from desktop_server import DesktopRuntime
    runtime=DesktopRuntime(tmp_path/'desktop-http').start()
    cookies=http.cookiejar.CookieJar()
    client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cookies))
    client.open(runtime.url,timeout=10).read()
    yield runtime,client
    runtime.close()


def test_desktop_http_rejects_no_cookie(desktop_http):
    runtime,_=desktop_http
    with pytest.raises(urllib.error.HTTPError) as exc:
        urllib.request.urlopen(runtime.origin+'/api/health')
    assert exc.value.code==403


def test_desktop_http_sets_mode_and_restricts_local_address(desktop_http):
    runtime,client=desktop_http
    assert runtime.http.server_address[0]=='127.0.0.1'
    html=client.open(runtime.origin+'/').read().decode()
    assert 'window.CE_DESKTOP=true' in html and '/static/desktop.js' in html
    assert json.loads(client.open(runtime.origin+'/api/health').read())['localOnly'] is True


def test_desktop_http_rejects_cross_origin_even_with_cookie(desktop_http):
    runtime,client=desktop_http
    request=urllib.request.Request(runtime.origin+'/api/health',headers={'Origin':'https://other.invalid'})
    with pytest.raises(urllib.error.HTTPError) as exc:client.open(request)
    assert exc.value.code==403
