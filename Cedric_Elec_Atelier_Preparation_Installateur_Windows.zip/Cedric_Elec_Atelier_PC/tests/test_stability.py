import io,json,math,threading,zipfile
from pathlib import Path
import pytest,pymupdf as fitz
from PIL import Image
import app,engine
from storage import Store
from geometry import uid
from demo import create_demo,legend_items

@pytest.fixture
def source(tmp_path):
    s=Store(tmp_path/'source');f=tmp_path/'d.pdf';create_demo(f);p=s.create('test.pdf',f.read_bytes());p['legend']=legend_items();p=s.write(p);return s,p

@pytest.mark.parametrize('scale',[.125,1,4,16,64])
def test_tiles_fixed_pixel_budget(source,scale):
    s,p=source;data=engine.render_tile(s.folder(p['id']),0,scale,0,0)
    im=Image.open(io.BytesIO(data));assert im.width<=514 and im.height<=514

@pytest.mark.parametrize('scale',[float('nan'),float('inf'),0,-1,128])
def test_invalid_zoom_rejected(source,scale):
    s,p=source
    with pytest.raises(ValueError):engine.render_tile(s.folder(p['id']),0,scale,0,0)

def test_tile_exact_original_vector_render(source):
    s,p=source;folder=s.folder(p['id']);scale=16;x=5;y=4
    actual=engine.render_tile(folder,0,scale,x,y)
    with fitz.open(folder/'work.pdf') as doc:
        ref=doc[0].get_pixmap(matrix=fitz.Matrix(scale,scale),clip=fitz.Rect(x*512/scale,y*512/scale,(x+1)*512/scale,(y+1)*512/scale),alpha=False,colorspace=fitz.csRGB).tobytes('png')
    assert actual==ref

def test_full_page_render_capped(source):
    s,p=source;data=engine.render_png(s.folder(p['id']),0,20);im=Image.open(io.BytesIO(data));assert im.width*im.height<=4_010_000 and max(im.size)<=2401

def test_large_raster_search_crosses_tile_boundary(tmp_path):
    doc=fitz.open();page=doc.new_page(width=2000,height=1500)
    positions=[(10,10),(305,180),(610,420),(921,780),(1444,1100)]
    for x,y in positions:
        page.draw_circle((x+8,y+8),6,color=(.8,.1,.1),width=1)
        page.draw_line((x+2,y+8),(x+14,y+8),color=(.8,.1,.1),width=1)
    raw=doc.tobytes();doc.close();s=Store(tmp_path/'raster');p=s.create('large.pdf',raw)
    legend={'id':uid(),'name':'test','family':'eclairage','method':'image','rotations':False,'multiScale':False,'source':{'page':0,'rect':[8,8,20,20]}}
    found,report=engine.detect_symbols(s.folder(p['id']),p,legend,0,.9)
    assert len(found)==5
    assert report['tiles']>1
    for x,y in positions:assert any(abs(v['x']-x-8)<1 and abs(v['y']-y-8)<1 for v in found)

def test_invalid_sample_keeps_other_family_results(source):
    s,p=source;old=app.STORE;app.STORE=s
    p['legend'][0]['source']['rect']=[1,1,.1,.1];p=s.write(p)
    job=uid();app.JOBS[job]={'cancel':threading.Event(),'projectId':p['id'],'status':'running'}
    try:
        app.run_analysis(job,p['id'],0,[v['id'] for v in p['legend']],.88)
        result=app.JOBS[job];assert result['status']=='done';assert len(result['result']['warnings'])==1
        assert result['result']['added']>0
    finally:app.STORE=old;app.JOBS.pop(job,None)

def test_matching_cancel_before_render(source):
    s,p=source;event=threading.Event();event.set()
    with pytest.raises(InterruptedError):engine.detect_symbols(s.folder(p['id']),p,p['legend'][0],0,.88,cancel=event)

def test_room_segmentation_bounded(source):
    s,p=source;array,sx,sy=engine.render_array(s.folder(p['id']),0,40);assert array.shape[0]*array.shape[1]<=2_010_000
