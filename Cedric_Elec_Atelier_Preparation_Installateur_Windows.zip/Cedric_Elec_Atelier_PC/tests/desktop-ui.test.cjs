'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const vm=require('node:vm');const fs=require('node:fs');const path=require('node:path');
function setup(failSave=false){
 const calls=[],messages=[];const elements=new Map();
 const api={info:async()=>({ok:true,directory:'TEST',recentProjectId:null}),recovery_list:async()=>({ok:true,copies:[]}),
 checkpoint:async(...args)=>{calls.push(['checkpoint',...args]);return {ok:true};},save_export:async(...args)=>{calls.push(['save_export',...args]);return{ok:true,filename:'test.ceprojet'};},
 complete_close:async()=>{calls.push(['complete_close']);return {ok:true};},cancel_close:async()=>{calls.push(['cancel_close']);return {ok:true};},save_blob:async()=>({ok:true,cancelled:true})};
 const context={CE_DESKTOP:true,pywebview:{api},CEVault:{capture:async()=>false,checkpoint:async()=>false},S:{project:{id:'abc',name:'Test'},page:0,dirty:true},
 document:{addEventListener(){}},addEventListener(){},$:selector=>{if(!elements.has(selector))elements.set(selector,{});return elements.get(selector);},
 clone:value=>JSON.parse(JSON.stringify(value)),download(){},saveBlob(){},fileBase64:async()=>'',
 saveNow:async()=>{calls.push(['saveNow']);if(failSave)throw new Error('Ecriture impossible');},toast:(message)=>messages.push(message),
 api:async()=>({}),loadProject:async()=>{},infoDialog(){},esc:String,guarded:fn=>fn(),console};
 context.window=context;
 vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../static/desktop.js'),'utf8'),context);
 return {context,calls,messages};
}
test('un export bureau utilise le dialogue natif apres sauvegarde',async()=>{
 const t=setup();await t.context.download('project');
 assert.deepEqual(t.calls.filter(c=>['saveNow','save_export'].includes(c[0])).map(c=>c[0]),['saveNow','save_export']);
});
test('la fermeture sauvegarde puis demande la fermeture native',async()=>{
 const t=setup();await t.context.CEDesktop.requestClose();
 assert.equal(t.calls.at(-1)[0],'complete_close');
 assert.equal(t.calls.filter(c=>c[0]==='checkpoint').length,2);
});
test('une erreur de sauvegarde interdit la fermeture silencieuse',async()=>{
 const t=setup(true);await t.context.CEDesktop.requestClose();
 assert.ok(t.calls.some(c=>c[0]==='cancel_close'));assert.ok(!t.calls.some(c=>c[0]==='complete_close'));
 assert.ok(t.messages.some(m=>m.includes('Fermeture interrompue')));
});
test('les checkpoints ont une sequence croissante',async()=>{
 const t=setup();await t.context.CEVault.checkpoint(t.context.S.project,true);await t.context.CEVault.checkpoint(t.context.S.project,false);
 const n=t.calls.filter(c=>c[0]==='checkpoint').map(c=>c[2]);assert.deepEqual(n,[1,2]);
});
