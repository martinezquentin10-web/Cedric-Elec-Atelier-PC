import json,threading,urllib.request,urllib.error
import pytest
import app
from http.server import ThreadingHTTPServer
from storage import Store

@pytest.fixture
def server(tmp_path):
 old=app.STORE;app.STORE=Store(tmp_path/'http-projets')
 http=ThreadingHTTPServer(('127.0.0.1',0),app.Handler);thread=threading.Thread(target=http.serve_forever,daemon=True);thread.start()
 yield 'http://127.0.0.1:'+str(http.server_port)
 http.shutdown();http.server_close();app.STORE=old

def send(url,path,body=None,headers=None):
 h=headers or {};data=None
 if body is not None:data=json.dumps(body).encode();h['Content-Type']='application/json'
 request=urllib.request.Request(url+path,data=data,headers=h)
 try:return urllib.request.urlopen(request,timeout=10)
 except urllib.error.HTTPError as error:return error

def test_http_health(server):
 r=send(server,'/api/health');assert r.status==200 and json.load(r)['localOnly']

def test_reject_post_without_token(server):
 assert send(server,'/api/demo',{}).status==403

def test_reject_external_origin(server):
 assert send(server,'/api/demo',{}, {'X-CE-Token':app.TOKEN,'Origin':'https://external.invalid'}).status==403

def test_reject_external_host(server):
 assert send(server,'/api/health',headers={'Host':'external.invalid'}).status==403

def test_reject_path_traversal(server):
 assert send(server,'/static/%2e%2e/app.py').status==403

def test_demo_empty_then_can_save(server):
 r=send(server,'/api/demo',{}, {'X-CE-Token':app.TOKEN});assert r.status==201;p=json.load(r);assert len(p['legend'])==4 and p['elements']==[]
 p['name']='Test sauvegarde';r=send(server,'/api/projects/'+p['id'],{'project':p,'revision':p['revision']},{'X-CE-Token':app.TOKEN});assert r.status==200 and json.load(r)['name']=='Test sauvegarde'
