"""Tests locaux avec plans synthetiques, jamais des documents de client."""
import copy,io,json,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
import pytest
import pymupdf as fitz
import ezdxf
from PIL import Image
from storage import Store,RevisionConflict,validate_project
from demo import create_demo,legend_items,POINTS
from engine import detect_symbols,propose_rooms,propose_legend,page_info,render_png
from geometry import uid,inside,polygon_area,rect_polygon,assigned_room,assign_rooms,merge_detections,orthogonal_route,clear_segment,route_with_passage,generate_circuits,route_length,mark_stale_circuits,simple_polygon,point_segment_distance
from exports import export_csv,export_pdf,export_svg,safe_cell

@pytest.fixture
def prepared(tmp_path):
 source=tmp_path/'source.pdf';create_demo(source);store=Store(tmp_path/'projets');p=store.create(source.name,source.read_bytes(),'Maison test')
 p['legend']=legend_items();p['zones']=[{'id':uid(),'page':0,'type':'exclude','name':'Legende','points':rect_polygon([940,65,230,585]),'color':'#aaaaaa','confirmed':True,'parentId':None}];p['scales']={'0':.01}
 return store,p

def populate(store,p):
 for legend in p['legend']:
  found,_=detect_symbols(store.folder(p['id']),p,legend,0,.88);merge_detections(p,legend['id'],0,found)
 return p

def ready(store,p):
 populate(store,p)
 for e in p['elements']:e['status']='validated'
 zones,_=propose_rooms(store.folder(p['id']),0,p)
 for z in zones:z['confirmed']=True
 p['zones']+=zones;p['targets']=[{'id':uid(),'page':0,'name':'Tableau','x':860,'y':620}]
 assign_rooms(p);return p

def test_inside_concave_and_boundary():
 poly=[[0,0],[10,0],[10,4],[4,4],[4,10],[0,10]]
 assert inside([2,8],poly) and not inside([8,8],poly) and inside([0,5],poly)
 assert polygon_area(poly)==64

def test_reject_self_crossing():
 assert not simple_polygon([[0,0],[10,10],[0,10],[10,0]])
 assert simple_polygon(rect_polygon([0,0,10,10]))

def test_smallest_confirmed_room(prepared):
 _,p=prepared;large={'id':uid(),'page':0,'type':'room','name':'Suite','confirmed':True,'points':rect_polygon([0,0,100,100])};small={'id':uid(),'page':0,'type':'room','name':'Dressing','confirmed':True,'points':rect_polygon([10,10,30,30]),'parentId':large['id']}
 e={'page':0,'x':20,'y':20};assert assigned_room(e,[large,small])[0]==small['id'];small['confirmed']=False;assert assigned_room(e,[large,small])[0]==large['id']

def test_semantic_legend_demo(prepared):
 store,p=prepared;items=propose_legend(store.folder(p['id']),0,[945,70,220,470]);assert len(items)==4
 assert {l['name'] for l in items}=={l['name'] for l in p['legend']}

def test_pdf_31_exact_positions(prepared):
 store,p=prepared;populate(store,p);assert len(p['elements'])==31
 for l,expected in zip(p['legend'],POINTS.values()):
  actual=[e for e in p['elements'] if e['legendId']==l['id']]
  assert len(actual)==len(expected)
  assert all(any(abs(e['x']-x)<.3 and abs(e['y']-y)<.3 for e in actual) for x,y in expected)
 assert all(e['status']=='pending' for e in p['elements'])

def test_reanalysis_preserves_corrections(prepared):
 store,p=prepared;populate(store,p);initial_ids={e['id'] for e in p['elements']};e=p['elements'][0];e['status']='excluded';excluded=e['id'];p['elements'][1]['status']='validated';p['elements'][1]['notes']='Controle terrain';validated=p['elements'][1]['id']
 populate(store,p);assert len(p['elements'])==31;assert {e['id'] for e in p['elements']}==initial_ids
 assert next(e for e in p['elements'] if e['id']==excluded)['status']=='excluded'
 assert next(e for e in p['elements'] if e['id']==validated)['notes']=='Controle terrain'

def test_count_source_from_actual_plan(prepared):
 store,p=prepared;l=p['legend'][0];l['source']={'page':0,'rect':[158,158,24,24],'excludeFromCount':False};found,_=detect_symbols(store.folder(p['id']),p,l,0,.88);merge_detections(p,l['id'],0,found);assert len(p['elements'])==13

def test_rooms_exclude_legend_and_are_pending(prepared):
 store,p=prepared;rooms,_=propose_rooms(store.folder(p['id']),0,p);assert len(rooms)==6 and all(not z['confirmed'] for z in rooms)
 assert all(max(x for x,y in z['points'])<940 for z in rooms)

def test_group_circuits_and_bus(prepared):
 store,p=prepared;ready(store,p);r=generate_circuits(p,0,p['targets'][0]['id']);assert r=={'circuits':15,'blocked':0,'unassigned':0,'kept':0}
 bus=[c for c in p['circuits'] if c['bus']];assert len(bus)==1 and len(bus[0]['elementIds'])==6
 ids=[i for c in p['circuits'] for i in c['elementIds']];assert len(ids)==31 and len(set(ids))==31
 assert all(route_length(c,.01)>0 for c in p['circuits'])

def test_preserve_manual_route_and_ids(prepared):
 store,p=prepared;ready(store,p);generate_circuits(p,0,p['targets'][0]['id']);names={c['id']:c['name'] for c in p['circuits']};c=p['circuits'][0];c['manual']=True;c['routes'][0]['points'].insert(1,[210,240]);before=copy.deepcopy(c['routes']);r=generate_circuits(p,0,p['targets'][0]['id']);assert r['kept']==1;assert names=={c['id']:c['name'] for c in p['circuits']};assert p['circuits'][0]['routes']==before

def test_stale_on_moved_element(prepared):
 store,p=prepared;ready(store,p);generate_circuits(p,0,p['targets'][0]['id']);c=p['circuits'][0];e=next(e for e in p['elements'] if e['id']==c['elementIds'][0]);e['x']+=5;mark_stale_circuits(p);assert c['stale'];assert route_length(c,.01) is None

def test_no_uncalibrated_lengths(prepared):
 store,p=prepared;ready(store,p);generate_circuits(p,0,p['targets'][0]['id']);assert route_length(p['circuits'][0],None) is None

def test_obstacle_avoidance():
 obstacle=rect_polygon([40,20,20,60]);route=orthogonal_route([10,50],[90,50],[obstacle],[100,100]);assert route and len(route)>2;assert all(clear_segment(a,b,[obstacle]) for a,b in zip(route,route[1:]))

def test_impossible_path_is_not_invented():
 obstacle=rect_polygon([40,0,20,100]);assert orthogonal_route([10,50],[90,50],[obstacle],[100,100]) is None

def test_explicit_passage():
 passage=[[30,20],[80,20]];route=route_with_passage([10,50],[90,50],[],[100,100],passage);assert all(any(point_segment_distance(pt,a,b)<.001 for a,b in zip(route,route[1:])) for pt in passage)

def test_manual_route_obstacle_is_flagged(prepared):
 store,p=prepared;ready(store,p);generate_circuits(p,0,p['targets'][0]['id']);c=p['circuits'][0];a=c['routes'][0]['points'][0];p['zones'].append({'id':uid(),'page':0,'type':'obstacle','name':'Interdit','points':rect_polygon([a[0]-2,a[1]-2,4,4]),'color':'#aa0000'});mark_stale_circuits(p);assert c['stale'] and c['routes'][0]['blocked']

def test_revision_conflict_and_atomic_storage(prepared):
 store,p=prepared;p=store.write(p);old=copy.deepcopy(p);p['name']='Nouveau nom';p=store.write(p,expected=p['revision']);assert store.load(p['id'])['name']=='Nouveau nom'
 with pytest.raises(RevisionConflict):store.write(old,expected=old['revision'])
 assert not (store.folder(p['id'])/'project.tmp').exists()

def test_portable_backup_restores_to_new_project(prepared):
 store,p=prepared;ready(store,p);generate_circuits(p,0,p['targets'][0]['id']);p=store.write(p);archive=store.archive(p['id']);restored=store.restore(archive);assert restored['id']!=p['id'];assert restored['elements']==p['elements'];assert restored['circuits']==p['circuits'];assert store.load(p['id'])['name']==p['name'];assert (store.folder(restored['id'])/'original.pdf').read_bytes()==(store.folder(p['id'])/'original.pdf').read_bytes()

def test_invalid_archive_rejected(prepared):
 store,p=prepared;stream=io.BytesIO()
 with zipfile.ZipFile(stream,'w') as z:z.writestr('../../bad.txt','unsafe')
 with pytest.raises(ValueError):store.restore(stream.getvalue())

def test_no_path_traversal(prepared):
 store,p=prepared
 with pytest.raises(ValueError):store.folder('../../escape')

def test_hierarchy_cycle_rejected(prepared):
 store,p=prepared;a={'id':uid(),'page':0,'type':'room','name':'A','points':rect_polygon([0,0,100,100])};b=copy.deepcopy(a);b['id']=uid();a['parentId']=b['id'];b['parentId']=a['id'];p['zones']=[a,b]
 with pytest.raises(ValueError):validate_project(p)

def test_invalid_subroom_rejected(prepared):
 store,p=prepared;a={'id':uid(),'page':0,'type':'room','name':'A','points':rect_polygon([0,0,100,100])};b={'id':uid(),'page':0,'type':'room','name':'B','points':rect_polygon([90,90,50,50]),'parentId':a['id']};p['zones']=[a,b]
 with pytest.raises(ValueError):validate_project(p)

def test_excel_formula_escape():
 assert safe_cell('=1+1')=="'=1+1" and safe_cell('Spot')=='Spot'

def test_pdf_svg_csv_exports(prepared,tmp_path):
 store,p=prepared;ready(store,p);generate_circuits(p,0,p['targets'][0]['id']);p['circuits'][0]['name']='ECL " essai';pdf=export_pdf(store.folder(p['id']),p)
 with fitz.open(stream=pdf,filetype='pdf') as doc:
  assert len(doc)>=2;assert 'RECAPITULATIF' in doc[-1].get_text();assert '13' in ''.join(page.get_text() for page in doc[1:])
  paths=[d for d in doc[0].get_drawings() if '5 3' in (d.get('dashes') or '')]
  assert paths and all(not d['closePath'] for d in paths), 'Les circuits ouverts ne doivent pas etre refermes dans le PDF'
 csv=export_csv(p).decode('utf-8-sig');assert 'CIRCUITS DE TRAVAIL' in csv and 'Spot encastre' in csv
 svg=export_svg(store.folder(p['id']),p,0);ET.fromstring(svg);assert b'equipement-' in svg and b'tableau-' in svg

def test_image_import(prepared,tmp_path):
 store,_=prepared;bio=io.BytesIO();Image.new('RGB',(640,480),'white').save(bio,format='PNG');p=store.create('image.png',bio.getvalue());assert p['document']['kind']=='image';info=page_info(store.folder(p['id']),0);assert info['hasRaster'] and info['textCount']==0

def test_rotation_and_multipage_import(prepared):
 store,_=prepared;doc=fitz.open();page=doc.new_page(width=200,height=300);page.insert_text((30,30),'ROTATION');page.set_rotation(90);doc.new_page(width=400,height=400);p=store.create('pages.pdf',doc.tobytes());assert len(p['document']['pages'])==2;assert p['document']['pages'][0]['width']==300
 assert render_png(store.folder(p['id']),0).startswith(b'\x89PNG')

def test_dwg_explicitly_rejected(prepared):
 store,_=prepared
 with pytest.raises(ValueError,match='DWG'):store.create('plan.dwg',b'AC1032')

def test_dxf_blocks_units_and_room(prepared):
 store,_=prepared;doc=ezdxf.new();doc.units=ezdxf.units.MM;b=doc.blocks.new('SPOT');b.add_circle((0,0),50);b.add_circle((0,0),10);m=doc.modelspace();m.add_lwpolyline([(0,0),(4000,0),(4000,3000),(0,3000)],close=True);m.add_text('CHAMBRE 1',dxfattribs={'height':100,'insert':(200,2600)})
 for pt,ang in [((500,500),0),((2000,2000),90),((3000,2000),180)]:m.add_blockref('SPOT',pt,dxfattribs={'rotation':ang})
 stream=io.StringIO();doc.write(stream);p=store.create('test.dxf',stream.getvalue().encode());info=page_info(store.folder(p['id']),0);assert len(info['blocks'])==3;assert p['scales']['0']>0
 l={'id':uid(),'name':'Spot','blockName':'SPOT','family':'eclairage','color':'#da2936'};d,_=detect_symbols(store.folder(p['id']),p,l,0,.88);assert len(d)==3
 rooms,_=propose_rooms(store.folder(p['id']),0,p);assert len(rooms)==1 and rooms[0]['name']=='CHAMBRE 1'

def test_preserve_15_recent_revisions(prepared):
 store,p=prepared
 for i in range(18):p['name']=str(i);p=store.write(p)
 assert len(list((store.folder(p['id'])/'revisions').glob('*.json')))==15

def test_code_geometry_does_not_count_bare_text(prepared):
 store,p=prepared;doc=fitz.open();page=doc.new_page(width=500,height=400)
 for x,y,scale in [(400,70,1),(100,200,2)]:
  page.draw_circle((x,y),2*scale,color=(1,0,0));page.draw_line((x-4*scale,y),(x+4*scale,y),color=(1,0,0));page.draw_line((x,y-4*scale),(x,y+4*scale),color=(1,0,0));page.insert_text((x-4*scale,y+10*scale),'T2',fontsize=6*scale,color=(1,0,0))
 page.insert_text((300,250),'T2',fontsize=12,color=(1,0,0));p=store.create('codes.pdf',doc.tobytes());l={'id':uid(),'name':'Spot T2','family':'eclairage','color':'#ff0000','source':{'page':0,'rect':[394,64,12,12]}};p['legend']=[l];found,_=detect_symbols(store.folder(p['id']),p,l,0,.88);merge_detections(p,l['id'],0,found)
 assert len(p['elements'])==1 and abs(p['elements'][0]['x']-100)<1
