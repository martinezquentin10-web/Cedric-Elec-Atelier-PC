"""Brouillons sur disque et recuperation non destructive des projets bureau."""
from __future__ import annotations
import copy
import io
import hashlib
import re
import json
import os
import tempfile
import zipfile
from pathlib import Path
from storage import Store, LOCK, now, validate_project


def atomic_bytes(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=path.name + '.', suffix='.tmp', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


class DesktopStore(Store):
    def __init__(self, root):
        super().__init__(root)
        self.drafts = self.root.parent / 'Brouillons'
        self.drafts.mkdir(exist_ok=True)
        self._sequence = {}

    def checkpoint(self, project, sequence, session, dirty=True):
        if not isinstance(sequence, int) or sequence < 0:
            raise ValueError('Numero de brouillon invalide.')
        p = validate_project(copy.deepcopy(project))
        folder = self.folder(p['id'])
        with LOCK:
            authoritative = self.load(p['id'])
            if p['document'] != authoritative['document']:
                raise ValueError('Le plan source du brouillon ne correspond pas au chantier.')
            key = (str(session), p['id'])
            if sequence < self._sequence.get(key, -1):
                return {'ok': True, 'ignored': True}
            session_key = hashlib.sha256(str(session).encode('utf-8')).hexdigest()[:16]
            record = {'project': p, 'at': now(), 'dirty': bool(dirty), 'sequence': sequence, 'session': session_key}
            atomic_bytes(self.drafts / (p['id'] + '.' + session_key + '.json'),
                         json.dumps(record, ensure_ascii=False, allow_nan=False).encode('utf-8'))
            self._sequence[key] = sequence
        return {'ok': True, 'dirty': bool(dirty)}

    def recovery_list(self):
        entries = []
        with LOCK:
            for path in self.drafts.glob('*.json'):
                try:
                    record = json.loads(path.read_text(encoding='utf-8'))
                    p = validate_project(record['project'])
                    if record.get('dirty'):
                        entries.append({'id': p['id'], 'key': path.stem, 'name': p['name'], 'at': record['at'], 'kind': 'draft'})
                except (OSError, ValueError, KeyError, TypeError):
                    continue
        return sorted(entries, key=lambda entry: entry['at'], reverse=True)

    def recover(self, identifier, revision=None):
        """Toujours une copie independante, jamais d'ecrasement du chantier."""
        reference = str(identifier)
        if '.' in reference and revision is None:
            if not re.fullmatch(r'[a-f0-9]{32}\.[a-f0-9]{16}', reference):
                raise ValueError('Reference de brouillon invalide.')
            identifier = reference.split('.')[0]
        folder = self.folder(identifier)
        if revision is None:
            if '.' not in reference:
                choices = [r for r in self.recovery_list() if r['id'] == identifier]
                if not choices:
                    raise FileNotFoundError('Aucun brouillon non confirme.')
                reference = choices[0]['key']
            path = self.drafts / (reference + '.json')
            data = json.loads(path.read_text(encoding='utf-8'))['project']
        else:
            if not isinstance(revision, int) or revision < 0:
                raise ValueError('Revision invalide.')
            path = folder / 'revisions' / f'{revision:08d}.json'
            data = json.loads(path.read_text(encoding='utf-8'))
        p = validate_project(copy.deepcopy(data))
        if p['id'] != identifier:
            raise ValueError('Ce brouillon appartient a un autre chantier.')
        ext = p['document']['sourceExtension']
        if ext not in ('.pdf', '.dxf', '.png', '.jpg', '.jpeg', '.webp'):
            raise ValueError('Format source invalide.')
        source = folder / ('original' + ext)
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as archive:
            archive.writestr('project.json', json.dumps(p, ensure_ascii=False))
            archive.write(source, 'original' + ext)
        recovered = self.restore(buffer.getvalue())
        recovered['name'] = (p['name'][:95] + ' - recuperation')
        return self.write(recovered)
