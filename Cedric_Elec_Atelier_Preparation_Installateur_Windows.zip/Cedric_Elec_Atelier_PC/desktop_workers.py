"""Moteurs isoles : aucun appel PDF dans les threads HTTP ou de l'interface.

Les processus de rendu et d'analyse sont distincts. Un processus arrete est
recree a la demande suivante; les ecritures des projets restent dans le parent.
"""
from __future__ import annotations
import multiprocessing as mp
import os
import threading
import time
from pathlib import Path


class WorkerFailure(RuntimeError):
    pass


def dispatch(operation, args, kwargs, progress):
    """Liste fermee d'operations, uniquement appelee par le code local."""
    import engine
    if operation == 'detect_symbols':
        return engine.detect_symbols(*args, **kwargs, progress=progress)
    allowed = {'prepare_document', 'render_png', 'render_tile', 'page_info',
               'propose_rooms', 'propose_legend'}
    if operation in allowed:
        return getattr(engine, operation)(*args, **kwargs)
    if operation in {'export_pdf', 'export_svg'}:
        import exports
        return getattr(exports, operation)(*args, **kwargs)
    if operation == 'create_demo':
        from demo import create_demo
        return create_demo(*args, **kwargs)
    raise ValueError('Operation de moteur non autorisee.')


def _worker_loop(pipe, target):
    """Chaque processus lit une demande a la fois, sur son thread principal."""
    try:
        while True:
            request = pipe.recv()
            if request is None:
                return
            operation, args, kwargs = request
            def report(label, fraction):
                pipe.send(('progress', str(label), float(fraction)))
            try:
                result = target(operation, args, kwargs, report)
                pipe.send(('result', result))
            except Exception as exc:
                pipe.send(('error', type(exc).__name__, str(exc)[:700]))
    except (EOFError, BrokenPipeError, OSError):
        pass
    finally:
        pipe.close()


class WorkerLane:
    def __init__(self, name, *, target=dispatch, recycle=120):
        self.name = name
        self._target = target
        self._context = mp.get_context('spawn')
        self._call_lock = threading.Lock()
        self._state_lock = threading.RLock()
        self._process = self._pipe = None
        self._closed = False
        self._tasks = 0
        self._recycle = recycle

    def _stop(self):
        with self._state_lock:
            pipe, process = self._pipe, self._process
            self._pipe = self._process = None
            self._tasks = 0
            if process:
                if process.is_alive():
                    process.terminate()
                process.join(timeout=2)
                if process.is_alive():
                    process.kill()
                    process.join(timeout=2)
                try:
                    process.close()
                except ValueError:
                    pass
            if pipe:
                pipe.close()

    def _start(self):
        with self._state_lock:
            if self._closed:
                raise WorkerFailure('Le logiciel est en cours de fermeture.')
            if self._process is not None and self._process.is_alive():
                return
            self._stop()
            parent, child = self._context.Pipe()
            process = self._context.Process(
                target=_worker_loop, args=(child, self._target),
                name='CE-' + self.name, daemon=True)
            try:
                process.start()
            except BaseException:
                parent.close()
                child.close()
                raise
            child.close()
            self._pipe, self._process = parent, process

    def call(self, operation, *args, timeout=120, cancel=None,
             progress=None, **kwargs):
        deadline = time.monotonic() + timeout
        locked = False
        try:
            while not locked:
                if self._closed:
                    raise WorkerFailure('Le moteur est ferme.')
                if cancel and cancel.is_set():
                    raise InterruptedError('Analyse annulee. Les resultats termines sont conserves.')
                if time.monotonic() >= deadline:
                    raise WorkerFailure('Moteur occupe. Reessayez apres le traitement en cours.')
                locked = self._call_lock.acquire(timeout=.08)
            self._start()
            pipe = self._pipe
            pipe.send((operation, args, kwargs))
            while True:
                if cancel and cancel.is_set():
                    self._stop()
                    raise InterruptedError('Analyse annulee. Les resultats termines sont conserves.')
                if time.monotonic() >= deadline:
                    self._stop()
                    raise WorkerFailure('Le delai de calcul est depasse. Ce calcul est arrete; vos projets enregistres restent disponibles. Vous pouvez reessayer sans fermer le logiciel.')
                if pipe.poll(.08):
                    message = pipe.recv()
                    if message[0] == 'progress':
                        if progress:
                            progress(message[1], message[2])
                        continue
                    if message[0] == 'error':
                        errors = {'ValueError': ValueError,
                                  'FileNotFoundError': FileNotFoundError,
                                  'InterruptedError': InterruptedError,
                                  'PermissionError': PermissionError}
                        raise errors.get(message[1], WorkerFailure)(message[2])
                    if message[0] != 'result':
                        raise WorkerFailure('Reponse du moteur non reconnue.')
                    self._tasks += 1
                    result = message[1]
                    if self._tasks >= self._recycle:
                        self._stop()
                    return result
                if self._process is None or not self._process.is_alive():
                    raise EOFError('Processus de calcul arrete.')
        except (InterruptedError, FileNotFoundError, PermissionError):
            raise
        except (EOFError, BrokenPipeError, OSError) as exc:
            self._stop()
            raise WorkerFailure('Le moteur de calcul a ete interrompu. Vos projets enregistres sont conserves; relancez seulement cette operation, pas le logiciel.') from exc
        finally:
            if locked:
                self._call_lock.release()

    def close(self):
        self._closed = True
        self._stop()


class DesktopWorkers:
    def __init__(self):
        self.render = WorkerLane('rendu')
        self.analysis = WorkerLane('analyse', recycle=24)

    def install(self):
        """Injection explicite a l'entree bureau; le site existant n'est pas modifie."""
        import app
        import storage
        self._original = {}
        def bind(module, name, wrapper):
            self._original[(module, name)] = getattr(module, name)
            setattr(module, name, wrapper)
        for name in ['render_png', 'render_tile', 'page_info']:
            bind(app, name, self._proxy(name, self.render, 45))
        for name in ['propose_rooms', 'propose_legend', 'export_pdf', 'export_svg', 'create_demo']:
            bind(app, name, self._proxy(name, self.analysis, 240))
        bind(storage, 'prepare_document', self._proxy('prepare_document', self.analysis, 240))
        def detect(folder, project, legend, page, threshold, progress, cancel):
            return self.analysis.call('detect_symbols', folder, project, legend,
                                      page, threshold, progress=progress,
                                      cancel=cancel, timeout=300)
        bind(app, 'detect_symbols', detect)

    @staticmethod
    def _proxy(name, lane, timeout):
        def proxy(*args, **kwargs):
            return lane.call(name, *args, timeout=timeout, **kwargs)
        return proxy

    def close(self):
        self.render.close()
        self.analysis.close()
        for (module, name), original in getattr(self, '_original', {}).items():
            setattr(module, name, original)
